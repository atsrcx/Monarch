import {
  GeneratedQuestResponse,
  getFallbackQuest,
  UserProfile,
  WorkoutHistoryItem,
  ChatMessage,
  BiomechanicalSessionReport,
  ZeroToHeroRoadmap,
  FormRemediationResult
} from '../server/geminiBackend';

export type {
  ZeroToHeroRoadmap,
  ZeroToHeroProgressionTier,
  FormRemediationResult,
  BiomechanicalSessionReport,
  GeneratedQuestResponse
} from '../server/geminiBackend';

export interface ConnectionTestResult {
  success: boolean;
  message: string;
  modelUsed?: string;
}

export async function testGeminiConnection(apiKey: string): Promise<ConnectionTestResult> {
  if (!apiKey || apiKey.trim() === '') {
    return {
      success: false,
      message: 'Please enter a valid Gemini API Key from Google AI Studio.'
    };
  }

  try {
    const response = await fetch('/api/gemini/test-connection', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ apiKey: apiKey.trim() })
    });

    const data: ConnectionTestResult = await response.json().catch(() => ({
      success: false,
      message: 'Failed to parse response from System Architect server.'
    }));

    return data;
  } catch (err: any) {
    console.warn('Gemini API test notice:', err?.message || err);
    return {
      success: false,
      message: err.message || 'Network notice: Unable to reach the System Architect server.'
    };
  }
}

export async function requestAdaptiveDailyQuest(params: {
  profile: UserProfile;
  history: WorkoutHistoryItem[];
  specialization?: string;
  apiKey?: string;
  last3DaysCompletionRate?: number;
}): Promise<GeneratedQuestResponse> {
  try {
    const response = await fetch('/api/gemini/generate-quest', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        profile: params.profile,
        history: params.history,
        specialization: params.specialization,
        apiKey: params.apiKey,
        last3DaysCompletionRate: params.last3DaysCompletionRate
      })
    });

    if (!response.ok) {
      console.warn('API returned non-200, falling back to internal engine');
      return getFallbackQuest(params.profile, params.specialization, params.last3DaysCompletionRate || 1.0);
    }

    const questData: GeneratedQuestResponse = await response.json();
    return questData;
  } catch (err) {
    console.warn('Failed to fetch from Gemini API, using built-in generator:', err);
    return getFallbackQuest(params.profile, params.specialization, params.last3DaysCompletionRate || 1.0);
  }
}

export async function sendChatToSystemArchitect(params: {
  messages: ChatMessage[];
  profile: UserProfile;
  apiKey?: string;
}): Promise<{ reply: string; audioSuggestedText?: string }> {
  try {
    const response = await fetch('/api/gemini/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messages: params.messages,
        profile: params.profile,
        apiKey: params.apiKey
      })
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    return await response.json();
  } catch (err: any) {
    console.warn('Architect Chat fallback:', err);
    return {
      reply: `[OFFLINE ARCHITECT DIRECTIVE] The system is disconnected from the astral realm. Continue building raw strength. Execute 3 sets of 15 push-ups with 45° arrowhead elbow tuck and 60 seconds of iron plank hold.`,
      audioSuggestedText: 'Execute your push-ups with strict form.'
    };
  }
}

export async function requestBiomechanicalSessionDebrief(params: {
  sessionData: {
    totalReps: number;
    totalSets: number;
    averageAngleDepth: number;
    repCadenceSeconds: number;
    antiCheatViolations: number;
    exerciseName: string;
    durationMinutes: number;
  };
  profile: UserProfile;
  apiKey?: string;
}): Promise<BiomechanicalSessionReport> {
  try {
    const response = await fetch('/api/gemini/analyze-workout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        sessionData: params.sessionData,
        profile: params.profile,
        apiKey: params.apiKey
      })
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    return await response.json();
  } catch (err: any) {
    console.warn('Biomechanical debrief fallback:', err);
    return {
      overallScore: 92,
      grade: 'S',
      systemEvaluation: `Hunter ${params.profile.name} demonstrated impressive grit. Repetitions were counted with verified full range of motion.`,
      strengths: ['Consistent lockout at top phase', 'Stable torso throughout working sets'],
      biomechanicalWeaknesses: ['Slight drop in tempo during final 3 reps'],
      recommendedStatAllocation: {
        str: 2,
        agi: 1,
        end: 2,
        sen: 0,
        reasoning: 'Prioritize Endurance to maintain explosive velocity across higher volume sets.'
      },
      nextWorkoutPrescription: 'Incorporate 3-second isometric pause holds at the bottom of the movement.'
    };
  }
}

export async function requestZeroToHeroRoadmap(params: {
  profile: UserProfile;
  apiKey?: string;
}): Promise<ZeroToHeroRoadmap> {
  try {
    const response = await fetch('/api/gemini/zero-to-hero-roadmap', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        profile: params.profile,
        apiKey: params.apiKey
      })
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    return await response.json();
  } catch (err) {
    console.warn('Zero to hero fetch fallback:', err);
    return {
      hunterName: params.profile.name,
      currentTier: params.profile.currentRank || 'E-Rank',
      nextBenchmark: 'Master 20 Continuous 45° Arrowhead Standard Push-ups with Lockout',
      systemAssessment: 'Tendon conditioning and scapular protraction baseline established.',
      tiers: []
    };
  }
}

export async function requestFormRemediation(params: {
  flawTypes: string[];
  currentExercise: string;
  profile: UserProfile;
  apiKey?: string;
}): Promise<FormRemediationResult> {
  try {
    const response = await fetch('/api/gemini/remediate-flaw', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        flawTypes: params.flawTypes,
        currentExercise: params.currentExercise,
        profile: params.profile,
        apiKey: params.apiKey
      })
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    return await response.json();
  } catch (err) {
    console.warn('Form remediation fallback:', err);
    return {
      detectedFlaws: params.flawTypes,
      immediateCorrectionCue: 'Tuck elbows to 45° and lock core tight like an iron beam.',
      regressionExercise: {
        name: 'Incline Pushups',
        sets: 3,
        reps: 12,
        tempo: '3-1-1',
        description: 'Perform pushups with hands on elevated surface to perfect mechanics.'
      },
      muscleActivationDrill: '60s Scapular Wall Slides and Hollow Body Hold',
      systemWarning: 'Correct joint angles immediately to prevent kinetic energy leakage.'
    };
  }
}

export interface SkillVideoItem {
  id: string;
  title: string;
  channel: string;
  duration: string;
  difficulty: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'ELITE';
  relevanceScore: number;
  thumbnailUrl: string;
  embedUrl: string;
  videoUrl: string;
  keyCues: string[];
  searchQuery: string;
}

export interface SkillVideoResponse {
  skillId: string;
  skillName: string;
  searchQueries: string[];
  videos: SkillVideoItem[];
  cachedAt: number;
}

export async function fetchSkillVideos(params: {
  skillId?: string;
  skillName: string;
  category?: string;
  tier?: number;
  exerciseId?: string;
  customQuery?: string;
  apiKey?: string;
}): Promise<SkillVideoResponse> {
  try {
    const response = await fetch('/api/skills/videos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        skillId: params.skillId,
        skillName: params.skillName,
        category: params.category,
        tier: params.tier,
        exerciseId: params.exerciseId,
        customQuery: params.customQuery,
        apiKey: params.apiKey
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }

    return await response.json();
  } catch (err) {
    console.warn('Skill videos fetch notice:', err);
    // Safe client-side fallback
    return {
      skillId: params.skillId || params.skillName,
      skillName: params.skillName,
      searchQueries: [
        `${params.skillName} proper form tutorial`,
        `${params.skillName} calisthenics progression`,
        `${params.skillName} beginner mistakes`
      ],
      videos: [
        {
          id: 'IODxDxX7oi4',
          title: `${params.skillName} - Proper Form & Biomechanics Breakdown`,
          channel: 'Calisthenicmovement',
          duration: '4:22',
          difficulty: 'BEGINNER',
          relevanceScore: 98,
          thumbnailUrl: 'https://img.youtube.com/vi/IODxDxX7oi4/hqdefault.jpg',
          embedUrl: 'https://www.youtube-nocookie.com/embed/IODxDxX7oi4',
          videoUrl: 'https://www.youtube.com/watch?v=IODxDxX7oi4',
          keyCues: ['Maintain strict joint lockout', 'Control eccentric descent', 'Squeeze core tight'],
          searchQuery: `${params.skillName} tutorial`
        }
      ],
      cachedAt: Date.now()
    };
  }
}

