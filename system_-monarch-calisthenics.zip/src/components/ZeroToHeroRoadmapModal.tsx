import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Award,
  ChevronRight,
  Zap,
  Activity,
  ShieldCheck,
  Flame,
  Layers,
  RefreshCw,
  Play,
  Camera,
  CheckCircle2
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';
import { requestZeroToHeroRoadmap, ZeroToHeroRoadmap, ZeroToHeroProgressionTier } from '../services/geminiService';

interface ZeroToHeroRoadmapModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectExerciseToPractice?: (exerciseName: string) => void;
}

export const ZeroToHeroRoadmapModal: React.FC<ZeroToHeroRoadmapModalProps> = ({
  isOpen,
  onClose,
  onSelectExerciseToPractice
}) => {
  const { profile, geminiApiKey } = useGameStore();

  const [roadmap, setRoadmap] = useState<ZeroToHeroRoadmap | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedTierIndex, setSelectedTierIndex] = useState<number>(0);

  const fetchRoadmap = async () => {
    setIsLoading(true);
    try {
      const data = await requestZeroToHeroRoadmap({
        profile,
        apiKey: geminiApiKey
      });
      setRoadmap(data);
      // Auto select current tier
      if (data.tiers && data.tiers.length > 0) {
        const tierIdx = data.tiers.findIndex((t) =>
          t.tierRank.toLowerCase().includes(profile.currentRank.toLowerCase().replace('-rank', ''))
        );
        if (tierIdx >= 0) {
          setSelectedTierIndex(tierIdx);
        }
      }
    } catch (err) {
      console.error('Failed to load roadmap:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && !roadmap) {
      fetchRoadmap();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const activeTier: ZeroToHeroProgressionTier | undefined = roadmap?.tiers[selectedTierIndex] || roadmap?.tiers[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#08090d] border border-cyan-500/40 rounded-3xl shadow-[0_0_50px_rgba(0,240,255,0.2)] flex flex-col overflow-hidden text-slate-100">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-slate-950/90 border-b border-cyan-500/25 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-purple-600/30 border border-cyan-400/40 flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.3)]">
              <Award className="w-6 h-6 text-cyan-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold tracking-widest text-cyan-400 uppercase">
                  AI FOUNDATION ENGINE (GEMINI 3.7)
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-mono bg-purple-950 text-purple-300 border border-purple-500/30">
                  ZERO TO HERO
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black font-['Orbitron'] text-white">
                CALISTHENICS MASTERY ROADMAP
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundEngine.playClick();
                fetchRoadmap();
              }}
              disabled={isLoading}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40 transition-all cursor-pointer disabled:opacity-50"
              title="Regenerate Roadmap via Gemini"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            </button>
            <button
              onClick={() => {
                soundEngine.playClick();
                onClose();
              }}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {isLoading && !roadmap ? (
            <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-12 h-12 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
              <p className="font-['Orbitron'] text-cyan-300 text-sm tracking-wider">
                SYNTHESIZING ZERO-TO-HERO PROGRESSION VECTOR...
              </p>
            </div>
          ) : (
            <>
              {/* Hunter Status Summary Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/30 to-purple-950/30 border border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-mono text-cyan-400 font-bold">
                    HUNTER VESSEL: {profile.name} (LVL {profile.level} • {profile.currentRank})
                  </div>
                  <div className="text-sm font-['Rajdhani'] font-bold text-slate-200 mt-1">
                    {roadmap?.systemAssessment || 'Tendon remodeling and kinetic vector alignment in progress.'}
                  </div>
                </div>
                <div className="sm:text-right shrink-0">
                  <div className="text-[10px] font-mono text-purple-300">NEXT BENCHMARK OBJECTIVE:</div>
                  <div className="text-xs font-bold font-mono text-cyan-300">
                    {roadmap?.nextBenchmark || '20 Strict 45° Arrowhead Pushups'}
                  </div>
                </div>
              </div>

              {/* Tier Selection Strip */}
              <div className="space-y-2">
                <label className="text-xs font-mono font-bold text-slate-400">SELECT MASTERY STAGE:</label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {roadmap?.tiers.map((tier, idx) => {
                    const isSelected = idx === selectedTierIndex;
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          soundEngine.playClick();
                          setSelectedTierIndex(idx);
                        }}
                        className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                          isSelected
                            ? 'bg-gradient-to-br from-cyan-950/80 to-blue-950/80 border-cyan-400 shadow-[0_0_20px_rgba(0,240,255,0.3)]'
                            : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <span className="text-[10px] font-mono font-bold text-purple-400">
                          {tier.levelRange}
                        </span>
                        <span className="text-xs font-bold font-['Orbitron'] text-white truncate">
                          {tier.tierRank.split(' ')[0]}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 truncate">
                          {tier.title}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Active Tier Details */}
              {activeTier && (
                <div className="p-5 rounded-3xl bg-slate-950/90 border border-cyan-500/25 space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500 text-black">
                          {activeTier.tierRank}
                        </span>
                        <span className="text-xs font-mono text-slate-400">{activeTier.levelRange}</span>
                      </div>
                      <h3 className="text-lg font-black font-['Orbitron'] text-white mt-1">
                        {activeTier.title}
                      </h3>
                    </div>
                    <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-500/30">
                      ★ BENCHMARK: {activeTier.benchmarkGoal}
                    </div>
                  </div>

                  {/* Progression Exercise Chain */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1.5">
                      <Zap className="w-4 h-4" />
                      <span>STEP-BY-STEP PROGRESSION CHAIN</span>
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {activeTier.progressionChain.map((chain, idx) => (
                        <div
                          key={idx}
                          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between gap-3"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-mono text-cyan-400 font-bold">
                                STAGE 0{idx + 1}
                              </span>
                              <span className="text-[10px] font-mono text-slate-400">
                                TARGET: ≤{chain.targetAngle}° DEPTH
                              </span>
                            </div>
                            <h5 className="text-sm font-bold font-['Orbitron'] text-white">
                              {chain.exerciseName}
                            </h5>
                            <p className="text-xs text-slate-300 font-mono">
                              {chain.masteryRequirement}
                            </p>
                          </div>

                          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                            <span className="text-purple-300 text-[11px] truncate max-w-[200px]">
                              {chain.biomechanicalFocus}
                            </span>
                            {onSelectExerciseToPractice && (
                              <button
                                onClick={() => {
                                  soundEngine.playClick();
                                  onSelectExerciseToPractice(chain.exerciseName);
                                  onClose();
                                }}
                                className="px-3 py-1 rounded-lg bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500 hover:text-black font-bold transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                              >
                                <Play className="w-3 h-3 fill-current" />
                                <span>PRACTICE</span>
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Physiological Adaptations Matrix */}
                  <div className="p-4 rounded-2xl bg-purple-950/20 border border-purple-500/30 space-y-2">
                    <h4 className="text-xs font-mono font-bold text-purple-300 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-purple-400" />
                      <span>PHYSIOLOGICAL & STRUCTURAL ADAPTATIONS</span>
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {activeTier.physiologicalBenefits.map((b, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 rounded-xl bg-purple-950/60 border border-purple-400/40 text-purple-200 text-xs font-mono"
                        >
                          ✓ {b}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
