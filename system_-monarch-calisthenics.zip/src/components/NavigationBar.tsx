import React from 'react';
import {
  Flame,
  Camera,
  User,
  Settings,
  Shield,
  Activity,
  Award,
  Sparkles,
  Layers,
  Bot,
  Sword,
  LayoutDashboard
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

export type TabType = 'dashboard' | 'skills' | 'camera' | 'combat' | 'chat' | 'stats';

interface NavigationBarProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
}

export const NavigationBar: React.FC<NavigationBarProps> = ({ activeTab, onSelectTab }) => {
  const { profile, openModal, geminiStatus } = useGameStore();

  const navItems: { id: TabType; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'dashboard',
      label: 'COMMAND',
      icon: <LayoutDashboard className="w-4 h-4 sm:w-5 sm:h-5" />
    },
    {
      id: 'skills',
      label: 'SKILLS',
      icon: <Award className="w-4 h-4 sm:w-5 sm:h-5" />
    },
    {
      id: 'camera',
      label: 'VISION AI',
      icon: <Camera className="w-4 h-4 sm:w-5 sm:h-5" />,
      badge: 'LIVE'
    },
    {
      id: 'combat',
      label: 'COMBAT',
      icon: <Sword className="w-4 h-4 sm:w-5 sm:h-5" />
    },
    {
      id: 'chat',
      label: 'COACH',
      icon: <Bot className="w-4 h-4 sm:w-5 sm:h-5" />
    },
    {
      id: 'stats',
      label: 'HUD',
      icon: <Activity className="w-4 h-4 sm:w-5 sm:h-5" />,
      badge: profile.statPoints > 0 ? `+${profile.statPoints}` : undefined
    }
  ];

  return (
    <div className="fixed bottom-3 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 w-[96%] sm:w-11/12 max-w-xl">
      <nav className="p-1.5 sm:p-2 rounded-2xl sm:rounded-3xl bg-neutral-950/95 border border-neutral-800 backdrop-blur-2xl shadow-2xl flex items-center justify-between gap-1">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                soundEngine.playClick();
                onSelectTab(item.id);
              }}
              className={`relative flex-1 py-2 px-1 sm:px-2 rounded-xl sm:rounded-2xl transition-all duration-200 flex flex-col items-center justify-center gap-0.5 sm:gap-1 font-mono font-bold cursor-pointer ${
                isActive
                  ? 'bg-white text-black font-bold shadow-lg'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
              }`}
            >
              <div className="relative">
                {item.icon}
                {item.badge && (
                  <span className={`absolute -top-1 -right-2 px-1 py-0.2 rounded-full text-[8px] sm:text-[9px] font-mono font-bold leading-none ${
                    isActive ? 'bg-black text-white' : 'bg-white text-black'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[8.5px] sm:text-[9.5px] tracking-wider uppercase font-['Orbitron'] truncate max-w-full">
                {item.label}
              </span>
            </button>
          );
        })}

        {/* Settings Action Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            openModal('settings');
          }}
          className="relative py-2 px-1 sm:px-2 rounded-xl sm:rounded-2xl text-neutral-400 hover:text-white hover:bg-neutral-900 transition-all flex flex-col items-center justify-center gap-0.5 sm:gap-1 font-mono font-bold cursor-pointer"
          title="System Protocol & Gemini Settings"
        >
          <div className="relative">
            <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
            <span
              className={`absolute -top-1 -right-1 w-2 h-2 rounded-full ${
                geminiStatus === 'online' ? 'bg-white shadow-[0_0_6px_#ffffff]' : 'bg-neutral-600'
              }`}
            />
          </div>
          <span className="text-[8.5px] sm:text-[9.5px] tracking-wider uppercase font-['Orbitron']">
            CONFIG
          </span>
        </button>
      </nav>
    </div>
  );
};

export default NavigationBar;
