import React, { useState } from 'react';
import {
  ShieldAlert,
  Flame,
  Clock,
  Sparkles,
  Play,
  CheckCircle2,
  RefreshCw,
  Award,
  ChevronRight,
  TrendingUp,
  Zap,
  Target,
  Dumbbell
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { requestAdaptiveDailyQuest } from '../services/geminiService';
import { soundEngine } from '../utils/soundEngine';

interface DailyQuestProps {
  onStartExercise: (exerciseId: string) => void;
}

export const DailyQuest: React.FC<DailyQuestProps> = ({ onStartExercise }) => {
  const {
    profile,
    currentQuest,
    completedSetsMap,
    isQuestCompleted,
    isPenaltyActive,
    streak,
    specialization,
    geminiApiKey,
    workoutHistory,
    setDailyQuest,
    triggerPenaltyQuest,
    openModal
  } = useGameStore();

  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Handle regenerating adaptive quest from Gemini
  const handleRegenerateQuest = async () => {
    soundEngine.playClick();
    setIsRefreshing(true);

    const historyItems = workoutHistory.map((h) => ({
      date: h.date,
      exercise: h.exerciseName,
      completedReps: h.reps,
      targetReps: h.targetReps,
      accuracyScore: h.accuracyScore
    }));

    const newQuest = await requestAdaptiveDailyQuest({
      profile,
      history: historyItems,
      specialization,
      apiKey: geminiApiKey
    });

    setIsRefreshing(false);
    setDailyQuest(newQuest);
    soundEngine.playSystemOpen();
  };

  // Calculate overall quest completion percentage
  const totalSetsRequired = currentQuest.exercises.reduce((acc, ex) => acc + ex.sets, 0);
  const totalSetsCompleted = currentQuest.exercises.reduce((acc, ex) => {
    const done = completedSetsMap[ex.id] || 0;
    return acc + Math.min(ex.sets, done);
  }, 0);
  const progressPercent = Math.round((totalSetsCompleted / Math.max(1, totalSetsRequired)) * 100);

  const formattedDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric'
  });

  return (
    <div className="space-y-6">
      {/* Holographic Solo Leveling Quest Header Banner */}
      <div
        className={`relative overflow-hidden rounded-3xl p-5 sm:p-7 border backdrop-blur-2xl transition-all shadow-2xl ${
          isPenaltyActive
            ? 'bg-gradient-to-br from-red-950/80 via-black to-red-900/40 border-red-500/60 shadow-[0_0_40px_rgba(255,51,102,0.3)]'
            : isQuestCompleted
            ? 'bg-gradient-to-br from-emerald-950/60 via-slate-900 to-cyan-950/60 border-emerald-400/50 shadow-[0_0_35px_rgba(16,185,129,0.25)]'
            : 'bg-gradient-to-br from-slate-900/90 via-[#0b101d]/90 to-cyan-950/50 border-cyan-500/40 shadow-[0_0_40px_rgba(0,240,255,0.18)]'
        }`}
      >
        {/* Glowing cyber grid pattern in background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#00f0ff_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold tracking-widest uppercase border ${
                  isPenaltyActive
                    ? 'bg-red-950 border-red-400 text-red-300 animate-pulse'
                    : 'bg-cyan-950 border-cyan-400/50 text-cyan-300'
                }`}
              >
                <Zap className="w-3 h-3 mr-1 text-cyan-400" />
                {formattedDate} • {currentQuest.difficulty} DIFFICULTY
              </span>

              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-purple-950/80 border border-purple-400/40 text-purple-300">
                REQUIRED: {currentQuest.rankRequirement || profile.currentRank}
              </span>

              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-950/80 border border-amber-400/40 text-amber-300 flex items-center gap-1">
                <Flame className="w-3 h-3 text-amber-400" />
                {streak} DAY STREAK
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black font-['Orbitron'] text-white tracking-wide">
              {currentQuest.questTitle}
            </h1>

            <p className="text-xs sm:text-sm font-mono text-slate-300/90 max-w-2xl leading-relaxed">
              {currentQuest.systemMessage}
            </p>
          </div>

          {/* Quick Stats & Refresh */}
          <div className="flex flex-row md:flex-col items-center md:items-end justify-between gap-3 shrink-0">
            <div className="flex items-center gap-3">
              <div className="text-left md:text-right">
                <div className="text-[10px] font-mono text-slate-400">TOTAL EST. TIME</div>
                <div className="text-sm font-bold font-['Rajdhani'] text-cyan-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {currentQuest.totalEstimatedTimeMin} MINS
                </div>
              </div>
              <div className="text-left md:text-right">
                <div className="text-[10px] font-mono text-slate-400">CALORIC BURN</div>
                <div className="text-sm font-bold font-['Rajdhani'] text-purple-300 flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5" />
                  ~{currentQuest.estimatedCalories} KCAL
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  openModal('roadmap');
                }}
                className="py-2 px-3 rounded-xl font-['Rajdhani'] font-bold text-xs bg-gradient-to-r from-purple-900/60 to-indigo-900/60 hover:from-purple-800 hover:to-indigo-800 border border-purple-400/40 text-purple-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(168,85,247,0.25)]"
                title="View Zero-to-Hero Calisthenics Mastery Progression Roadmap"
              >
                <Award className="w-3.5 h-3.5 text-purple-300" />
                <span>ZERO TO HERO</span>
              </button>

              <button
                onClick={handleRegenerateQuest}
                disabled={isRefreshing}
                className="py-2 px-3.5 rounded-xl font-['Rajdhani'] font-bold text-xs bg-slate-800/80 hover:bg-slate-700 border border-slate-600 text-cyan-300 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                title="Generate new daily variation using Gemini AI"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>AI RE-CALIBRATE</span>
              </button>
            </div>
          </div>
        </div>

        {/* Global Quest Progress Bar */}
        <div className="relative mt-6 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between text-xs font-mono mb-2">
            <span className="text-slate-300 font-bold">QUEST COMPLETION RATE</span>
            <span className="font-['Orbitron'] font-black text-cyan-300">{progressPercent}%</span>
          </div>
          <div className="w-full h-3 rounded-full bg-black/60 border border-slate-800 p-0.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isQuestCompleted
                  ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 shadow-[0_0_15px_#00f0ff]'
                  : 'bg-gradient-to-r from-cyan-500 to-purple-600'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Push & Calisthenics Routine Exercises Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base sm:text-lg font-black font-['Orbitron'] text-white tracking-wide">
              TODAY'S SPECIALIZATION DRILLS
            </h2>
          </div>
          <span className="text-xs font-mono text-cyan-400">
            {totalSetsCompleted}/{totalSetsRequired} SETS VERIFIED
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {currentQuest.exercises.map((exercise, index) => {
            const completedSets = completedSetsMap[exercise.id] || 0;
            const isExerciseFinished = completedSets >= exercise.sets;

            return (
              <div
                key={exercise.id}
                className={`relative rounded-2xl p-5 border backdrop-blur-xl transition-all duration-300 flex flex-col justify-between ${
                  isExerciseFinished
                    ? 'bg-slate-950/60 border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
                    : 'bg-slate-900/70 border-slate-800 hover:border-cyan-500/40 shadow-lg hover:shadow-[0_0_25px_rgba(0,240,255,0.15)]'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-slate-800 text-slate-300 border border-slate-700">
                      DRILL #{index + 1} • {exercise.category.toUpperCase()}
                    </span>

                    {isExerciseFinished ? (
                      <span className="flex items-center gap-1 text-xs font-mono font-bold text-emerald-400">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        CLEARED
                      </span>
                    ) : (
                      <span className="text-xs font-mono text-cyan-400 font-bold">
                        {completedSets} / {exercise.sets} SETS
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="text-base font-black font-['Orbitron'] text-white leading-snug">
                      {exercise.name}
                    </h3>
                    <p className="text-xs font-mono text-slate-400 mt-1 line-clamp-2">
                      {exercise.description}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-black/40 border border-slate-800 space-y-1 text-xs font-mono">
                    <div className="flex justify-between text-slate-300">
                      <span>Target Volume:</span>
                      <span className="font-bold text-white">
                        {exercise.sets} Sets × {exercise.repsPerSet} Reps
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Rest Interval:</span>
                      <span className="font-bold text-cyan-300">{exercise.restSeconds}s</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Reward per Rep:</span>
                      <span className="font-bold text-purple-300">+{exercise.xpPerRep} XP</span>
                    </div>
                  </div>

                  <div className="text-[11px] font-mono text-cyan-400/90 bg-cyan-950/40 p-2 rounded-lg border border-cyan-500/20">
                    <span className="font-bold">Form Cue:</span> {exercise.formFocus}
                  </div>
                </div>

                {/* Launch Button */}
                <div className="pt-4 mt-2">
                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      onStartExercise(exercise.id);
                    }}
                    className={`w-full py-3 px-4 rounded-xl font-['Rajdhani'] font-bold text-sm tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      isExerciseFinished
                        ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        : 'bg-gradient-to-r from-cyan-400 to-blue-600 text-black hover:opacity-95 shadow-[0_0_15px_rgba(0,240,255,0.3)]'
                    }`}
                  >
                    <Play className="w-4 h-4 fill-current" />
                    {isExerciseFinished ? 'REPEAT DRILL VIA AI CAMERA' : 'ENGAGE VISION AI TRACKER'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rewards & Penalty Protocol Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Quest Rewards */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-cyan-500/20 space-y-3 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-black font-['Orbitron'] text-white">
              DAILY COMPLETION REWARDS
            </h3>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center font-mono">
            <div className="p-3 rounded-xl bg-black/40 border border-slate-800">
              <div className="text-[10px] text-slate-400">EXP POINTS</div>
              <div className="text-base font-black text-cyan-300 mt-0.5">+{currentQuest.rewards.xp} XP</div>
            </div>
            <div className="p-3 rounded-xl bg-black/40 border border-slate-800">
              <div className="text-[10px] text-slate-400">STAT POINTS</div>
              <div className="text-base font-black text-purple-300 mt-0.5">+{currentQuest.rewards.statPoints} PTS</div>
            </div>
            <div className="p-3 rounded-xl bg-black/40 border border-slate-800">
              <div className="text-[10px] text-slate-400">MONARCH GOLD</div>
              <div className="text-base font-black text-amber-400 mt-0.5">+{currentQuest.rewards.gold} G</div>
            </div>
          </div>
        </div>

        {/* Penalty Protocol Warning */}
        <div className="p-5 rounded-2xl bg-red-950/40 border border-red-500/30 space-y-3 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <h3 className="text-sm font-black font-['Orbitron'] text-red-200">
                PENALTY QUEST PROTOCOL
              </h3>
            </div>
            <button
              onClick={() => {
                triggerPenaltyQuest();
              }}
              className="text-[10px] font-mono px-2 py-1 rounded bg-red-900/50 hover:bg-red-800 text-red-300 border border-red-500/40 cursor-pointer"
            >
              TEST PENALTY ZONE
            </button>
          </div>
          <p className="text-xs font-mono text-slate-300 leading-relaxed">
            {currentQuest.penalty.description}
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            {currentQuest.penalty.tasks.map((task, i) => (
              <span
                key={i}
                className="px-2.5 py-1 rounded-lg bg-black/50 border border-red-500/30 text-[11px] font-mono text-red-300"
              >
                ⚠️ {task}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DailyQuest;
