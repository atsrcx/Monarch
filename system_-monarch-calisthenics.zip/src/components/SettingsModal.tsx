import React, { useState, useEffect } from 'react';
import {
  X,
  Key,
  Eye,
  EyeOff,
  Activity,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink,
  Volume2,
  VolumeX,
  RotateCcw,
  Shield,
  Trash2,
  Cpu,
  Sparkles,
  Zap,
  Download,
  Smartphone,
  Check,
  Globe,
  WifiOff
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { testGeminiConnection } from '../services/geminiService';
import { soundEngine } from '../utils/soundEngine';
import { aiTts } from '../utils/aiTtsEngine';

export const SettingsModal: React.FC = () => {
  const {
    geminiApiKey,
    geminiStatus,
    geminiStatusMessage,
    specialization,
    audioVolume,
    isMuted,
    cameraFacingMode,
    showSkeleton,
    antiCheatEnabled,
    closeModal,
    setGeminiApiKey,
    setGeminiStatus,
    setSpecialization,
    setVolume,
    toggleMute,
    setCameraFacingMode,
    toggleSkeleton,
    toggleAntiCheat,
    resetAllProgress
  } = useGameStore();

  const [inputKey, setInputKey] = useState<string>(geminiApiKey);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [confirmReset, setConfirmReset] = useState<boolean>(false);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);

  useEffect(() => {
    // Detect standalone PWA mode
    const checkStandalone = () => {
      const isStandaloneMode =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true;
      setIsStandalone(isStandaloneMode);
      if (isStandaloneMode) {
        setIsInstalled(true);
      }
    };
    checkStandalone();

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallPwa = async () => {
    soundEngine.playClick();
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        soundEngine.playLevelUp();
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      alert('To install Monarch PWA, tap your browser menu (or Share button on iOS Safari) and select "Add to Home Screen" or "Install App".');
    }
  };

  // Handle Save API Key
  const handleSaveKey = () => {
    soundEngine.playClick();
    setGeminiApiKey(inputKey.trim());
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Run Real-Time Connection Test Protocol
  const handleTestConnection = async () => {
    const keyToTest = inputKey.trim() || geminiApiKey;
    if (!keyToTest) {
      setGeminiStatus('error', 'Please enter a Gemini API Key before testing.');
      return;
    }

    soundEngine.playClick();
    setIsTesting(true);
    setGeminiStatus('testing', 'Authenticating with Google Gemini Neural Grid...');

    const result = await testGeminiConnection(keyToTest);
    setIsTesting(false);

    if (result.success) {
      soundEngine.playLevelUp();
      setGeminiStatus('online', result.message || 'System Link Established: Grand Architect Online');
      setGeminiApiKey(keyToTest);
    } else {
      soundEngine.playPenaltyAlert();
      setGeminiStatus('error', result.message || 'Failed to authenticate with Gemini API.');
    }
  };

  const handleResetData = () => {
    if (!confirmReset) {
      setConfirmReset(true);
      return;
    }
    soundEngine.playPenaltyAlert();
    resetAllProgress();
    closeModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl overflow-y-auto">
      <div className="relative w-full max-w-xl my-8 rounded-3xl bg-[#0b0f19]/90 border border-cyan-500/30 shadow-[0_0_50px_rgba(0,240,255,0.2)] text-slate-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-cyan-500/20 flex items-center justify-between bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
              <Cpu className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black font-['Orbitron'] text-white tracking-wider">
                SYSTEM PROTOCOL & CONFIG
              </h2>
              <p className="text-xs font-mono text-cyan-400/80">Neural Architect & Calisthenics HUD Engine</p>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playClick();
              closeModal();
            }}
            className="p-2 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-400 hover:text-white hover:border-cyan-400/50 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto custom-scrollbar">
          {/* Gemini API Key & Connection Section */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-cyan-500/20 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold font-['Orbitron'] text-white tracking-wide">
                  GEMINI AI ARCHITECT KEY
                </h3>
              </div>
              <a
                href="https://aistudio.google.com/"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 hover:underline cursor-pointer"
              >
                Get Free Key <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="relative flex items-center">
              <input
                type={showPassword ? 'text' : 'password'}
                value={inputKey}
                onChange={(e) => setInputKey(e.target.value)}
                placeholder="AIzaSy... (Google AI Studio Gemini Key)"
                className="w-full py-3 pl-4 pr-11 rounded-xl bg-black/70 border border-slate-700 text-slate-100 placeholder-slate-500 text-xs sm:text-sm font-mono focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 p-1.5 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex flex-wrap gap-2.5 pt-1">
              <button
                onClick={handleSaveKey}
                className="py-2.5 px-4 rounded-xl font-['Rajdhani'] font-bold text-xs sm:text-sm tracking-wider bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white transition-all flex items-center gap-2 cursor-pointer"
              >
                {saveSuccess ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Zap className="w-4 h-4 text-cyan-400" />}
                {saveSuccess ? 'KEY SAVED' : 'SAVE KEY'}
              </button>

              <button
                onClick={handleTestConnection}
                disabled={isTesting}
                className="flex-1 py-2.5 px-4 rounded-xl font-['Rajdhani'] font-bold text-xs sm:text-sm tracking-wider bg-gradient-to-r from-cyan-500 to-blue-600 text-black hover:opacity-95 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.3)] cursor-pointer"
              >
                {isTesting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                    TESTING PROTOCOL...
                  </>
                ) : (
                  <>
                    <Activity className="w-4 h-4 text-black" />
                    TEST CONNECTION
                  </>
                )}
              </button>
            </div>

            {/* Live Status Badge */}
            {geminiStatus === 'online' && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-400/60 shadow-[0_0_18px_rgba(16,185,129,0.25)] flex items-start gap-2.5 text-emerald-300">
                <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <div className="text-xs font-mono">
                  <div className="font-bold tracking-wider">[ONLINE: SYSTEM ARCHITECT CONNECTED]</div>
                  <div className="text-slate-300 mt-0.5">{geminiStatusMessage}</div>
                </div>
              </div>
            )}

            {geminiStatus === 'error' && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/80 shadow-[0_0_18px_rgba(255,51,102,0.3)] flex items-start gap-2.5 text-red-300 animate-pulse">
                <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                <div className="text-xs font-mono">
                  <div className="font-bold tracking-wider">[OFFLINE: AUTHENTICATION ERROR]</div>
                  <div className="text-slate-300 mt-0.5">{geminiStatusMessage}</div>
                </div>
              </div>
            )}
          </div>

          {/* Calisthenics Specialization Focus */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-bold font-['Orbitron'] text-white">
                WORKOUT SPECIALIZATION TREE
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { id: 'Push & Chest Hypertrophy', desc: 'Standard -> Diamond -> Archer Pushups' },
                { id: 'All-Round Calisthenics', desc: 'Chest + Squats + Iron Core Planks' },
                { id: 'Core & Pseudo Planche', desc: 'Advanced Lever & Shoulder Lean focus' },
                { id: 'Explosive Agility & Reps', desc: 'High cadence Calisthenics endurance' }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    soundEngine.playClick();
                    setSpecialization(item.id);
                  }}
                  className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                    specialization === item.id
                      ? 'bg-purple-950/60 border-purple-400 text-white shadow-[0_0_15px_rgba(139,92,246,0.3)]'
                      : 'bg-black/40 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold font-['Rajdhani'] tracking-wide">{item.id}</div>
                  <div className="text-[10px] font-mono text-slate-400 mt-0.5">{item.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Audio & Sensor HUD Controls */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold font-['Orbitron'] text-white">
              SENSORS & AUDIO SYNTHESIZER
            </h3>

            {/* Audio Volume */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
                <span>System Web Audio Volume</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : audioVolume}
                  onChange={(e) => {
                    if (isMuted) toggleMute();
                    setVolume(parseFloat(e.target.value));
                  }}
                  className="w-28 accent-cyan-400 cursor-pointer"
                />
                <button
                  onClick={toggleMute}
                  className="text-xs font-mono px-2 py-1 rounded bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                >
                  {isMuted ? 'UNMUTE' : 'MUTE'}
                </button>
              </div>
            </div>

            {/* Vision Controls */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={toggleSkeleton}
                className={`p-3 rounded-xl border text-xs font-mono flex items-center justify-between transition-all cursor-pointer ${
                  showSkeleton ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300' : 'bg-black/40 border-slate-800 text-slate-400'
                }`}
              >
                <span>SKELETON HUD</span>
                <span className="font-bold">{showSkeleton ? 'ON' : 'OFF'}</span>
              </button>

              <button
                onClick={toggleAntiCheat}
                className={`p-3 rounded-xl border text-xs font-mono flex items-center justify-between transition-all cursor-pointer ${
                  antiCheatEnabled ? 'bg-purple-950/40 border-purple-400 text-purple-300' : 'bg-black/40 border-slate-800 text-slate-400'
                }`}
              >
                <span>ANTI-CHEAT SENTRY</span>
                <span className="font-bold">{antiCheatEnabled ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>

          {/* Vision Lab & Ghost Trainer Holographic Engine */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold font-['Orbitron'] text-white">
                  VISION LAB & GHOST TRAINER
                </h3>
              </div>
              <span className="text-[10px] font-mono text-cyan-400 font-bold bg-cyan-950/60 px-2 py-0.5 rounded-md border border-cyan-500/30">
                BIOMECHANICAL V2.0
              </span>
            </div>

            {/* Feature Toggles */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <button
                onClick={() => useGameStore.getState().toggleGhostTrainer()}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  useGameStore.getState().showGhostTrainer
                    ? 'bg-cyan-950/50 border-cyan-400 text-cyan-300'
                    : 'bg-black/40 border-slate-800 text-slate-500'
                }`}
              >
                <span>Ghost Trainer</span>
                <span className="font-bold">{useGameStore.getState().showGhostTrainer ? 'ON' : 'OFF'}</span>
              </button>

              <button
                onClick={() => useGameStore.getState().toggleMotionTrails()}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  useGameStore.getState().showMotionTrails
                    ? 'bg-cyan-950/50 border-cyan-400 text-cyan-300'
                    : 'bg-black/40 border-slate-800 text-slate-500'
                }`}
              >
                <span>Motion Trails</span>
                <span className="font-bold">{useGameStore.getState().showMotionTrails ? 'ON' : 'OFF'}</span>
              </button>

              <button
                onClick={() => useGameStore.getState().toggleJointArcs()}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  useGameStore.getState().showJointArcs
                    ? 'bg-cyan-950/50 border-cyan-400 text-cyan-300'
                    : 'bg-black/40 border-slate-800 text-slate-500'
                }`}
              >
                <span>Joint Arcs</span>
                <span className="font-bold">{useGameStore.getState().showJointArcs ? 'ON' : 'OFF'}</span>
              </button>

              <button
                onClick={() => useGameStore.getState().toggleMovementVectors()}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  useGameStore.getState().showMovementVectors
                    ? 'bg-cyan-950/50 border-cyan-400 text-cyan-300'
                    : 'bg-black/40 border-slate-800 text-slate-500'
                }`}
              >
                <span>Movement Vectors</span>
                <span className="font-bold">{useGameStore.getState().showMovementVectors ? 'ON' : 'OFF'}</span>
              </button>
            </div>

            {/* Smoothing Alpha & Confidence Sliders */}
            <div className="space-y-3 pt-2 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-slate-300">EMA Smoothing Alpha:</span>
                <span className="font-bold text-cyan-400">{useGameStore.getState().smoothingAlpha.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="0.95"
                step="0.05"
                value={useGameStore.getState().smoothingAlpha}
                onChange={(e) => useGameStore.getState().setSmoothingAlpha(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />

              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-300">Confidence Threshold:</span>
                <span className="font-bold text-cyan-400">{(useGameStore.getState().landmarkConfidenceThreshold * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="0.8"
                step="0.05"
                value={useGameStore.getState().landmarkConfidenceThreshold}
                onChange={(e) => useGameStore.getState().setLandmarkConfidenceThreshold(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>

          {/* AI Voice Coach & Neural Persona Settings */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-purple-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-bold font-['Orbitron'] text-white">
                  AI VOICE COACH & TTS SYNTHESIS
                </h3>
              </div>
              <button
                onClick={() => {
                  soundEngine.playClick();
                  aiTts.speak('System status nominal. All calisthenics protocols are calibrated to perfection.', true);
                }}
                className="text-[11px] font-mono text-purple-300 hover:text-purple-200 flex items-center gap-1 cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>TEST VOICE</span>
              </button>
            </div>

            {/* Persona Selection */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'monarch', name: 'Monarch', desc: 'Resonant & Dominant' },
                { id: 'architect', name: 'Architect', desc: 'Analytical & Cold' },
                { id: 'sergeant', name: 'Sergeant', desc: 'Strict & Urgent' },
                { id: 'cyber', name: 'Cyber AI', desc: 'Futuristic HUD' }
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    soundEngine.playClick();
                    useGameStore.getState().setTtsPersona(p.id as any);
                    aiTts.speak(`Persona switched to ${p.name}.`, true);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    useGameStore.getState().ttsPersona === p.id
                      ? 'bg-purple-950/60 border-purple-400 text-purple-200 shadow-[0_0_12px_rgba(139,92,246,0.3)]'
                      : 'bg-black/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold font-['Orbitron']">{p.name}</div>
                  <div className="text-[9px] font-mono text-slate-500">{p.desc}</div>
                </button>
              ))}
            </div>

            {/* Voice Coaching Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs font-mono">
              <button
                onClick={() => useGameStore.getState().toggleTts()}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  useGameStore.getState().ttsEnabled
                    ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                    : 'bg-black/40 border-slate-800 text-slate-500'
                }`}
              >
                <span>AI VOICE SYNTHESIS</span>
                <span className="font-bold">{useGameStore.getState().ttsEnabled ? 'ENABLED' : 'MUTED'}</span>
              </button>

              <button
                onClick={() => useGameStore.getState().toggleTtsAutoCues()}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  useGameStore.getState().ttsAutoCues
                    ? 'bg-purple-950/40 border-purple-400 text-purple-300'
                    : 'bg-black/40 border-slate-800 text-slate-500'
                }`}
              >
                <span>LIVE FORM CALLOUTS</span>
                <span className="font-bold">{useGameStore.getState().ttsAutoCues ? 'ACTIVE' : 'OFF'}</span>
              </button>
            </div>
          </div>

          {/* Production PWA & Offline System Module */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-cyan-950/40 via-slate-900/90 to-black border border-cyan-500/40 space-y-3.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold font-['Orbitron'] text-white">
                  PROGRESSIVE WEB APP (PWA)
                </h3>
              </div>
              <span className="text-[10px] font-mono text-cyan-300 font-bold bg-cyan-900/60 px-2 py-0.5 rounded-md border border-cyan-400/40 flex items-center gap-1">
                <Check className="w-3 h-3 text-cyan-400" />
                {isStandalone ? 'STANDALONE MODE' : 'PWA READY'}
              </span>
            </div>

            <p className="text-xs text-slate-300 font-mono leading-relaxed">
              Install Monarch directly onto your device for fullscreen gaming HUD, offline cached workouts, zero-latency MediaPipe vision tracking, and instant load speeds.
            </p>

            <div className="p-3 rounded-xl bg-black/60 border border-slate-800 font-mono text-[11px] space-y-1.5 text-slate-400">
              <div className="flex justify-between">
                <span>Display Environment:</span>
                <span className={isStandalone ? 'text-emerald-400 font-bold' : 'text-cyan-400 font-bold'}>
                  {isStandalone ? 'Standalone App' : 'Browser Web App'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Offline Engine (SW):</span>
                <span className="text-emerald-400 font-bold">Precached & Active</span>
              </div>
              <div className="flex justify-between">
                <span>Camera Tracking:</span>
                <span className="text-cyan-400 font-bold">Standard Web MediaDevices</span>
              </div>
              <div className="flex justify-between">
                <span>AI Model Gateway:</span>
                <span className="text-purple-400 font-bold">Gemini 2.5 Server-Proxy</span>
              </div>
            </div>

            {isInstalled ? (
              <div className="w-full py-3 px-4 rounded-xl font-mono font-bold text-xs bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 flex items-center justify-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                MONARCH PWA INSTALLED (STANDALONE ACTIVE)
              </div>
            ) : (
              <button
                onClick={handleInstallPwa}
                className="w-full py-3 px-4 rounded-xl font-mono font-bold text-xs bg-cyan-400 text-black hover:bg-cyan-300 hover:shadow-[0_0_25px_rgba(0,240,255,0.4)] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                INSTALL MONARCH PWA APP
              </button>
            )}
          </div>

          {/* Reset / Danger Zone */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <div className="text-xs font-mono text-slate-400">
              Clear local saves and restart Hunter Awakening
            </div>
            <button
              onClick={handleResetData}
              className={`py-2 px-3 rounded-xl font-mono text-xs transition-all flex items-center gap-1.5 cursor-pointer ${
                confirmReset
                  ? 'bg-red-600 text-white font-bold animate-pulse'
                  : 'bg-slate-900 border border-slate-700 text-slate-400 hover:text-red-400 hover:border-red-500/50'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              {confirmReset ? 'CONFIRM RESET?' : 'RESET DATA'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
