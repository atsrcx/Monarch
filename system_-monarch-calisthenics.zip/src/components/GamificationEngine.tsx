import React, { useState } from 'react';
import {
  Shield,
  Zap,
  Flame,
  Award,
  Plus,
  TrendingUp,
  Activity,
  User,
  Sparkles,
  ChevronRight,
  Target,
  Clock,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { useGameStore, HunterRank } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

export const GamificationEngine: React.FC = () => {
  const {
    profile,
    streak,
    workoutHistory,
    allocateStat,
    openModal
  } = useGameStore();

  const xpPercent = Math.min(100, Math.round((profile.xp / Math.max(1, profile.maxXp)) * 100));

  const stats = [
    {
      id: 'str' as const,
      label: 'STRENGTH (STR)',
      value: profile.str,
      desc: 'Increases push power, chest hypertrophy & lockouts',
    },
    {
      id: 'agi' as const,
      label: 'AGILITY (AGI)',
      value: profile.agi,
      desc: 'Accelerates rep cadence, speed & joint mobility',
    },
    {
      id: 'end' as const,
      label: 'ENDURANCE (END)',
      value: profile.end,
      desc: 'Amplifies max set capacity & isometric plank duration',
    },
    {
      id: 'sen' as const,
      label: 'SENSE / FORM (SEN)',
      value: profile.sen,
      desc: 'Heightens AI form accuracy detection & precision',
    }
  ];

  // Total Lifetime Reps & Calories
  const totalLifetimeReps = workoutHistory.reduce((acc, curr) => acc + curr.reps, 0);
  const totalLifetimeCalories = workoutHistory.reduce((acc, curr) => acc + curr.calories, 0);

  return (
    <div className="space-y-6">
      {/* Solo Leveling Hunter Status HUD */}
      <div className="rounded-3xl p-6 sm:p-8 bg-neutral-950 border border-neutral-800 shadow-2xl relative overflow-hidden text-white">
        <div className="relative z-10 space-y-6">
          {/* Top Row: Rank, Level, Titles */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800">
            <div className="flex items-center gap-4">
              {/* Rank Badge */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white text-black flex flex-col items-center justify-center font-['Orbitron'] font-black border-2 border-white shrink-0 shadow-xl">
                <span className="text-[8px] uppercase tracking-widest leading-none text-neutral-800">RANK</span>
                <span className="text-xl sm:text-2xl mt-0.5">{profile.currentRank.replace('-Rank', '')}</span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white tracking-wide">
                    {profile.name}
                  </h1>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-neutral-900 border border-neutral-800 text-white font-bold">
                    LV. {profile.level}
                  </span>
                </div>
                <div className="text-xs font-mono text-neutral-300 font-bold mt-1">
                  TITLE: « {profile.activeTitle} »
                </div>
                <div className="text-xs font-mono text-neutral-500 mt-0.5">
                  CLASS: {profile.hunterClass}
                </div>
              </div>
            </div>

            {/* Stat Points & Gold */}
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center min-w-[90px]">
                <div className="text-[10px] font-mono text-neutral-400 font-bold">STAT POINTS</div>
                <div className="text-lg font-black font-['Orbitron'] text-white mt-0.5">
                  {profile.statPoints}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center min-w-[90px]">
                <div className="text-[10px] font-mono text-neutral-400 font-bold">MONARCH GOLD</div>
                <div className="text-lg font-black font-['Orbitron'] text-white mt-0.5">
                  {profile.gold}
                </div>
              </div>
            </div>
          </div>

          {/* XP Gauge Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-1.5 text-neutral-300">
                <Sparkles className="w-3.5 h-3.5 text-white" />
                <span>EXP PROGRESSION TO LEVEL {profile.level + 1}</span>
              </div>
              <span className="font-bold text-white">
                {profile.xp} / {profile.maxXp} XP ({xpPercent}%)
              </span>
            </div>
            <div className="w-full h-3 rounded-full bg-neutral-900 border border-neutral-800 p-0.5 overflow-hidden">
              <div
                className="h-full rounded-full bg-white transition-all duration-500 shadow-[0_0_10px_#ffffff]"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
          </div>

          {/* Stat Allocation Grid */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold font-['Orbitron'] text-white tracking-wider flex items-center gap-2">
                <Activity className="w-4 h-4 text-white" />
                VESSEL ATTRIBUTES ALLOCATION
              </h2>
              {profile.statPoints > 0 && (
                <span className="text-xs font-mono font-bold text-white animate-pulse">
                  ★ {profile.statPoints} UNALLOCATED POINTS AVAILABLE
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {stats.map((stat) => (
                <div
                  key={stat.id}
                  className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <span className="text-xs font-black font-['Orbitron'] text-white">
                      {stat.label}
                    </span>
                    <p className="text-[11px] font-mono text-neutral-400">{stat.desc}</p>
                    <div className="text-xl font-black font-['Orbitron'] text-white pt-1">
                      {stat.value}
                    </div>
                  </div>

                  <button
                    onClick={() => allocateStat(stat.id)}
                    disabled={profile.statPoints <= 0}
                    className="p-2.5 rounded-xl font-bold bg-white text-black hover:bg-neutral-200 disabled:opacity-20 disabled:cursor-not-allowed transition-all cursor-pointer shadow-md"
                    title="Allocate 1 Stat Point"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Lifetime Performance Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-white">
        <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-[10px] font-mono text-neutral-400">TOTAL AI VERIFIED REPS</div>
          <div className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white mt-1">
            {totalLifetimeReps}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-[10px] font-mono text-neutral-400">CALORIES EXPELLED</div>
          <div className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white mt-1">
            {totalLifetimeCalories} <span className="text-xs font-mono text-neutral-500">kcal</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-[10px] font-mono text-neutral-400">ACTIVE STREAK</div>
          <div className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white mt-1 flex items-center gap-1">
            <Flame className="w-5 h-5 text-white" />
            {streak} <span className="text-xs font-mono text-neutral-500">days</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-[10px] font-mono text-neutral-400">HUNTER TITLES</div>
          <div className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white mt-1">
            {profile.titles.length}
          </div>
        </div>
      </div>

      {/* Recent Workout Log Feed */}
      <div className="p-5 sm:p-6 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-4 text-white">
        <h3 className="text-sm font-bold font-['Orbitron'] text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-white" />
          RECENT TRAINING LOGS & AI ACCURACY
        </h3>

        {workoutHistory.length === 0 ? (
          <div className="p-8 text-center text-xs font-mono text-neutral-500">
            No training logs recorded yet. Complete today's daily quest to populate the combat register.
          </div>
        ) : (
          <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
            {workoutHistory.slice(0, 8).map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between text-xs font-mono"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 flex items-center justify-center text-white font-bold">
                    ✓
                  </div>
                  <div>
                    <div className="font-bold text-white">{log.exerciseName}</div>
                    <div className="text-[11px] text-neutral-400">{log.date} • {log.accuracyScore}% Form Accuracy</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-white">+{log.reps} REPS</div>
                  <div className="text-[11px] text-neutral-400">+{log.xpEarned} XP • {log.calories} kcal</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default GamificationEngine;
