import React, { useEffect } from 'react';
import { Clock, Plus, SkipForward, Flame, Zap } from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

export const RestTimerModal: React.FC = () => {
  const {
    restTimerSecondsLeft,
    decrementRestTimer,
    stopRestTimer,
    startRestTimer
  } = useGameStore();

  useEffect(() => {
    if (restTimerSecondsLeft <= 0) return;

    const timer = setInterval(() => {
      decrementRestTimer();
    }, 1000);

    return () => clearInterval(timer);
  }, [restTimerSecondsLeft, decrementRestTimer]);

  const addTime = (secs: number) => {
    soundEngine.playClick();
    startRestTimer(restTimerSecondsLeft + secs);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-slate-900 via-[#0b101c] to-[#08090d] border-2 border-cyan-500/40 shadow-[0_0_60px_rgba(0,240,255,0.3)] text-slate-100 p-6 text-center space-y-6 overflow-hidden">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-bold tracking-wider uppercase">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            RECOVERY INTERVAL
          </div>
          <h2 className="text-lg font-black font-['Orbitron'] text-white pt-1">
            MUSCLE HYPERTROPHY REST
          </h2>
          <p className="text-xs font-mono text-slate-400">
            Regulate ATP and diaphragm oxygen before the next set.
          </p>
        </div>

        {/* Large Countdown Circular Ring */}
        <div className="relative w-36 h-36 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-4 border-slate-800" />
          <div className="absolute inset-0 rounded-full border-4 border-cyan-400 border-t-transparent animate-spin duration-1000" />
          <div className="text-4xl font-black font-['Share_Tech_Mono'] text-white drop-shadow-[0_0_15px_rgba(0,240,255,0.8)]">
            {restTimerSecondsLeft}s
          </div>
        </div>

        {/* Quick extension pills */}
        <div className="flex justify-center gap-2">
          <button
            onClick={() => addTime(15)}
            className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono text-cyan-300 transition-all cursor-pointer"
          >
            +15s
          </button>
          <button
            onClick={() => addTime(30)}
            className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono text-cyan-300 transition-all cursor-pointer"
          >
            +30s
          </button>
        </div>

        {/* Skip / Next Set Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            stopRestTimer();
          }}
          className="w-full py-3.5 px-6 rounded-2xl font-['Rajdhani'] font-bold text-sm tracking-wider bg-gradient-to-r from-cyan-400 to-blue-600 text-black hover:opacity-95 transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.4)] cursor-pointer"
        >
          <SkipForward className="w-4 h-4 text-black" />
          READY FOR NEXT SET (SKIP REST)
        </button>
      </div>
    </div>
  );
};

export default RestTimerModal;
