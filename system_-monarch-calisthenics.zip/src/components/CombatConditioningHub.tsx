import React, { useState, useEffect } from 'react';
import {
  Sword,
  Shield,
  Activity,
  Timer,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  ChevronRight,
  Flame,
  Zap,
  Award
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

interface CombatConditioningHubProps {
  onStartCameraWorkout: (exerciseId: string) => void;
}

export const CombatConditioningHub: React.FC<CombatConditioningHubProps> = ({
  onStartCameraWorkout,
}) => {
  const [activeMode, setActiveMode] = useState<'prehab' | 'combat_rounds'>('prehab');
  const [selectedRoutineIndex, setSelectedRoutineIndex] = useState<number>(0);

  // Round Timer State
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(45);
  const [currentInterval, setCurrentInterval] = useState<'WORK' | 'REST'>('WORK');
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const totalRounds = 5;

  useEffect(() => {
    let interval: any = null;
    if (timerRunning) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            soundEngine.playTimerBeep();
            if (currentInterval === 'WORK') {
              setCurrentInterval('REST');
              return 15;
            } else {
              if (roundNumber >= totalRounds) {
                setTimerRunning(false);
                soundEngine.playLevelUp();
                return 45;
              }
              setRoundNumber((r) => r + 1);
              setCurrentInterval('WORK');
              return 45;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerRunning, currentInterval, roundNumber]);

  const PREHAB_ROUTINES = [
    {
      title: 'Wrist Tendon & Forearm Armor Protocol',
      duration: '4 Minutes',
      focus: 'Distal biceps tendon & carpal joint prehab for Planche & Levers',
      steps: [
        'Forward Wrist Rocks (Palm flat, fingers forward, pulse forward 15 reps)',
        'Reverse Palm Rocking (Fingers pointing back to knees, pulse backward 15 reps)',
        'Back-of-Hand Knuckle Compressions (Slow partial push loading 10 reps)',
        'Fingertip Claws & Radial Wall Extensions (20 pulses)',
      ],
      exerciseId: 'plank',
    },
    {
      title: 'Scapular Kinetic Activation & Serratus Ignition',
      duration: '5 Minutes',
      focus: 'Serratus anterior protraction, lower traps, and rotator cuff stability',
      steps: [
        'Scapular Push-Up Protraction Holds (Push ground away at top, hold 3s × 10 reps)',
        'Prone Cobra / Y-T-W Scapular Retractions (12 reps)',
        'Bear Crawl Scapular Iso-Hold (45 seconds)',
        'Dead Hang Active-to-Passive Scapular Pulls (10 reps)',
      ],
      exerciseId: 'push-standard',
    },
    {
      title: 'Thoracic Extension & Shoulder Mobility',
      duration: '4 Minutes',
      focus: 'Upper spine decompression and overhead lockout range for Handstands',
      steps: [
        'Puppy Dog Thoracic Sink (Hold 45 seconds)',
        'Cat-Cow Active Spinal Segmentations (10 slow cycles)',
        'Shoulder Dislocates with Resistance Band or Stick (15 reps)',
      ],
      exerciseId: 'push-pike',
    },
  ];

  const COMBAT_ROUTINES = [
    {
      name: 'Explosive Kinetic Calisthenics Protocol',
      rounds: '5 Rounds • 45s Work / 15s Rest',
      description: 'Maximum power output: Clapping Push-Ups, Sprawls, and Fast Mountain Climbers.',
      exerciseId: 'push-standard',
    },
    {
      name: 'Iron Guard Trunk & Isometric Stamina',
      rounds: '4 Rounds • 45s Work / 15s Rest',
      description: 'Planche Leans alternating with Hollow Body Rockers and Bear Crawls.',
      exerciseId: 'planche-lean',
    },
    {
      name: 'Striker Shoulder Cadence Matrix',
      rounds: '5 Rounds • 45s Work / 15s Rest',
      description: 'Pike Push-ups with high-cadence shadow boxing intervals.',
      exerciseId: 'push-pike',
    },
  ];

  const toggleTimer = () => {
    soundEngine.playClick();
    setTimerRunning(!timerRunning);
  };

  const resetTimer = () => {
    soundEngine.playClick();
    setTimerRunning(false);
    setSecondsRemaining(45);
    setCurrentInterval('WORK');
    setRoundNumber(1);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-24 text-white">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
              <Sword className="w-4 h-4 text-white" />
              <span>MONARCH COMBAT FITNESS & PREHAB</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black font-['Orbitron'] tracking-wider text-white mt-1">
              COMBAT FITNESS HUB
            </h1>
            <p className="text-xs font-mono text-neutral-400 mt-1">
              Bulletproof your tendons, master explosive power, and execute high-intensity kinetic rounds.
            </p>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center rounded-2xl bg-neutral-900 border border-neutral-800 p-1">
            <button
              onClick={() => {
                soundEngine.playClick();
                setActiveMode('prehab');
              }}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                activeMode === 'prehab'
                  ? 'bg-white text-black font-bold shadow-lg'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              PREHAB & MOBILITY
            </button>
            <button
              onClick={() => {
                soundEngine.playClick();
                setActiveMode('combat_rounds');
              }}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                activeMode === 'combat_rounds'
                  ? 'bg-white text-black font-bold shadow-lg'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              COMBAT ROUNDS
            </button>
          </div>
        </div>
      </div>

      {/* Mode 1: Prehab & Mobility */}
      {activeMode === 'prehab' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            {PREHAB_ROUTINES.map((routine, idx) => (
              <div
                key={idx}
                onClick={() => setSelectedRoutineIndex(idx)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                  selectedRoutineIndex === idx
                    ? 'bg-neutral-900 border-white shadow-xl'
                    : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase">
                    {routine.duration} • PREHAB PROTOCOL #{idx + 1}
                  </span>
                  <Shield className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-base font-bold font-['Orbitron'] text-white mt-1">
                  {routine.title}
                </h3>
                <p className="text-xs font-mono text-neutral-400 mt-1">
                  {routine.focus}
                </p>
              </div>
            ))}
          </div>

          {/* Routine Detail Card */}
          <div className="p-6 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl space-y-4 h-fit">
            <h3 className="text-sm font-black font-['Orbitron'] text-white">
              {PREHAB_ROUTINES[selectedRoutineIndex].title}
            </h3>
            <div className="space-y-2 text-xs font-mono text-neutral-300">
              {PREHAB_ROUTINES[selectedRoutineIndex].steps.map((step, i) => (
                <div key={i} className="flex items-start gap-2 p-2.5 rounded-xl bg-neutral-900 border border-neutral-800">
                  <CheckCircle2 className="w-4 h-4 text-white shrink-0 mt-0.5" />
                  <span>{step}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() =>
                onStartCameraWorkout(PREHAB_ROUTINES[selectedRoutineIndex].exerciseId)
              }
              className="w-full py-3.5 px-4 rounded-xl bg-white text-black font-bold font-mono text-xs tracking-wider uppercase hover:bg-neutral-200 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
            >
              <Play className="w-4 h-4 fill-current text-black" />
              <span>TEST ALIGNMENT ON CAMERA</span>
            </button>
          </div>
        </div>
      )}

      {/* Mode 2: Combat Kinetic Rounds */}
      {activeMode === 'combat_rounds' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Interval Timer Deck */}
          <div className="p-6 sm:p-8 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl text-center space-y-6 flex flex-col items-center justify-center">
            <div className="space-y-1">
              <span className="text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
                ROUND {roundNumber} / {totalRounds}
              </span>
              <div
                className={`text-xs font-mono font-bold px-3 py-1 rounded-full border inline-block ${
                  currentInterval === 'WORK'
                    ? 'bg-white text-black border-white'
                    : 'bg-neutral-900 text-neutral-400 border-neutral-800'
                }`}
              >
                {currentInterval} PHASE
              </div>
            </div>

            {/* Giant Seconds Counter */}
            <div className="text-6xl sm:text-8xl font-black font-['Orbitron'] text-white">
              {secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining}
              <span className="text-lg font-mono text-neutral-500 font-normal">s</span>
            </div>

            {/* Timer Controls */}
            <div className="flex items-center gap-3 w-full max-w-xs">
              <button
                onClick={toggleTimer}
                className="flex-1 py-4 px-6 rounded-2xl bg-white text-black font-mono font-bold text-sm tracking-wider uppercase hover:bg-neutral-200 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
              >
                {timerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                <span>{timerRunning ? 'PAUSE' : 'START ROUND'}</span>
              </button>

              <button
                onClick={resetTimer}
                className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white transition-all cursor-pointer"
                title="Reset Round Timer"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Combat Matrix List */}
          <div className="space-y-4">
            {COMBAT_ROUTINES.map((routine, i) => (
              <div
                key={i}
                className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 shadow-xl"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase">
                    {routine.rounds}
                  </span>
                  <Flame className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-base font-bold font-['Orbitron'] text-white">
                  {routine.name}
                </h3>
                <p className="text-xs font-mono text-neutral-400">
                  {routine.description}
                </p>
                <button
                  onClick={() => onStartCameraWorkout(routine.exerciseId)}
                  className="w-full mt-2 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-mono font-bold text-neutral-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>COMMENCE WITH VISION AI</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CombatConditioningHub;
