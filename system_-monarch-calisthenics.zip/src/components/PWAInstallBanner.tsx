import React, { useState, useEffect } from 'react';
import { Download, X, Sparkles, Smartphone } from 'lucide-react';
import { soundEngine } from '../utils/soundEngine';

export const PWAInstallBanner: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showBanner, setShowBanner] = useState<boolean>(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setShowBanner(false);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) {
      setShowBanner(false);
      return;
    }
    soundEngine.playClick();
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      soundEngine.playLevelUp();
    }
    setDeferredPrompt(null);
    setShowBanner(false);
  };

  if (!showBanner) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-md animate-fade-in">
      <div className="p-4 rounded-2xl bg-[#0e1424]/95 border border-cyan-400/50 backdrop-blur-2xl shadow-[0_0_30px_rgba(0,240,255,0.3)] text-slate-100 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-black font-['Orbitron'] text-white">INSTALL MONARCH PWA</div>
            <div className="text-[11px] font-mono text-cyan-400">Offline Fullscreen Calisthenics Engine</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleInstall}
            className="py-1.5 px-3 rounded-lg font-['Rajdhani'] font-bold text-xs bg-gradient-to-r from-cyan-400 to-blue-600 text-black hover:opacity-90 shadow-md cursor-pointer"
          >
            INSTALL
          </button>
          <button
            onClick={() => setShowBanner(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default PWAInstallBanner;
