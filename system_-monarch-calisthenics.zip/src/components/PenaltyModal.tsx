import React, { useState, useEffect } from 'react';
import { ShieldAlert, AlertTriangle, Flame, CheckCircle, Skull, Play } from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

interface PenaltyModalProps {
  onStartPenaltyExercise?: (exerciseId: string) => void;
}

export const PenaltyModal: React.FC<PenaltyModalProps> = ({ onStartPenaltyExercise }) => {
  const { resolvePenaltyQuest, closeModal } = useGameStore();
  const [secondsLeft, setSecondsLeft] = useState<number>(14400); // 4 hours survival timer
  const [completedTasks, setCompletedTasks] = useState<Record<number, boolean>>({});

  const tasks = [
    { id: 0, title: '100 Deep Push-ups (Full Lockout)', reps: 100, xp: 150 },
    { id: 1, title: '100 Bodyweight Squats (Deep Parallel)', reps: 100, xp: 120 },
    { id: 2, title: '180 Seconds Static Iron Plank', reps: 180, xp: 100 },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const toggleTask = (index: number) => {
    soundEngine.playClick();
    setCompletedTasks((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const allCompleted = tasks.every((_, idx) => !!completedTasks[idx]);

  const handleResolve = () => {
    soundEngine.playLevelUp();
    resolvePenaltyQuest();
    closeModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-2xl overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-lg my-8 rounded-3xl bg-gradient-to-b from-[#1a050a] via-[#0d0205] to-[#08090d] border-2 border-red-500 shadow-[0_0_80px_rgba(255,51,102,0.5)] text-slate-100 p-6 sm:p-8 space-y-6 overflow-hidden">
        {/* Red warning pulse effect */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full bg-red-600/20 blur-3xl pointer-events-none" />

        <div className="text-center space-y-2 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950 border border-red-500 text-red-300 text-xs font-mono font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(255,51,102,0.4)] animate-pulse">
            <Skull className="w-3.5 h-3.5 text-red-400" />
            PENALTY ZONE ENGAGED
          </div>

          <h2 className="text-2xl sm:text-3xl font-black font-['Orbitron'] text-white tracking-wider pt-2">
            SURVIVAL QUEST: DESERT DUNGEON
          </h2>

          <div className="text-4xl sm:text-5xl font-black font-['Share_Tech_Mono'] text-red-400 py-1 tracking-widest drop-shadow-[0_0_15px_rgba(255,51,102,0.8)]">
            {formatTime(secondsLeft)}
          </div>

          <p className="text-xs font-mono text-slate-300 max-w-sm mx-auto leading-relaxed">
            [WARNING] The daily training protocol was not satisfied. Complete the survival emergency drill to escape the penalty zone without stat penalties.
          </p>
        </div>

        {/* Penalty Tasks List */}
        <div className="space-y-3 relative z-10">
          {tasks.map((task, idx) => {
            const isDone = !!completedTasks[idx];
            return (
              <div
                key={task.id}
                onClick={() => toggleTask(idx)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isDone
                    ? 'bg-emerald-950/40 border-emerald-500 text-emerald-200'
                    : 'bg-black/60 border-red-900/60 hover:border-red-500/50 text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs border ${
                      isDone
                        ? 'bg-emerald-500 text-black border-emerald-400'
                        : 'bg-black/80 border-slate-700 text-slate-500'
                    }`}
                  >
                    {isDone ? '✓' : ''}
                  </div>
                  <div>
                    <div className="text-sm font-bold font-['Rajdhani'] tracking-wide">{task.title}</div>
                    <div className="text-[10px] font-mono text-slate-400">+{task.xp} XP upon completion</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Button */}
        <div className="flex flex-col gap-2 relative z-10 pt-2">
          <button
            onClick={handleResolve}
            className={`w-full py-3.5 px-6 rounded-2xl font-['Orbitron'] font-black text-sm tracking-widest transition-all flex items-center justify-center gap-2 cursor-pointer ${
              allCompleted
                ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-black shadow-[0_0_25px_rgba(16,185,129,0.5)]'
                : 'bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-[0_0_25px_rgba(255,51,102,0.4)] hover:opacity-90'
            }`}
          >
            <CheckCircle className="w-5 h-5 text-current" />
            {allCompleted ? 'SURVIVAL COMPLETED: ESCAPE DUNGEON' : 'COMPLETE DRILL & RESOLVE'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PenaltyModal;
