import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Volume2,
  VolumeX,
  Trash2,
  Cpu,
  Bot,
  User,
  ShieldAlert,
  ArrowRight,
  RefreshCw,
  Zap,
  Terminal,
  X
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { sendChatToSystemArchitect } from '../services/geminiService';
import { soundEngine } from '../utils/soundEngine';
import { aiTts } from '../utils/aiTtsEngine';

interface SystemArchitectTerminalProps {
  onClose?: () => void;
  isModal?: boolean;
}

const QUICK_PROMPTS = [
  'How do I progress from standard push-ups to Planche push-ups?',
  'Analyze my current hunter stats and recommend attribute distribution.',
  'What is the exact biomechanics of scapular protraction during push-ups?',
  'Give me an anti-injury tendon strengthening protocol for wrists and elbows.'
];

export const SystemArchitectTerminal: React.FC<SystemArchitectTerminalProps> = ({
  onClose,
  isModal = false
}) => {
  const {
    profile,
    geminiApiKey,
    chatMessages,
    addChatMessage,
    clearChat,
    ttsEnabled,
    ttsPersona,
    setTtsPersona
  } = useGameStore();

  const [inputVal, setInputVal] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [autoSpeakReplies, setAutoSpeakReplies] = useState<boolean>(true);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query || isLoading) return;

    soundEngine.playClick();
    const userMsg = {
      role: 'user' as const,
      content: query,
      timestamp: Date.now()
    };

    addChatMessage(userMsg);
    setInputVal('');
    setIsLoading(true);

    try {
      const response = await sendChatToSystemArchitect({
        messages: [...chatMessages, userMsg],
        profile: {
          name: profile.name,
          age: profile.age,
          weightKg: profile.weightKg,
          heightCm: profile.heightCm,
          hunterClass: profile.hunterClass,
          currentRank: profile.currentRank,
          level: profile.level,
          str: profile.str,
          agi: profile.agi,
          end: profile.end,
          sen: profile.sen
        },
        apiKey: geminiApiKey
      });

      const architectMsg = {
        role: 'system' as const,
        content: response.reply,
        timestamp: Date.now()
      };

      addChatMessage(architectMsg);
      soundEngine.playLevelUp();

      if (autoSpeakReplies && ttsEnabled) {
        aiTts.speak(response.audioSuggestedText || response.reply.slice(0, 180));
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      addChatMessage({
        role: 'system',
        content: `[SYSTEM LINK LATENCY] ${err.message || 'The astral link encountered an anomaly.'}`,
        timestamp: Date.now()
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className={`flex flex-col bg-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl ${
        isModal ? 'max-h-[85vh] h-[700px]' : 'h-[620px]'
      }`}
    >
      {/* Terminal Top Bar */}
      <div className="p-4 sm:p-5 bg-black border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-neutral-900 border border-neutral-700 flex items-center justify-center">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
                MONARCH AI COACH CORE
              </span>
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            </div>
            <h3 className="text-base sm:text-lg font-black font-['Orbitron'] text-white">
              AI CALISTHENICS MASTER COACH
            </h3>
          </div>
        </div>

        {/* Top Controls: Voice toggle, persona selector, clear & close */}
        <div className="flex items-center gap-2">
          {/* Persona selector */}
          <select
            value={ttsPersona}
            onChange={(e) => setTtsPersona(e.target.value as any)}
            className="hidden sm:block px-2.5 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs font-mono cursor-pointer"
            title="System Voice Persona"
          >
            <option value="monarch">Monarch Voice</option>
            <option value="architect">Grand Architect</option>
            <option value="sergeant">Strict Sergeant</option>
            <option value="cyber">Cyber AI</option>
          </select>

          <button
            onClick={() => setAutoSpeakReplies(!autoSpeakReplies)}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              autoSpeakReplies
                ? 'bg-white text-black border-white'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-white'
            }`}
            title={autoSpeakReplies ? 'Auto Voice Playback Active' : 'Auto Voice Playback Muted'}
          >
            {autoSpeakReplies ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              clearChat();
            }}
            className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-red-400 transition-all cursor-pointer"
            title="Clear Chat Logs"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          {isModal && onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Message Feed */}
      <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 font-mono text-xs sm:text-sm">
        {chatMessages.map((msg, idx) => {
          const isSystem = msg.role === 'system';
          return (
            <div
              key={idx}
              className={`flex gap-3 ${isSystem ? 'justify-start' : 'justify-end'}`}
            >
              {isSystem && (
                <div className="w-8 h-8 rounded-xl bg-neutral-900 border border-neutral-700 flex items-center justify-center shrink-0 mt-1">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-2xl relative ${
                  isSystem
                    ? 'bg-neutral-900 border border-neutral-800 text-neutral-200'
                    : 'bg-white text-black font-medium'
                }`}
              >
                <div className="flex items-center justify-between gap-4 mb-1.5 pb-1 border-b border-neutral-700/40 text-[10px] opacity-70">
                  <span>{isSystem ? 'MONARCH AI COACH DIRECTIVE' : `ATHLETE ${profile.name}`}</span>
                  <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>

                <div className="whitespace-pre-wrap leading-relaxed">
                  {msg.content}
                </div>

                {/* Speak Message Button */}
                {isSystem && (
                  <button
                    onClick={() => aiTts.speak(msg.content)}
                    className="mt-2 text-[10px] font-mono text-neutral-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>PLAY SYSTEM AUDIO</span>
                  </button>
                )}
              </div>

              {!isSystem && (
                <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shrink-0 mt-1 text-black">
                  <User className="w-4 h-4 text-black" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-8 h-8 rounded-xl bg-neutral-900 border border-neutral-700 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-white animate-spin" />
            </div>
            <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span>MONARCH COACH IS CALCULATING BIOMECHANICAL TRAJECTORY...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 bg-black border-t border-neutral-800 flex items-center gap-2 overflow-x-auto">
        <span className="text-[10px] font-mono text-neutral-500 uppercase shrink-0">
          PROMPTS:
        </span>
        {QUICK_PROMPTS.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(prompt)}
            className="px-3 py-1 rounded-xl bg-neutral-900 hover:bg-white hover:text-black border border-neutral-800 text-[11px] font-mono text-neutral-300 transition-all cursor-pointer whitespace-nowrap"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Message Area */}
      <div className="p-4 bg-black border-t border-neutral-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="Ask Monarch Coach (e.g. form analysis, calisthenics progressions, injury safeguards)..."
            className="flex-1 px-4 py-3 rounded-2xl bg-neutral-900 border border-neutral-800 focus:border-white focus:outline-none text-white text-xs sm:text-sm font-mono placeholder-neutral-500 transition-all"
          />

          <button
            type="submit"
            disabled={isLoading || !inputVal.trim()}
            className="px-5 py-3 rounded-2xl bg-white text-black font-bold font-mono text-xs hover:bg-neutral-200 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer shadow-lg flex items-center gap-1.5"
          >
            <span>TRANSMIT</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
