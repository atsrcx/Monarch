import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Sliders,
  Sparkles,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';
import { soundEngine } from '../utils/soundEngine';

export type DemoExerciseType =
  | 'pushup_standard'
  | 'pushup_diamond'
  | 'pushup_archer'
  | 'pushup_pseudo'
  | 'squat_deep'
  | 'squat_pistol'
  | 'plank_iron';

export type ViewAngle = 'side' | 'arrowhead_top' | 'isometric_3d';

interface ExerciseDemonstratorProps {
  exerciseType?: DemoExerciseType;
  cadenceBpm?: number;
  showTelemetry?: boolean;
  onPhaseChange?: (phase: 'top' | 'descending' | 'bottom' | 'ascending', angle: number) => void;
  className?: string;
}

export const ExerciseDemonstrator: React.FC<ExerciseDemonstratorProps> = ({
  exerciseType = 'pushup_standard',
  cadenceBpm = 28,
  showTelemetry = true,
  onPhaseChange,
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animRef = useRef<number | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentView, setCurrentView] = useState<ViewAngle>('side');
  const [currentBpm, setCurrentBpm] = useState<number>(cadenceBpm);
  const [showMuscles, setShowMuscles] = useState<boolean>(true);
  const [currentAngle, setCurrentAngle] = useState<number>(165);
  const [movementPhase, setMovementPhase] = useState<'top' | 'descending' | 'bottom' | 'ascending'>('top');

  const phaseRef = useRef<number>(0);

  useEffect(() => {
    let lastTime = performance.now();

    const render = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      if (isPlaying) {
        // Metronome cadence speed
        const speed = (currentBpm / 60) * Math.PI * 2;
        phaseRef.current += dt * speed;

        const sinVal = Math.sin(phaseRef.current);
        const cosVal = Math.cos(phaseRef.current);

        // Map sine wave: 0 = bottom (< 85°), 1 = top lockout (> 160°)
        const cycle = (sinVal + 1) / 2;

        let calculatedAngle = 165;
        let phaseName: 'top' | 'descending' | 'bottom' | 'ascending' = 'top';

        if (exerciseType.startsWith('pushup')) {
          calculatedAngle = Math.round(80 + cycle * (165 - 80));
        } else if (exerciseType.startsWith('squat')) {
          calculatedAngle = Math.round(82 + cycle * (170 - 82));
        } else {
          calculatedAngle = 180;
        }

        if (cycle >= 0.92) {
          phaseName = 'top';
        } else if (cycle <= 0.08) {
          phaseName = 'bottom';
        } else if (cosVal > 0) {
          phaseName = 'ascending';
        } else {
          phaseName = 'descending';
        }

        setCurrentAngle(calculatedAngle);
        setMovementPhase(phaseName);

        if (onPhaseChange) {
          onPhaseChange(phaseName, calculatedAngle);
        }
      }

      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          drawBiomechanicalModel(
            ctx,
            canvas.width,
            canvas.height,
            exerciseType,
            phaseRef.current,
            currentView,
            showMuscles
          );
        }
      }

      animRef.current = requestAnimationFrame(render);
    };

    animRef.current = requestAnimationFrame(render);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isPlaying, currentBpm, exerciseType, currentView, showMuscles, onPhaseChange]);

  return (
    <div className={`relative rounded-3xl bg-[#08090d] border border-cyan-500/30 overflow-hidden shadow-2xl flex flex-col ${className}`}>
      {/* Top Header & View Controls */}
      <div className="p-3 bg-slate-950/90 border-b border-cyan-500/20 flex flex-wrap items-center justify-between gap-2 z-10">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#00f0ff]" />
          <span className="text-xs font-mono font-bold text-cyan-300 tracking-wider">
            ANATOMICAL KINETIC MODEL: 45° ARROWHEAD
          </span>
        </div>

        {/* View Perspective Selector */}
        <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-[11px] font-mono">
          <button
            onClick={() => {
              soundEngine.playClick();
              setCurrentView('side');
            }}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              currentView === 'side'
                ? 'bg-cyan-500/25 text-cyan-300 font-bold border border-cyan-500/40 shadow-[0_0_10px_rgba(0,240,255,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            SIDE PROFILE (BACKWARD DIVE)
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setCurrentView('arrowhead_top');
            }}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              currentView === 'arrowhead_top'
                ? 'bg-purple-500/25 text-purple-300 font-bold border border-purple-500/40 shadow-[0_0_10px_rgba(139,92,246,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            TOP 45° ARROWHEAD
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setCurrentView('isometric_3d');
            }}
            className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
              currentView === 'isometric_3d'
                ? 'bg-emerald-500/25 text-emerald-300 font-bold border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            3D ISOMETRIC
          </button>
        </div>
      </div>

      {/* Main Animation Stage */}
      <div className="relative w-full h-[320px] sm:h-[360px] bg-[#050609] flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={640}
          height={360}
          className="w-full h-full object-contain"
        />

        {/* Telemetry Overlays */}
        {showTelemetry && (
          <>
            {/* Top-Left Live Kinematic Angle & Status */}
            <div className="absolute top-3 left-3 p-3 rounded-2xl bg-black/80 backdrop-blur-md border border-cyan-500/30 text-xs font-mono space-y-1.5 pointer-events-none">
              <div className="flex items-center justify-between gap-4">
                <span className="text-slate-400">ELBOW ANGLE:</span>
                <span className="text-base font-bold font-['Share_Tech_Mono'] text-cyan-300">
                  {currentAngle}°
                </span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span className="text-slate-400">PHASE:</span>
                <span
                  className={`font-bold font-['Orbitron'] ${
                    movementPhase === 'bottom'
                      ? 'text-emerald-400'
                      : movementPhase === 'top'
                      ? 'text-cyan-400'
                      : 'text-purple-300'
                  }`}
                >
                  {movementPhase === 'top' ? 'LOCKOUT (>160°)' : movementPhase === 'bottom' ? 'CHEST DEPTH (<85°)' : movementPhase.toUpperCase()}
                </span>
              </div>
              <div className="flex items-center justify-between gap-4 text-[10px] text-emerald-400 font-bold">
                <span>ELBOW VECTOR:</span>
                <span>45° BACKWARD TUCK</span>
              </div>
            </div>

            {/* Top-Right Biomechanical Cue Note */}
            <div className="absolute top-3 right-3 p-3 rounded-2xl bg-black/80 backdrop-blur-md border border-purple-500/30 text-right text-xs font-mono space-y-1 pointer-events-none max-w-[210px]">
              <div className="text-purple-400 font-bold">ARROWHEAD RULE:</div>
              <div className="text-[11px] text-slate-300 leading-tight">
                Elbows strictly move backward relative to torso during descent.
              </div>
            </div>
          </>
        )}
      </div>

      {/* Bottom Model Controls */}
      <div className="p-3 bg-slate-950 border-t border-cyan-500/20 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2.5 rounded-xl bg-cyan-500 text-black hover:bg-cyan-400 font-bold transition-all cursor-pointer shadow-[0_0_15px_rgba(0,240,255,0.3)]"
            title={isPlaying ? 'Pause Loop' : 'Play Loop'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
          </button>

          <button
            onClick={() => {
              phaseRef.current = 0;
            }}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all cursor-pointer"
            title="Reset Loop to Lockout"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Muscle Highlight Toggle */}
          <button
            onClick={() => setShowMuscles(!showMuscles)}
            className={`px-3 py-2 rounded-xl border transition-all cursor-pointer ${
              showMuscles
                ? 'bg-purple-950/60 border-purple-400 text-purple-200'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            {showMuscles ? 'MUSCLE HEATMAP ON' : 'SKELETON ONLY'}
          </button>
        </div>

        {/* Metronome Pace Slider */}
        <div className="flex items-center gap-2 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400">PACE:</span>
          <input
            type="range"
            min="15"
            max="45"
            value={currentBpm}
            onChange={(e) => setCurrentBpm(Number(e.target.value))}
            className="w-20 accent-cyan-400 cursor-pointer"
          />
          <span className="text-cyan-300 font-bold">{currentBpm} BPM</span>
        </div>
      </div>
    </div>
  );
};

/**
 * Biomechanically Accurate Rendering Engine
 * Animate the skeleton moving such that the elbow_x value decreases (moves behind the shoulder)
 * as the chest_y moves down.
 */
function drawBiomechanicalModel(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  type: DemoExerciseType,
  phase: number,
  view: ViewAngle,
  showMuscles: boolean
) {
  ctx.clearRect(0, 0, width, height);

  // 1. Cyber Grid Background
  ctx.strokeStyle = 'rgba(0, 240, 255, 0.04)';
  ctx.lineWidth = 1;
  const grid = 36;
  for (let x = 0; x < width; x += grid) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y < height; y += grid) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  const cycle = (Math.sin(phase) + 1) / 2; // 0 = bottom (<85°), 1 = top lockout (>160°)

  // ==========================================
  // VIEW 1: SIDE PROFILE
  // Elbow_x decreases (moves behind shoulder) as chest_y descends
  // ==========================================
  if (view === 'side') {
    const groundY = height * 0.78;

    // Floor Line
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.5)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(40, groundY);
    ctx.lineTo(width - 40, groundY);
    ctx.stroke();

    // 1. Fixed Hand Placement
    const handX = width * 0.56;
    const handY = groundY;

    // Fixed Feet contact point
    const feetX = width * 0.20;
    const feetY = groundY - 8;

    // 2. Torso Movement: Chest moves down (chest_y increases towards ground)
    const verticalTravel = 95 * (1 - cycle); // Moves down on descent
    const forwardTravel = 24 * (1 - cycle); // Torso translates slightly forward relative to wrist

    const shoulderLockoutX = width * 0.56;
    const shoulderLockoutY = groundY - 140;

    const shoulderX = shoulderLockoutX + forwardTravel;
    const shoulderY = shoulderLockoutY + verticalTravel;

    const headX = shoulderX + 36;
    const headY = shoulderY - 6;

    const hipX = feetX + (shoulderX - feetX) * 0.55;
    const hipY = feetY + (shoulderY - feetY) * 0.55;

    // 3. ELBOW KINEMATICS:
    // As chest_y descends, elbow_x strictly DECREASES (moves behind shoulder line toward feet/hips)
    const elbowLockoutX = (shoulderLockoutX + handX) / 2 + 5;
    const elbowLockoutY = (shoulderLockoutY + handY) / 2;

    // At bottom (cycle = 0), elbow is 45px BEHIND shoulderX (elbow_x < shoulderX)
    const elbowBottomX = handX - 44; 
    const elbowBottomY = groundY - 34;

    const elbowX = elbowBottomX + cycle * (elbowLockoutX - elbowBottomX);
    const elbowY = elbowBottomY + cycle * (elbowLockoutY - elbowBottomY);

    // Muscle Heatmap
    if (showMuscles) {
      // Chest
      ctx.fillStyle = `rgba(0, 240, 255, ${0.15 + (1 - cycle) * 0.45})`;
      ctx.beginPath();
      ctx.ellipse(shoulderX + 8, shoulderY + 12, 22, 14, 0.2, 0, Math.PI * 2);
      ctx.fill();

      // Triceps
      ctx.fillStyle = `rgba(139, 92, 246, ${0.2 + cycle * 0.4})`;
      ctx.beginPath();
      ctx.ellipse((shoulderX + elbowX) / 2 - 4, (shoulderY + elbowY) / 2, 16, 8, -0.4, 0, Math.PI * 2);
      ctx.fill();

      // Core
      ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
      ctx.beginPath();
      ctx.ellipse((shoulderX + hipX) / 2, (shoulderY + hipY) / 2 + 4, 35, 10, 0.1, 0, Math.PI * 2);
      ctx.fill();
    }

    // Floor Anchors
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(handX, handY, 7, 0, Math.PI * 2);
    ctx.arc(feetX, feetY, 7, 0, Math.PI * 2);
    ctx.fill();

    // Torso Spine Kinetic Beam
    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(feetX, feetY);
    ctx.lineTo(hipX, hipY);
    ctx.lineTo(shoulderX, shoulderY);
    ctx.stroke();

    // Head
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(headX, headY, 15, 0, Math.PI * 2);
    ctx.fill();

    // Arm (Shoulder -> Elbow -> Wrist)
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(shoulderX, shoulderY);
    ctx.lineTo(elbowX, elbowY);
    ctx.lineTo(handX, handY);
    ctx.stroke();

    // Joint Rings
    [
      { x: shoulderX, y: shoulderY },
      { x: elbowX, y: elbowY },
      { x: hipX, y: hipY }
    ].forEach((pt) => {
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#08090d';
      ctx.fill();
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    // Angle Display
    const elbowAngle = Math.round(80 + cycle * (165 - 80));
    ctx.font = 'bold 12px "Share Tech Mono", monospace';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`${elbowAngle}° (Elbow Behind Shoulder)`, elbowX - 45, elbowY + 24);
  }

  // ==========================================
  // VIEW 2: TOP-DOWN TRANSVERSE VIEW (45° ARROWHEAD)
  // ==========================================
  else if (view === 'arrowhead_top') {
    const cx = width * 0.5;
    const cy = height * 0.52;

    const torsoW = 75;
    const torsoH = 150;

    // Spine Centerline
    ctx.strokeStyle = 'rgba(139, 92, 246, 0.4)';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(cx, cy - torsoH / 2 - 40);
    ctx.lineTo(cx, cy + torsoH / 2 + 50);
    ctx.stroke();
    ctx.setLineDash([]);

    // Torso Fill
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(cx - torsoW / 2, cy - torsoH / 2, torsoW, torsoH, 16);
    ctx.fill();
    ctx.stroke();

    // Head
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(cx, cy - torsoH / 2 - 25, 20, 0, Math.PI * 2);
    ctx.fill();

    // Shoulders
    const leftShoulderX = cx - torsoW / 2 + 5;
    const rightShoulderX = cx + torsoW / 2 - 5;
    const shoulderY = cy - torsoH / 2 + 25;

    // Hands
    const leftHandX = cx - torsoW / 2 - 22;
    const rightHandX = cx + torsoW / 2 + 22;
    const handY = shoulderY + 18;

    // 45° Arrowhead Backward Path
    const flareOffset = 42 * (1 - cycle);
    const leftElbowX = leftShoulderX - 28 - flareOffset * 0.35;
    const leftElbowY = shoulderY + 36 + flareOffset * 0.85;

    const rightElbowX = rightShoulderX + 28 + flareOffset * 0.35;
    const rightElbowY = shoulderY + 36 + flareOffset * 0.85;

    // Left Arm
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(leftShoulderX, shoulderY);
    ctx.lineTo(leftElbowX, leftElbowY);
    ctx.lineTo(leftHandX, handY);
    ctx.stroke();

    // Right Arm
    ctx.beginPath();
    ctx.moveTo(rightShoulderX, shoulderY);
    ctx.lineTo(rightElbowX, rightElbowY);
    ctx.lineTo(rightHandX, handY);
    ctx.stroke();

    // 45° Guideline vs 90° Fault
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.6)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(leftShoulderX, shoulderY);
    ctx.lineTo(leftShoulderX - 60, shoulderY + 60);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(255, 51, 102, 0.4)';
    ctx.beginPath();
    ctx.moveTo(leftShoulderX, shoulderY);
    ctx.lineTo(leftShoulderX - 70, shoulderY);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.font = 'bold 11px "Orbitron", sans-serif';
    ctx.fillStyle = '#00f0ff';
    ctx.fillText('45° ARROWHEAD (CORRECT)', leftShoulderX - 170, shoulderY + 55);

    ctx.fillStyle = '#ff3366';
    ctx.fillText('90° T-FLARE (FAULT)', leftShoulderX - 150, shoulderY - 8);

    // Hands
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(leftHandX, handY, 7, 0, Math.PI * 2);
    ctx.arc(rightHandX, handY, 7, 0, Math.PI * 2);
    ctx.fill();
  }

  // ==========================================
  // VIEW 3: 3D ISOMETRIC
  // ==========================================
  else if (view === 'isometric_3d') {
    const originX = width * 0.48;
    const originY = height * 0.55;

    const toIso = (x: number, y: number, z: number) => {
      const isoX = originX + (x - y) * Math.cos(Math.PI / 6);
      const isoY = originY + (x + y) * Math.sin(Math.PI / 6) - z;
      return { x: isoX, y: isoY };
    };

    const verticalZ = 20 + cycle * 70;
    const forwardX = (1 - cycle) * 25;

    const feet = toIso(-100, 0, 10);
    const hips = toIso(-30 + forwardX * 0.5, 0, verticalZ * 0.7);
    const shoulderL = toIso(40 + forwardX, -25, verticalZ);
    const shoulderR = toIso(40 + forwardX, 25, verticalZ);
    const head = toIso(75 + forwardX, 0, verticalZ);

    const handL = toIso(35, -35, 0);
    const handR = toIso(35, 35, 0);

    const elbowL = toIso(10 + (1 - cycle) * -22, -42, verticalZ * 0.5);
    const elbowR = toIso(10 + (1 - cycle) * -22, 42, verticalZ * 0.5);

    // Spine
    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(feet.x, feet.y);
    ctx.lineTo(hips.x, hips.y);
    ctx.lineTo((shoulderL.x + shoulderR.x) / 2, (shoulderL.y + shoulderR.y) / 2);
    ctx.stroke();

    // Shoulders
    ctx.beginPath();
    ctx.moveTo(shoulderL.x, shoulderL.y);
    ctx.lineTo(shoulderR.x, shoulderR.y);
    ctx.stroke();

    // Arms
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(shoulderL.x, shoulderL.y);
    ctx.lineTo(elbowL.x, elbowL.y);
    ctx.lineTo(handL.x, handL.y);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(shoulderR.x, shoulderR.y);
    ctx.lineTo(elbowR.x, elbowR.y);
    ctx.lineTo(handR.x, handR.y);
    ctx.stroke();

    // Joint Spheres
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(handL.x, handL.y, 6, 0, Math.PI * 2);
    ctx.arc(handR.x, handR.y, 6, 0, Math.PI * 2);
    ctx.arc(head.x, head.y, 14, 0, Math.PI * 2);
    ctx.fill();
  }
}
