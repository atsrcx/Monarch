import React, { useState } from 'react';
import { Shield, Sparkles, Zap, Award, ArrowRight, UserCheck, CheckCircle2, ChevronRight, Activity } from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

export const AwakeningModal: React.FC = () => {
  const { profile, awakenHunter, closeModal, setDailyQuest } = useGameStore();

  const [step, setStep] = useState<'profile' | 'generating' | 'revealed'>('profile');
  const [name, setName] = useState<string>(profile.name || 'Alex Hunter');
  const [age, setAge] = useState<number>(profile.age || 25);
  const [weightKg, setWeightKg] = useState<number>(profile.weightKg || 75);
  const [heightCm, setHeightCm] = useState<number>(profile.heightCm || 180);
  const [experience, setExperience] = useState<'beginner' | 'intermediate' | 'advanced' | 'elite'>('intermediate');
  const [goals, setGoals] = useState<string[]>(['Standard Push-Up Mastery', 'Iron Core & Lever Base']);
  const [equipment, setEquipment] = useState<string[]>(['Bodyweight Floor', 'Pull-up Bar']);
  const [trainingFrequency, setTrainingFrequency] = useState<number>(4);
  const [limitations, setLimitations] = useState<string>('');
  const [personalDescription, setPersonalDescription] = useState<string>(
    'I want to build master calisthenics bodyweight strength, master strict lockout form, and build explosive combat conditioning.'
  );
  const [generatedPlanSummary, setGeneratedPlanSummary] = useState<any>(null);

  const GOAL_OPTIONS = [
    'Standard Push-Up Mastery',
    'Diamond & Triceps Leverage',
    'Planche Progression',
    'Muscle-Up & High Pull',
    'Handstand Balance',
    'Iron Core & Lever Base',
    'Combat Conditioning',
    'Pistol Squat Dominance'
  ];

  const EQUIPMENT_OPTIONS = [
    'Bodyweight Floor',
    'Pull-up Bar',
    'Dip Station',
    'Gymnastic Rings',
    'Resistance Bands',
    'Parallettes'
  ];

  const toggleGoal = (goal: string) => {
    soundEngine.playClick();
    if (goals.includes(goal)) {
      if (goals.length > 1) {
        setGoals(goals.filter((g) => g !== goal));
      }
    } else {
      setGoals([...goals, goal]);
    }
  };

  const toggleEquipment = (eq: string) => {
    soundEngine.playClick();
    if (equipment.includes(eq)) {
      if (equipment.length > 1) {
        setEquipment(equipment.filter((e) => e !== eq));
      }
    } else {
      setEquipment([...equipment, eq]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.playLevelUp();
    setStep('generating');

    const hunterClass = experience === 'elite'
      ? 'Monarch Strength & Leverage Master'
      : experience === 'advanced'
      ? 'Kinetic Calisthenics Specialist'
      : experience === 'intermediate'
      ? 'Dynamic Calisthenics Master'
      : 'Foundation Kinetic Athlete';

    awakenHunter(name, age, weightKg, heightCm, hunterClass);

    try {
      const response = await fetch('/api/gemini/onboarding-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          age,
          weightKg,
          heightCm,
          experience,
          goals,
          equipment,
          trainingFrequency,
          limitations,
          personalDescription,
        }),
      });

      if (response.ok) {
        const plan = await response.json();
        setGeneratedPlanSummary(plan);
        if (plan.firstDailyProtocol) {
          setDailyQuest(plan.firstDailyProtocol);
        }
      }
    } catch (err) {
      console.warn('Onboarding plan generation notice:', err);
    } finally {
      setStep('revealed');
    }
  };

  const handleFinish = () => {
    soundEngine.playLevelUp();
    closeModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/95 backdrop-blur-2xl overflow-y-auto">
      <div className="relative w-full max-w-2xl my-6 rounded-3xl bg-neutral-950 border border-neutral-800 text-white p-5 sm:p-8 space-y-6 shadow-2xl overflow-hidden">
        {/* Subtle monochrome ambient light */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full blur-3xl pointer-events-none" />

        {step === 'profile' && (
          <>
            <div className="text-center space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-mono font-bold tracking-widest uppercase">
                <Shield className="w-3.5 h-3.5 text-white" />
                MONARCH V3 ATHLETE PROFILE
              </div>
              <h2 className="text-2xl sm:text-3xl font-black font-['Orbitron'] text-white tracking-wider">
                CALISTHENICS MASTER REGISTRATION
              </h2>
              <p className="text-xs font-mono text-neutral-400 max-w-lg mx-auto leading-relaxed">
                Initialize your physical vessel and tell Monarch your personal goals to calibrate real-time AI computer vision and progressive mastery paths.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 max-h-[68vh] overflow-y-auto pr-1">
              {/* Hunter Name */}
              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 uppercase tracking-wider mb-1.5">
                  ATHLETE NAME / CALLSIGN
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex Hunter"
                  className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-white text-white font-mono text-sm focus:outline-none"
                />
              </div>

              {/* Physical Metrics */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-mono text-neutral-400 uppercase mb-1">
                    AGE
                  </label>
                  <input
                    type="number"
                    min="12"
                    max="90"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="w-full py-2 px-3 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-white text-white font-mono text-sm focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-neutral-400 uppercase mb-1">
                    WEIGHT (KG)
                  </label>
                  <input
                    type="number"
                    min="35"
                    max="250"
                    value={weightKg}
                    onChange={(e) => setWeightKg(Number(e.target.value))}
                    className="w-full py-2 px-3 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-white text-white font-mono text-sm focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-neutral-400 uppercase mb-1">
                    HEIGHT (CM)
                  </label>
                  <input
                    type="number"
                    min="100"
                    max="250"
                    value={heightCm}
                    onChange={(e) => setHeightCm(Number(e.target.value))}
                    className="w-full py-2 px-3 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-white text-white font-mono text-sm focus:outline-none"
                  />
                </div>
              </div>

              {/* Experience Level */}
              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 uppercase tracking-wider mb-1.5">
                  EXPERIENCE LEVEL
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['beginner', 'intermediate', 'advanced', 'elite'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setExperience(lvl)}
                      className={`py-2 px-2.5 rounded-xl border text-center font-mono text-xs capitalize transition-all cursor-pointer ${
                        experience === lvl
                          ? 'bg-white text-black font-bold border-white'
                          : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Primary Goals */}
              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 uppercase tracking-wider mb-1.5">
                  PRIMARY CALISTHENICS GOALS (SELECT MULTIPLE)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {GOAL_OPTIONS.map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => toggleGoal(g)}
                      className={`p-2.5 rounded-xl text-left border font-mono text-xs transition-all cursor-pointer flex items-center justify-between ${
                        goals.includes(g)
                          ? 'bg-white text-black font-bold border-white'
                          : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span>{g}</span>
                      {goals.includes(g) && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Equipment */}
              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 uppercase tracking-wider mb-1.5">
                  AVAILABLE APPARATUS & EQUIPMENT
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {EQUIPMENT_OPTIONS.map((eq) => (
                    <button
                      key={eq}
                      type="button"
                      onClick={() => toggleEquipment(eq)}
                      className={`p-2 rounded-xl text-left border font-mono text-xs transition-all cursor-pointer flex items-center justify-between ${
                        equipment.includes(eq)
                          ? 'bg-white text-black font-bold border-white'
                          : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span>{eq}</span>
                      {equipment.includes(eq) && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Frequency */}
              <div>
                <div className="flex justify-between text-xs font-mono font-bold text-neutral-300 mb-1.5">
                  <span>TRAINING FREQUENCY</span>
                  <span className="text-white">{trainingFrequency} DAYS / WEEK</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="6"
                  value={trainingFrequency}
                  onChange={(e) => setTrainingFrequency(Number(e.target.value))}
                  className="w-full accent-white"
                />
              </div>

              {/* Tell Monarch About Yourself */}
              <div>
                <label className="block text-xs font-mono font-bold text-neutral-300 uppercase tracking-wider mb-1.5">
                  TELL MONARCH ABOUT YOURSELF (BACKGROUND & INJURIES)
                </label>
                <textarea
                  rows={3}
                  value={personalDescription}
                  onChange={(e) => setPersonalDescription(e.target.value)}
                  placeholder="Describe your athletic background, current max pushups, joint considerations, or what you want to achieve..."
                  className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 focus:border-white text-white font-mono text-xs focus:outline-none resize-none leading-relaxed"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-2xl font-mono font-bold text-sm tracking-wider bg-white text-black hover:bg-neutral-200 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl mt-4"
              >
                <UserCheck className="w-4 h-4 text-black" />
                CALIBRATE MONARCH MASTER PLAN
              </button>
            </form>
          </>
        )}

        {step === 'generating' && (
          <div className="py-12 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full border-2 border-white/20 border-t-white animate-spin" />
            <h3 className="text-lg font-black font-['Orbitron'] text-white">CALIBRATING BIOMECHANICAL PROFILE</h3>
            <p className="text-xs font-mono text-neutral-400 max-w-sm mx-auto">
              Monarch AI Coach is analyzing your vessel leverage metrics, target skills, and creating your progression pathway...
            </p>
          </div>
        )}

        {step === 'revealed' && (
          <div className="space-y-5">
            <div className="text-center space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white text-black text-xs font-mono font-bold tracking-widest uppercase">
                <CheckCircle2 className="w-3.5 h-3.5" />
                CALIBRATION COMPLETE
              </div>
              <h3 className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white">
                {generatedPlanSummary?.hunterTitle || `${name.toUpperCase()} — THE AWAKENED ATHLETE`}
              </h3>
              <p className="text-xs font-mono text-neutral-400">
                {generatedPlanSummary?.hunterArchetype || 'Dynamic Calisthenics Master'}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 text-xs font-mono">
              <div>
                <span className="text-neutral-500 uppercase">BIOMETRIC ASSESSMENT:</span>
                <p className="text-neutral-200 mt-0.5 leading-relaxed">
                  {generatedPlanSummary?.biometricAnalysis || `Calibrated for ${weightKg}kg mass and ${heightCm}cm leverage profile.`}
                </p>
              </div>

              <div>
                <span className="text-neutral-500 uppercase">PROGRESSION STRATEGY:</span>
                <p className="text-neutral-200 mt-0.5 leading-relaxed">
                  {generatedPlanSummary?.personalizedStrategy || `Focusing on ${goals.join(', ')} with progressive overload.`}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-neutral-800">
                <div>
                  <span className="text-neutral-500 text-[10px] uppercase">TARGET KEY SKILL:</span>
                  <div className="font-bold text-white mt-0.5">{generatedPlanSummary?.targetKeySkill || 'Push-Up 45° Arrowhead'}</div>
                </div>
                <div>
                  <span className="text-neutral-500 text-[10px] uppercase">RECOMMENDED CADENCE:</span>
                  <div className="font-bold text-white mt-0.5">{generatedPlanSummary?.recommendedWeeklyCadence || `${trainingFrequency} days/week`}</div>
                </div>
              </div>
            </div>

            <button
              onClick={handleFinish}
              className="w-full py-3.5 px-6 rounded-2xl font-mono font-bold text-sm tracking-wider bg-white text-black hover:bg-neutral-200 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
            >
              <span>ENTER MONARCH DASHBOARD</span>
              <ChevronRight className="w-4 h-4 text-black" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AwakeningModal;
