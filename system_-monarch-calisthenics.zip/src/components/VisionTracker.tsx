import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Camera,
  RotateCcw,
  Volume2,
  VolumeX,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Zap,
  ArrowLeft,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  Layers,
  Activity,
  Maximize2,
  Bot,
  Compass,
  Sliders,
  ChevronDown,
  Info,
  Award,
  Vibrate,
  Ghost,
  BarChart3,
  Check,
  X,
  Radio,
  Clock,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { useGameStore, RepQualityEntry } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';
import { aiTts } from '../utils/aiTtsEngine';
import {
  CalisthenicsFormTracker,
  drawCyberpunkSkeleton,
  FormAnalysisResult,
  ExerciseType,
  Landmark,
  RepPhase,
  BoneFlawMap,
  FormBreakdown,
  getExerciseDefinition,
  ExerciseDefinition,
} from '../utils/calisthenicsVisionMath';
import { ExerciseDemonstrator, DemoExerciseType } from './ExerciseDemonstrator';
import { indexedDbService } from '../utils/indexedDbService';

interface VisionTrackerProps {
  onClose?: () => void;
  overrideExerciseId?: string;
}

interface ParticleXP {
  id: number;
  x: number;
  y: number;
  text: string;
}

const EXERCISE_OPTIONS: { id: ExerciseType; label: string; sub: string; category: string; tier: string }[] = [
  { id: 'pushup', label: 'Push-Up', sub: '45° Arrowhead Standard', category: 'Chest/Arms', tier: 'T1' },
  { id: 'diamond_pushup', label: 'Diamond Push-Up', sub: 'Close Hand Stance (◇)', category: 'Triceps/Chest', tier: 'T2' },
  { id: 'wide_pushup', label: 'Wide Push-Up', sub: '1.4× Stance Pectoral Bias', category: 'Chest', tier: 'T2' },
  { id: 'archer_pushup', label: 'Archer Push-Up', sub: 'Unilateral Working & Assist Arm', category: 'Chest/Arms', tier: 'T3' },
  { id: 'pike_pushup', label: 'Pike Push-Up', sub: 'Inverted V Shoulder Press', category: 'Shoulders', tier: 'T2' },
  { id: 'handstand_pushup', label: 'Handstand Push-Up', sub: 'Vertical Inversion Press', category: 'Shoulders', tier: 'T4' },
  { id: 'squat', label: 'Deep Squat', sub: '85° Depth • Upright Torso', category: 'Legs', tier: 'T1' },
  { id: 'pistol_squat', label: 'Pistol Squat', sub: 'Single Leg Isolation Depth', category: 'Legs', tier: 'T3' },
  { id: 'plank', label: 'Iron Plank', sub: 'Rigid Core Isometric Hold', category: 'Core', tier: 'T1' },
  { id: 'planche_lean', label: 'Planche Lean', sub: 'Forward Lean & Straight Arms', category: 'Shoulders/Core', tier: 'T3' },
  { id: 'lsit', label: 'L-Sit Hold', sub: '90° Hip Compression & Lockout', category: 'Core/Triceps', tier: 'T3' },
  { id: 'lunge', label: 'Lunge', sub: '90° Knee Flexion Stride', category: 'Legs', tier: 'T1' },
];

export const VisionTracker: React.FC<VisionTrackerProps> = ({ onClose, overrideExerciseId }) => {
  const {
    profile,
    currentQuest,
    completedSetsMap,
    cameraFacingMode,
    showSkeleton,
    antiCheatEnabled,
    visionHudMode,
    showGhostTrainer,
    showMotionTrails,
    showJointArcs,
    showMovementVectors,
    showTargetZones,
    landmarkConfidenceThreshold,
    smoothingAlpha,
    sessionRepQualityLog,
    isMuted,
    ttsEnabled,
    setCameraFacingMode,
    toggleSkeleton,
    toggleAntiCheat,
    setVisionHudMode,
    toggleGhostTrainer,
    toggleMotionTrails,
    toggleJointArcs,
    toggleMovementVectors,
    toggleTargetZones,
    toggleMute,
    toggleTts,
    recordRep,
    completeSet,
    startRestTimer,
  } = useGameStore();

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const trackerRef = useRef<CalisthenicsFormTracker>(new CalisthenicsFormTracker(160, 85));
  const poseDetectorRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const isMountedRef = useRef<boolean>(true);
  const sessionIdRef = useRef<number>(0);

  // States
  const [cameraState, setCameraState] = useState<'idle' | 'requesting' | 'running' | 'error' | 'simulation'>('idle');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [fps, setFps] = useState<number>(0);
  const [latencyMs, setLatencyMs] = useState<number>(14);
  const [repCount, setRepCount] = useState<number>(0);
  const [showPipGuide, setShowPipGuide] = useState<boolean>(false);
  const [showFormBreakdownModal, setShowFormBreakdownModal] = useState<boolean>(false);
  const [showExerciseDropdown, setShowExerciseDropdown] = useState<boolean>(false);
  const [showQuickSettings, setShowQuickSettings] = useState<boolean>(false);
  const [showDebug, setShowDebug] = useState<boolean>(false);
  const [particles, setParticles] = useState<ParticleXP[]>([]);

  // Calibration Countdown
  const [calibrationCountdown, setCalibrationCountdown] = useState<number | null>(null);
  const [isWorkoutActive, setIsWorkoutActive] = useState<boolean>(false);

  // Manual selected exercise override
  const [selectedExercise, setSelectedExercise] = useState<ExerciseType>('pushup');

  const defaultFlaws: BoneFlawMap = {
    spine: false,
    leftUpperArm: false,
    rightUpperArm: false,
    leftForearm: false,
    rightForearm: false,
    wrists: false,
    leftThigh: false,
    rightThigh: false,
    leftShin: false,
    rightShin: false,
    hips: false,
    neck: false,
  };

  const defaultBreakdown: FormBreakdown = {
    alignmentScore: 95,
    elbowScore: 98,
    depthScore: 92,
    handScore: 96,
    symmetryScore: 94,
    primaryIssue: 'None - Strict Form',
    whyExplanation: 'Torso spinal alignment and 45° elbow tuck maximize chest recruitment while protecting shoulder joint capsule.',
    howToFixCue: 'Maintain steady 2-second descent and explode up through mid-palm.',
  };

  const [analysisResult, setAnalysisResult] = useState<FormAnalysisResult>({
    primaryAngle: 180,
    secondaryAngle: 180,
    repPhase: 'LOCKED_UP',
    repCount: 0,
    feedbackText: 'ALIGN IN FRAME',
    feedbackSeverity: 'info',
    depthPercentage: 0,
    formScore: 95,
    formGrade: 'S',
    isCheatDetected: false,
    isBottomTriggered: false,
    isRepCountedTriggered: false,
    holdDurationMs: 0,
    spineAngle: 180,
    isSpineAligned: true,
    visibilityScore: 0,
    isBodyInFrame: true,
    isElbowTucked: true,
    elbowSpineProjection: 0.1,
    handPlacement: {
      ratio: 1.1,
      idealMin: 0.8,
      idealMax: 1.35,
      status: 'valid',
      cueText: 'HAND PLACEMENT NOMINAL',
    },
    movementVector: 'DESCEND',
    boneFlaws: defaultFlaws,
    fatigueWarning: false,
    formBreakdown: defaultBreakdown,
  });

  // Current active exercise from quest or override
  const questExercise = overrideExerciseId
    ? currentQuest.exercises.find((e) => e.id === overrideExerciseId) || currentQuest.exercises[0]
    : currentQuest.exercises[0];

  const currentCompletedSets = completedSetsMap[questExercise?.id || ''] || 0;
  const currentSetNum = Math.min(questExercise?.sets || 3, currentCompletedSets + 1);

  // Initialize selected exercise from quest on mount
  useEffect(() => {
    if (questExercise) {
      if (questExercise.id.includes('diamond')) setSelectedExercise('diamond_pushup');
      else if (questExercise.id.includes('wide')) setSelectedExercise('wide_pushup');
      else if (questExercise.id.includes('pike')) setSelectedExercise('pike_pushup');
      else if (questExercise.id.includes('pistol')) setSelectedExercise('pistol_squat');
      else if (questExercise.id.includes('squat') || questExercise.category === 'legs') setSelectedExercise('squat');
      else if (questExercise.id.includes('plank') || questExercise.category === 'core') setSelectedExercise('plank');
      else if (questExercise.id.includes('lunge')) setSelectedExercise('lunge');
      else setSelectedExercise('pushup');
    }
  }, [questExercise]);

  // Reset VisionTracker workout state when the selected exercise changes
  useEffect(() => {
    setIsWorkoutActive(false);
    setCalibrationCountdown(null);
    trackerRef.current.reset(0);
    setRepCount(0);
  }, [selectedExercise]);

  const demoType: DemoExerciseType =
    selectedExercise === 'diamond_pushup'
      ? 'pushup_diamond'
      : selectedExercise === 'wide_pushup' || selectedExercise === 'pike_pushup'
      ? 'pushup_standard'
      : selectedExercise === 'pistol_squat'
      ? 'squat_pistol'
      : selectedExercise === 'squat'
      ? 'squat_deep'
      : selectedExercise === 'plank'
      ? 'plank_iron'
      : 'pushup_standard';

  // Synchronize dynamic refs
  const selectedExerciseRef = useRef(selectedExercise);
  selectedExerciseRef.current = selectedExercise;

  const antiCheatEnabledRef = useRef(antiCheatEnabled);
  antiCheatEnabledRef.current = antiCheatEnabled;

  const showSkeletonRef = useRef(showSkeleton);
  showSkeletonRef.current = showSkeleton;

  const showGhostTrainerRef = useRef(showGhostTrainer);
  showGhostTrainerRef.current = showGhostTrainer;

  const showMotionTrailsRef = useRef(showMotionTrails);
  showMotionTrailsRef.current = showMotionTrails;

  const showJointArcsRef = useRef(showJointArcs);
  showJointArcsRef.current = showJointArcs;

  const showMovementVectorsRef = useRef(showMovementVectors);
  showMovementVectorsRef.current = showMovementVectors;

  const showTargetZonesRef = useRef(showTargetZones);
  showTargetZonesRef.current = showTargetZones;

  const landmarkConfidenceThresholdRef = useRef(landmarkConfidenceThreshold);
  landmarkConfidenceThresholdRef.current = landmarkConfidenceThreshold;

  const recordRepRef = useRef(recordRep);
  recordRepRef.current = recordRep;

  // Haptic feedback utility
  const triggerHaptic = useCallback((pattern: number | number[]) => {
    if (typeof window !== 'undefined' && 'navigator' in window && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch (e) {}
    }
  }, []);

  // Trigger floating XP Particle
  const spawnXpParticle = useCallback((text = '+10 XP') => {
    const newId = Date.now() + Math.random();
    setParticles((prev) => [...prev, { id: newId, x: 50 + (Math.random() * 20 - 10), y: 45, text }]);
    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => p.id !== newId));
    }, 1200);
  }, []);

  // Calibration sequence trigger
  useEffect(() => {
    if (!analysisResult.visionQuality?.isCalibrated && calibrationCountdown !== null && !isWorkoutActive) {
      // If we lose calibration during countdown, reset it
      setCalibrationCountdown(null);
      return;
    }

    if (analysisResult.visionQuality?.isCalibrated && !isWorkoutActive && calibrationCountdown === null) {
      setCalibrationCountdown(3);
      aiTts.speak('Vision calibrated. Stand by. Three, two, one, begin!', false);

      const interval = setInterval(() => {
        setCalibrationCountdown((prev) => {
          if (prev === null) return null;
          if (prev <= 1) {
            clearInterval(interval);
            setIsWorkoutActive(true);
            soundEngine.playLevelUp();
            return null;
          }
          soundEngine.playClick();
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [analysisResult.visionQuality?.isCalibrated, isWorkoutActive, calibrationCountdown]);

  // Initialize MediaPipe Pose detector
  const initMediaPipePose = useCallback(async () => {
    try {
      if (poseDetectorRef.current) {
        return poseDetectorRef.current;
      }

      if (!(window as any).Pose) {
        await new Promise<void>((resolve, reject) => {
          const existingScript = document.querySelector('script[src*="mediapipe/pose"]');
          if (existingScript) {
            existingScript.addEventListener('load', () => resolve());
            existingScript.addEventListener('error', () => reject(new Error('Failed to load MediaPipe script')));
            return;
          }
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js';
          script.crossOrigin = 'anonymous';
          script.onload = () => resolve();
          script.onerror = () => reject(new Error('Failed to load MediaPipe Pose engine script'));
          document.head.appendChild(script);
        });
      }

      const PoseClass = (window as any).Pose;
      if (!PoseClass) throw new Error('Pose detector not found in window context');

      const pose = new PoseClass({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`,
      });

      pose.setOptions({
        modelComplexity: 1,
        smoothLandmarks: true,
        enableSegmentation: false,
        smoothSegmentation: false,
        minDetectionConfidence: 0.55,
        minTrackingConfidence: 0.55,
      });

      pose.onResults((results: any) => {
        if (!canvasRef.current || !videoRef.current || !isMountedRef.current) return;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const width = canvas.width;
        const height = canvas.height;

        const currentVisionType = selectedExerciseRef.current;
        const currentAntiCheat = antiCheatEnabledRef.current;

        if (results.poseLandmarks && results.poseLandmarks.length >= 33) {
          // Sub-Pixel 2nd-Order EMA Smoothing & Biomechanical Form Evaluation
          const analysis = trackerRef.current.analyzeFrame(
            results.poseLandmarks,
            currentVisionType,
            currentAntiCheat,
            landmarkConfidenceThresholdRef.current
          );

          setAnalysisResult(analysis);
          setRepCount(analysis.repCount);

          // 1. Spoken Biomechanical Voice Coach
          if (analysis.flawType) {
            aiTts.reportBiomechanicsFlaw(analysis.flawType, true);
          } else {
            aiTts.reportBiomechanicsFlaw('waist_sagging', false);
            aiTts.reportBiomechanicsFlaw('shallow_depth', false);
            aiTts.reportBiomechanicsFlaw('flared_elbows', false);
            aiTts.reportBiomechanicsFlaw('hand_width', false);
            aiTts.reportBiomechanicsFlaw('squat_shallow', false);
            aiTts.reportBiomechanicsFlaw('plank_sagging', false);
          }

          // 2. Phase 2: CHEST_DEPTH_REACHED -> Audio ping & subtle haptic
          if (analysis.isBottomTriggered) {
            soundEngine.playBottomValid();
            triggerHaptic(35);
          }

          // 3. Phase 4: REP_VALIDATED -> Audio chime + Voice rep callout + Haptic burst
          if (analysis.isRepCountedTriggered) {
            soundEngine.playRepCounted();
            triggerHaptic([40, 60, 40]);
            spawnXpParticle(`+${questExercise?.xpPerRep || 10} XP`);
            aiTts.speakRepCount(analysis.repCount, questExercise?.repsPerSet || 15);

            const repEntry: RepQualityEntry = {
              repIndex: analysis.repCount,
              qualityScore: analysis.formScore,
              grade: analysis.formScore >= 95 ? 'PERFECT' : analysis.formScore >= 80 ? 'GOOD' : 'FLAW',
              depthAngle: analysis.primaryAngle,
              alignmentAngle: analysis.spineAngle,
              flawNote: analysis.flawType || (analysis.isCheatDetected ? analysis.cheatReason : undefined),
              timestamp: Date.now(),
            };

            if (questExercise?.id) {
              recordRepRef.current(questExercise.id, repEntry);
            }
          }

          // 4. Render 3D Holographic Skeletal Overlay with Ghost Trainer & Motion Trails
          drawCyberpunkSkeleton(
            ctx,
            results.poseLandmarks,
            width,
            height,
            analysis,
            currentVisionType,
            {
              showSkeleton: showSkeletonRef.current,
              showGhostTrainer: showGhostTrainerRef.current,
              showMotionTrails: showMotionTrailsRef.current,
              showJointArcs: showJointArcsRef.current,
              showMovementVectors: showMovementVectorsRef.current,
              showTargetZones: showTargetZonesRef.current,
            }
          );
        } else {
          ctx.clearRect(0, 0, width, height);
          setAnalysisResult((prev) => ({
            ...prev,
            feedbackText: 'POSITION FULL BODY IN FRAME',
            feedbackSeverity: 'warning',
            isBodyInFrame: false,
          }));
        }
      });

      poseDetectorRef.current = pose;
      return pose;
    } catch (err) {
      console.warn('Could not initialize MediaPipe Pose via CDN, fallback simulator available:', err);
      return null;
    }
  }, [spawnXpParticle, triggerHaptic, questExercise]);

  // Safe camera stream terminator
  const stopCameraStream = useCallback(() => {
    sessionIdRef.current++;
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (e) {}
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      try {
        videoRef.current.pause();
        videoRef.current.srcObject = null;
      } catch (e) {}
    }
  }, []);

  // Start device camera
  const startCamera = useCallback(async () => {
    stopCameraStream();
    const currentSession = ++sessionIdRef.current;

    setCameraState('requesting');
    setCameraError(null);

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: cameraFacingMode,
          width: { ideal: 1280, min: 640 },
          height: { ideal: 720, min: 480 },
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);

      if (!isMountedRef.current || currentSession !== sessionIdRef.current) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
        videoRef.current.playsInline = true;

        try {
          const playPromise = videoRef.current.play();
          if (playPromise !== undefined) {
            await playPromise;
          }
        } catch (playErr: any) {
          if (
            playErr.name === 'AbortError' ||
            playErr.message?.includes('interrupted') ||
            !isMountedRef.current ||
            currentSession !== sessionIdRef.current
          ) {
            return;
          }
          throw playErr;
        }
      }

      if (!isMountedRef.current || currentSession !== sessionIdRef.current) {
        return;
      }

      setCameraState('running');

      let detector = poseDetectorRef.current;
      if (!detector) {
        detector = await initMediaPipePose();
      }

      // Video frame processing loop
      let lastTime = performance.now();
      let frameCount = 0;

      const processFrame = async () => {
        if (!isMountedRef.current || currentSession !== sessionIdRef.current) {
          return;
        }

        if (!videoRef.current || videoRef.current.paused || videoRef.current.ended) {
          animFrameIdRef.current = requestAnimationFrame(processFrame);
          return;
        }

        const now = performance.now();
        frameCount++;
        if (now - lastTime >= 1000) {
          setFps(frameCount);
          frameCount = 0;
          lastTime = now;
        }

        if (poseDetectorRef.current && videoRef.current.readyState >= 2) {
          const sendStart = performance.now();
          try {
            await poseDetectorRef.current.send({ image: videoRef.current });
            setLatencyMs(Math.round(performance.now() - sendStart));
          } catch (e) {}
        }

        if (isMountedRef.current && currentSession === sessionIdRef.current) {
          animFrameIdRef.current = requestAnimationFrame(processFrame);
        }
      };

      animFrameIdRef.current = requestAnimationFrame(processFrame);
    } catch (err: any) {
      if (!isMountedRef.current || currentSession !== sessionIdRef.current) {
        return;
      }
      if (err.name === 'AbortError' || err.message?.includes('interrupted')) {
        return;
      }

      console.error('Camera Access Error:', err);
      setCameraState('error');
      setCameraError(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'Camera permission denied. Please allow camera access in browser settings or switch to Simulator.'
          : 'Unable to connect to camera. Device may be in use by another application.'
      );
    }
  }, [cameraFacingMode, initMediaPipePose, stopCameraStream]);

  // Fallback Simulation Mode
  const startSimulationMode = () => {
    setCameraState('simulation');
    setCameraError(null);

    let simProgress = 0;
    let lastTime = performance.now();
    let simReps = 0;
    let bottomPlayed = false;

    const runSimLoop = () => {
      const now = performance.now();
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      simProgress += delta * 2.1;
      const wave = (Math.sin(simProgress) + 1) / 2;
      const currentAngle = Math.round(75 + wave * (165 - 75));

      const isBottom = currentAngle <= 85;
      const isTop = currentAngle >= 155;

      if (isBottom && !bottomPlayed) {
        bottomPlayed = true;
        soundEngine.playBottomValid();
      }

      if (isTop && bottomPlayed) {
        bottomPlayed = false;
        simReps++;
        setRepCount(simReps);
        soundEngine.playRepCounted();
        spawnXpParticle(`+${questExercise?.xpPerRep || 10} XP`);
        aiTts.speakRepCount(simReps, questExercise?.repsPerSet || 15);
        const simRepEntry: RepQualityEntry = {
          repIndex: simReps,
          qualityScore: 96,
          grade: 'PERFECT',
          depthAngle: currentAngle,
          alignmentAngle: 175,
          timestamp: Date.now(),
        };
        if (questExercise?.id) {
          recordRep(questExercise.id, simRepEntry);
        }
      }

      const depthPct = Math.max(0, Math.min(100, Math.round(((165 - currentAngle) / (165 - 75)) * 100)));

      const simAnalysis: FormAnalysisResult = {
        primaryAngle: currentAngle,
        secondaryAngle: 175,
        repPhase: isBottom ? 'CHEST_DEPTH_REACHED' : isTop ? 'LOCKED_UP' : 'DESCENDING',
        repCount: simReps,
        feedbackText: isBottom
          ? 'PEAK DEPTH (<85°): DRIVE UP'
          : isTop
          ? 'LOCKOUT (>160°): READY'
          : 'SMOOTH KINETIC PACE',
        feedbackSeverity: isBottom ? 'success' : 'info',
        depthPercentage: depthPct,
        formScore: 96,
        formGrade: 'S',
        isCheatDetected: false,
        isBottomTriggered: isBottom,
        isRepCountedTriggered: isTop && bottomPlayed,
        holdDurationMs: isBottom ? 120 : 0,
        spineAngle: 175,
        isSpineAligned: true,
        visibilityScore: 0.98,
        isBodyInFrame: true,
        isElbowTucked: true,
        elbowSpineProjection: 0.1,
        handPlacement: {
          ratio: selectedExercise === 'diamond_pushup' ? 0.35 : 1.15,
          idealMin: selectedExercise === 'diamond_pushup' ? 0.15 : 0.75,
          idealMax: selectedExercise === 'diamond_pushup' ? 0.55 : 1.35,
          status: 'valid',
          cueText: selectedExercise === 'diamond_pushup' ? 'DIAMOND PLACEMENT NOMINAL' : 'HAND PLACEMENT NOMINAL',
        },
        movementVector: isBottom ? 'DRIVE' : 'DESCEND',
        boneFlaws: defaultFlaws,
        fatigueWarning: false,
        ghostMatch: {
          ghostLandmarks: [],
          matchScore: 96,
          isAligned: true,
          statusText: 'GHOST MATCH: 96%',
        },
        formBreakdown: defaultBreakdown,
        visionQuality: {
          status: 'READY',
          confidenceScore: 98,
          framingMessage: 'OPTIMAL FRAMING',
          lightingQuality: 'OPTIMAL',
          isCalibrated: true,
        },
      };

      setAnalysisResult(simAnalysis);

      if (canvasRef.current) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          const w = canvas.width;
          const h = canvas.height;

          const depthOffset = (1 - wave) * 45;
          const mockLandmarks: Landmark[] = new Array(33).fill({ x: 0.5, y: 0.5, visibility: 0.95 });
          mockLandmarks[11] = { x: 0.35, y: 0.52 + depthOffset / h, visibility: 0.95, z: 0.1 };
          mockLandmarks[12] = { x: 0.42, y: 0.50 + depthOffset / h, visibility: 0.95, z: 0.2 };
          mockLandmarks[13] = { x: 0.38, y: 0.63, visibility: 0.95, z: 0.05 };
          mockLandmarks[14] = { x: 0.45, y: 0.61, visibility: 0.95, z: 0.15 };
          mockLandmarks[15] = { x: 0.38, y: 0.76, visibility: 0.95, z: 0.0 };
          mockLandmarks[16] = { x: 0.48, y: 0.74, visibility: 0.95, z: 0.1 };
          mockLandmarks[23] = { x: 0.60, y: 0.55 + depthOffset / (h * 1.5), visibility: 0.95, z: 0.1 };
          mockLandmarks[24] = { x: 0.65, y: 0.53 + depthOffset / (h * 1.5), visibility: 0.95, z: 0.2 };
          mockLandmarks[25] = { x: 0.75, y: 0.65, visibility: 0.95, z: 0.1 };
          mockLandmarks[26] = { x: 0.80, y: 0.63, visibility: 0.95, z: 0.2 };
          mockLandmarks[27] = { x: 0.88, y: 0.75, visibility: 0.95, z: 0.1 };
          mockLandmarks[28] = { x: 0.92, y: 0.73, visibility: 0.95, z: 0.2 };

          drawCyberpunkSkeleton(
            ctx,
            mockLandmarks,
            w,
            h,
            simAnalysis,
            selectedExerciseRef.current,
            {
              showSkeleton: showSkeletonRef.current,
              showGhostTrainer: showGhostTrainerRef.current,
              showMotionTrails: showMotionTrailsRef.current,
              showJointArcs: showJointArcsRef.current,
              showMovementVectors: showMovementVectorsRef.current,
              showTargetZones: showTargetZonesRef.current,
            }
          );
        }
      }

      animFrameIdRef.current = requestAnimationFrame(runSimLoop);
    };

    animFrameIdRef.current = requestAnimationFrame(runSimLoop);
  };

  // Reset tracker state and load exercise definition when exercise changes
  useEffect(() => {
    const def = getExerciseDefinition(selectedExercise);
    trackerRef.current.setExercise(selectedExercise);
    setRepCount(0);
    
    // Clear and initialize fresh exercise-specific analysis state
    setAnalysisResult({
      primaryAngle: def.angleRanges.lockoutMinAngle,
      secondaryAngle: 180,
      repPhase: 'LOCKED_UP',
      repCount: 0,
      feedbackText: def.correctionMessages.lockoutCue,
      feedbackSeverity: 'info',
      depthPercentage: 0,
      formScore: 100,
      formGrade: 'S',
      isCheatDetected: false,
      isBottomTriggered: false,
      isRepCountedTriggered: false,
      holdDurationMs: 0,
      spineAngle: 180,
      isSpineAligned: true,
      visibilityScore: 1.0,
      isBodyInFrame: true,
      isElbowTucked: true,
      elbowSpineProjection: 0.1,
      handPlacement: {
        ratio: 1.0,
        idealMin: def.placementRules.idealRatioMin,
        idealMax: def.placementRules.idealRatioMax,
        status: 'valid',
        cueText: def.placementRules.description,
      },
      movementVector: (def.isIsometric || def.isHoldExercise) ? 'HOLD' : 'DESCEND',
      boneFlaws: defaultFlaws,
      fatigueWarning: false,
      exerciseDefinition: def,
      primaryAngleName: def.angleRanges.primaryJointName,
      secondaryAngleName: def.angleRanges.secondaryJointName,
      cameraAdviceText: def.cameraAngleAdvice,
      placementStatusText: def.placementRules.description,
      currentExerciseName: def.name,
      formBreakdown: {
        alignmentScore: 98,
        elbowScore: 98,
        depthScore: 95,
        handScore: 98,
        symmetryScore: 96,
        primaryIssue: `Nominal Form (${def.name})`,
        whyExplanation: def.postureRules.map((r) => r.instruction || r.rule || r.title).join(' • '),
        howToFixCue: def.correctionMessages.lockoutCue,
      },
    });

    soundEngine.playClick();
    if (ttsEnabled) {
      aiTts.speak(`${def.name}. ${def.cameraAngleAdvice}`);
    }
  }, [selectedExercise, ttsEnabled]);

  // Start camera on mount
  useEffect(() => {
    isMountedRef.current = true;
    startCamera();

    return () => {
      isMountedRef.current = false;
      stopCameraStream();
    };
  }, [startCamera, stopCameraStream]);

  // Complete current set
  const handleFinishSet = () => {
    if (!questExercise) return;
    const finalReps = repCount || questExercise.repsPerSet;
    completeSet(questExercise.id, finalReps, analysisResult.formScore);

    indexedDbService.saveWorkoutLog({
      id: `set-${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      timestamp: Date.now(),
      exerciseName: EXERCISE_OPTIONS.find((e) => e.id === selectedExercise)?.label || questExercise.name,
      completedReps: finalReps,
      targetReps: questExercise.repsPerSet,
      completionRate: Math.min(1.0, finalReps / Math.max(1, questExercise.repsPerSet)),
      accuracyScore: analysisResult.formScore,
      xpEarned: finalReps * (questExercise.xpPerRep || 10) + 25,
      flawsDetected: analysisResult.isCheatDetected ? [analysisResult.cheatReason || 'Form Flaw'] : [],
    });

    trackerRef.current.reset(0);
    setRepCount(0);
    startRestTimer(questExercise.restSeconds || 45);
  };

  const isFormFlaw = analysisResult.feedbackSeverity === 'warning' || analysisResult.feedbackSeverity === 'error' || analysisResult.isCheatDetected;
  const isDepthValid = analysisResult.repPhase === 'CHEST_DEPTH_REACHED';
  const isRepSuccess = analysisResult.repPhase === 'REP_VALIDATED';

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full min-h-[600px] flex flex-col bg-[#050505] text-neutral-100 overflow-hidden select-none"
    >
      {/* Top Cinematic Minimalist HUD Bar */}
      <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between p-3 sm:p-4 bg-gradient-to-b from-black/95 via-black/75 to-transparent backdrop-blur-md border-b border-white/10">
        <div className="flex items-center gap-2 sm:gap-3">
          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-300 hover:text-white hover:border-white/40 transition-all cursor-pointer"
              title="Return to Hub"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}

          {/* Exercise Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowExerciseDropdown(!showExerciseDropdown)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-neutral-900/90 border border-neutral-700 hover:border-cyan-400/60 transition-all cursor-pointer text-left"
            >
              <div>
                <div className="text-[9px] font-mono font-bold text-white uppercase tracking-widest flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  {cameraState === 'simulation' ? 'SIMULATION' : `${fps} FPS • ${latencyMs}ms`}
                </div>
                <h2 className="text-xs sm:text-sm font-black font-['Orbitron'] text-white tracking-wide flex items-center gap-1.5">
                  {EXERCISE_OPTIONS.find((e) => e.id === selectedExercise)?.label}
                  <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
                </h2>
              </div>
            </button>

            {/* Dropdown Menu */}
            {showExerciseDropdown && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-neutral-950/95 border border-neutral-800 rounded-2xl p-1.5 shadow-2xl z-50 backdrop-blur-xl space-y-1">
                {EXERCISE_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      setSelectedExercise(opt.id);
                      setShowExerciseDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer flex flex-col ${
                      selectedExercise === opt.id
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-300 hover:bg-neutral-900 hover:text-white'
                    }`}
                  >
                    <span>{opt.label}</span>
                    <span className={`text-[10px] ${selectedExercise === opt.id ? 'text-neutral-700' : 'text-neutral-500'}`}>
                      {opt.sub}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Coach vs Analyst Mode Toggle Switch */}
          <div className="flex items-center rounded-xl bg-neutral-900 border border-neutral-800 p-0.5">
            <button
              onClick={() => setVisionHudMode('coach')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold tracking-wider transition-all cursor-pointer ${
                visionHudMode === 'coach'
                  ? 'bg-white text-black shadow-lg font-bold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              COACH
            </button>
            <button
              onClick={() => setVisionHudMode('analyst')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold tracking-wider transition-all cursor-pointer ${
                visionHudMode === 'analyst'
                  ? 'bg-white text-black shadow-lg font-bold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              ANALYST
            </button>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Ghost Trainer Toggle */}
          <button
            onClick={toggleGhostTrainer}
            className={`p-2 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-1 ${
              showGhostTrainer
                ? 'bg-white text-black border-white'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-white'
            }`}
            title="Toggle Ghost Trainer Hologram"
          >
            <Ghost className="w-4 h-4" />
          </button>

          {/* Voice Coach Toggle */}
          <button
            onClick={toggleTts}
            className={`p-2 rounded-xl border font-mono text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              ttsEnabled ? 'bg-white text-black border-white' : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-white'
            }`}
            title={ttsEnabled ? 'Voice Coach Online' : 'Voice Coach Muted'}
          >
            <Bot className="w-4 h-4" />
          </button>

          {/* PiP 3D Form Demonstrator Toggle */}
          <button
            onClick={() => setShowPipGuide(!showPipGuide)}
            className={`px-2.5 py-1.5 rounded-xl border font-mono text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              showPipGuide
                ? 'bg-white text-black border-white'
                : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
            }`}
            title="Toggle 3D Anatomical Guide"
          >
            <Layers className="w-4 h-4" />
            <span className="hidden sm:inline">GUIDE</span>
          </button>

          {/* Flip Camera */}
          <button
            onClick={() => {
              const nextMode = cameraFacingMode === 'user' ? 'environment' : 'user';
              setCameraFacingMode(nextMode);
            }}
            className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white transition-all cursor-pointer"
            title="Flip Camera"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Quick HUD Layers Drawer */}
          <div className="relative">
            <button
              onClick={() => setShowQuickSettings(!showQuickSettings)}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                showQuickSettings ? 'bg-white text-black border-white' : 'bg-neutral-900 border-neutral-800 text-neutral-400'
              }`}
              title="Vision HUD Layers & Settings"
            >
              <Sliders className="w-4 h-4" />
            </button>

            {showQuickSettings && (
              <div className="absolute right-0 top-full mt-2 w-56 bg-neutral-950/95 border border-neutral-800 rounded-2xl p-2.5 shadow-2xl z-50 backdrop-blur-xl space-y-1.5">
                <div className="text-[9px] font-mono font-bold text-neutral-400 uppercase px-2 pb-1 border-b border-neutral-800">
                  HUD LAYER CONTROLS
                </div>
                <button
                  onClick={toggleSkeleton}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Live Skeleton</span>
                  <span className={showSkeleton ? 'text-cyan-400 font-bold' : 'text-neutral-600'}>
                    {showSkeleton ? 'ON' : 'OFF'}
                  </span>
                </button>
                <button
                  onClick={toggleGhostTrainer}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Ghost Trainer</span>
                  <span className={showGhostTrainer ? 'text-cyan-400 font-bold' : 'text-neutral-600'}>
                    {showGhostTrainer ? 'ON' : 'OFF'}
                  </span>
                </button>
                <button
                  onClick={toggleMotionTrails}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Motion Trails</span>
                  <span className={showMotionTrails ? 'text-cyan-400 font-bold' : 'text-neutral-600'}>
                    {showMotionTrails ? 'ON' : 'OFF'}
                  </span>
                </button>
                <button
                  onClick={toggleJointArcs}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Joint Arcs</span>
                  <span className={showJointArcs ? 'text-cyan-400 font-bold' : 'text-neutral-600'}>
                    {showJointArcs ? 'ON' : 'OFF'}
                  </span>
                </button>
                <button
                  onClick={toggleMovementVectors}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Movement Vectors</span>
                  <span className={showMovementVectors ? 'text-cyan-400 font-bold' : 'text-neutral-600'}>
                    {showMovementVectors ? 'ON' : 'OFF'}
                  </span>
                </button>
                <div className="my-1 border-t border-neutral-800" />
                <button
                  onClick={() => setShowDebug(!showDebug)}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Vision Debug Mode</span>
                  <span className={showDebug ? 'text-green-400 font-bold' : 'text-neutral-600'}>
                    {showDebug ? 'ON' : 'OFF'}
                  </span>
                </button>
                <button
                  onClick={toggleAntiCheat}
                  className="w-full px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs font-mono hover:bg-neutral-900 cursor-pointer"
                >
                  <span className="text-neutral-300">Anti-Cheat</span>
                  <span className={antiCheatEnabled ? 'text-purple-400 font-bold' : 'text-neutral-600'}>
                    {antiCheatEnabled ? 'ON' : 'OFF'}
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Sound FX */}
          <button
            onClick={toggleMute}
            className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white transition-all cursor-pointer"
            title="Sound FX"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-neutral-300" />}
          </button>
        </div>
      </div>

      {/* Main Camera Viewport + Skeletal Canvas */}
      <div className="relative flex-1 w-full bg-black flex items-center justify-center overflow-hidden">
        {/* Video Stream */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover ${cameraFacingMode === 'user' ? 'scale-x-[-1]' : ''} ${
            cameraState === 'running' ? 'opacity-100' : 'opacity-20'
          }`}
          onLoadedMetadata={() => {
            if (canvasRef.current && videoRef.current) {
              canvasRef.current.width = videoRef.current.videoWidth || 640;
              canvasRef.current.height = videoRef.current.videoHeight || 480;
            }
          }}
        />

        {/* 3D Skeletal Canvas Overlay */}
        <canvas
          ref={canvasRef}
          className={`absolute inset-0 w-full h-full object-cover pointer-events-none ${
            cameraFacingMode === 'user' ? 'scale-x-[-1]' : ''
          }`}
          width={640}
          height={480}
        />

        {/* Vision Debug Mode Overlay */}
        {showDebug && (
          <div className="absolute top-4 left-4 z-50 p-3 rounded-lg bg-black/80 border border-green-500/50 backdrop-blur-md pointer-events-none text-[10px] font-mono text-green-400 space-y-1">
            <div className="font-bold border-b border-green-900 pb-1 mb-1 text-green-300">VISION DEBUG MENU</div>
            <div>FPS: {fps} | Latency: {latencyMs}ms</div>
            <div>Exercise: {analysisResult.currentExerciseName || selectedExercise}</div>
            <div>Orientation: {analysisResult.orientation || 'UNKNOWN'}</div>
            <div>Phase: {analysisResult.repPhase}</div>
            <div>Calibration State: {analysisResult.visionQuality?.isCalibrated ? 'CALIBRATED' : 'CALIBRATING'}</div>
            <div>Countdown State: {calibrationCountdown !== null ? calibrationCountdown : 'IDLE/DONE'}</div>
            <div>Pose Confidence: {analysisResult.visionQuality?.confidenceScore || 0}%</div>
            <div>Rep Count: {repCount}</div>
            <div>Form Score: {analysisResult.formScore || 0}</div>
            <div>Body In Frame: {analysisResult.isBodyInFrame ? 'YES' : 'NO'}</div>
          </div>
        )}

        {/* Calibration Countdown Banner */}
        {calibrationCountdown !== null && (
          <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm pointer-events-none">
            <div className="text-center space-y-2">
              <div className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest">
                VISION CALIBRATED • COMMENCING SET
              </div>
              <div className="text-7xl sm:text-9xl font-black font-['Orbitron'] text-white drop-shadow-[0_0_40px_rgba(0,240,255,0.8)] animate-ping">
                {calibrationCountdown}
              </div>
            </div>
          </div>
        )}

        {/* Floating XP Particle Bursts */}
        {particles.map((p) => (
          <div
            key={p.id}
            className="absolute z-40 font-['Orbitron'] font-black text-2xl sm:text-4xl text-white drop-shadow-[0_0_20px_rgba(255,255,255,1)] animate-bounce pointer-events-none -translate-x-1/2"
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
          >
            {p.text}
          </div>
        ))}

        {/* Camera Framing Validation Banner */}
        {analysisResult.framingWarning && (
          <div className="absolute top-16 sm:top-20 z-40 px-4 py-1.5 rounded-full bg-red-950/90 border border-red-500 text-red-200 text-xs font-mono font-bold tracking-wider animate-pulse flex items-center gap-2 shadow-2xl">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>{analysisResult.framingWarning}</span>
          </div>
        )}

        {/* Fatigue & Form Breakdown Safety Alert Banner */}
        {analysisResult.fatigueWarning && (
          <div className="absolute top-28 z-40 px-6 py-2 rounded-2xl bg-black/95 border-2 border-red-500 text-white text-center font-mono shadow-[0_0_40px_rgba(255,0,60,0.6)] animate-bounce">
            <div className="text-[10px] text-red-400 font-bold tracking-widest uppercase">FATIGUE DETECTION</div>
            <div className="text-sm font-black font-['Orbitron'] text-red-100">PAUSE • RECALIBRATE FORM</div>
          </div>
        )}

        {/* Picture-in-Picture 3D Anatomical Demonstrator */}
        {showPipGuide && (
          <div className="absolute bottom-24 right-4 z-40 w-64 sm:w-80 rounded-2xl overflow-hidden border border-neutral-700 bg-neutral-950/95 shadow-2xl">
            <ExerciseDemonstrator
              exerciseType={demoType}
              cadenceBpm={28}
              showTelemetry={false}
              className="h-44"
            />
          </div>
        )}

        {/* Camera Permission / Error Dialog Overlay */}
        {cameraState === 'error' && (
          <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl">
            <div className="max-w-md w-full p-6 rounded-2xl bg-neutral-900 border border-neutral-700 text-center space-y-4">
              <div className="w-12 h-12 mx-auto rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 animate-pulse">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black font-['Orbitron'] text-white">CAMERA OFFLINE</h3>
                <p className="text-xs text-neutral-400 mt-1.5 font-mono leading-relaxed">
                  {cameraError || 'Camera stream could not be initialized in this viewport.'}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                <button
                  onClick={startCamera}
                  className="flex-1 py-2.5 px-4 rounded-xl font-mono font-bold text-xs bg-white text-black hover:bg-neutral-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  RETRY CAMERA
                </button>
                <button
                  onClick={startSimulationMode}
                  className="flex-1 py-2.5 px-4 rounded-xl font-mono font-bold text-xs bg-neutral-800 border border-neutral-700 text-neutral-300 hover:text-white transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  SIMULATOR
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Top Centered Live Dynamic Form Feedback Card */}
        <div className="absolute top-16 sm:top-20 left-1/2 -translate-x-1/2 z-20 w-11/12 max-w-md pointer-events-none">
          <div
            className={`p-3 rounded-2xl border backdrop-blur-xl transition-all duration-200 text-center shadow-2xl ${
              isDepthValid
                ? 'bg-neutral-950/95 border-white text-white shadow-[0_0_24px_rgba(255,255,255,0.35)]'
                : isRepSuccess
                ? 'bg-neutral-950/95 border-white text-white shadow-[0_0_24px_rgba(255,255,255,0.3)]'
                : isFormFlaw
                ? 'bg-neutral-950/95 border-red-500 text-red-200 shadow-[0_0_24px_rgba(255,51,68,0.35)]'
                : 'bg-neutral-950/90 border-neutral-800 text-neutral-300'
            }`}
          >
            <div className="text-[9px] font-mono tracking-widest uppercase flex items-center justify-center gap-2">
              <span className={isFormFlaw ? 'text-red-400 font-bold' : isDepthValid ? 'text-white font-bold' : 'text-neutral-400'}>
                {isFormFlaw ? '[CORRECTION REQUIRED]' : isDepthValid ? '[DEPTH TARGET ATTAINED]' : '[ALIGNMENT STABLE]'}
              </span>
              {isDepthValid && <span className="text-white font-bold">★ 85° DEPTH ★</span>}
            </div>
            <div className="text-xs sm:text-sm font-black font-['Orbitron'] tracking-wider mt-0.5">
              {analysisResult.feedbackText}
            </div>
          </div>
        </div>

        {/* Ghost Match Score Pill (In Coach Mode) */}
        {showGhostTrainer && analysisResult.ghostMatch && (
          <div className="absolute top-32 left-1/2 -translate-x-1/2 z-20 px-3 py-1 rounded-full bg-black/90 border border-neutral-700 backdrop-blur-md flex items-center gap-2 shadow-lg">
            <Ghost className="w-3.5 h-3.5 text-white" />
            <span className="text-[10px] font-mono font-bold text-white">
              GHOST MATCH {analysisResult.ghostMatch.matchScore}%
            </span>
          </div>
        )}

        {/* Left Side: Real-Time Depth Meter & Clickable Form Score Gauge */}
        <div className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-3">
          {/* Depth Gauge */}
          <div className="flex flex-col items-center gap-1.5">
            <div className="text-[9px] font-mono text-neutral-400 font-bold rotate-[-90deg] origin-center -translate-y-8 tracking-widest">
              DEPTH
            </div>
            <div className="w-4 sm:w-5 h-44 sm:h-52 rounded-full bg-neutral-900 border border-neutral-800 p-0.5 flex flex-col justify-end shadow-2xl overflow-hidden relative">
              <div className="absolute top-[18%] left-0 right-0 h-[1.5px] bg-white" />
              <div
                className={`w-full rounded-full transition-all duration-100 ${
                  analysisResult.depthPercentage >= 85 ? 'bg-white shadow-[0_0_10px_#ffffff]' : 'bg-neutral-500'
                }`}
                style={{ height: `${analysisResult.depthPercentage}%` }}
              />
            </div>
            <span className="text-[10px] font-mono font-bold text-neutral-300">
              {analysisResult.depthPercentage}%
            </span>
          </div>

          {/* Interactive Form Score Badge -> Opens Explainable Breakdown Modal */}
          <button
            onClick={() => setShowFormBreakdownModal(true)}
            className="p-2 rounded-xl bg-neutral-950/90 border border-neutral-800 hover:border-white text-center w-14 transition-all cursor-pointer group shadow-xl"
            title="Click to view explainable biomechanical breakdown"
          >
            <div className="text-[8px] font-mono text-neutral-500 font-bold group-hover:text-white">SCORE</div>
            <div className="text-sm font-black font-['Orbitron'] text-white">
              {analysisResult.formScore}%
            </div>
            <div className="text-[9px] font-mono font-bold text-neutral-300">
              RANK {analysisResult.formGrade}
            </div>
          </button>
        </div>

        {/* Right Side Telemetry: Dynamic Joint Angles, Posture Alignment, Stance */}
        <div className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2 max-w-[150px] sm:max-w-[170px]">
          {/* Primary Joint Angle */}
          <div className="p-2.5 rounded-2xl bg-neutral-950/90 border border-neutral-800 text-right shadow-xl">
            <div className="text-[8px] font-mono text-neutral-400 font-bold uppercase tracking-wider">
              {analysisResult.primaryAngleName || (selectedExercise.includes('squat') ? 'θ_KNEE ANGLE' : 'θ_ELBOW ANGLE')}
            </div>
            <div className="text-lg sm:text-2xl font-black font-['Share_Tech_Mono'] text-white">
              {analysisResult.primaryAngle}°
            </div>
            <div className="text-[7px] font-mono text-neutral-500">
              {(analysisResult.exerciseDefinition?.isIsometric || analysisResult.exerciseDefinition?.isHoldExercise)
                ? 'HOLD ISOMETRIC'
                : `LOCK: ≥${analysisResult.exerciseDefinition?.angleRanges.lockoutMinAngle || 160}° | DEPTH: ≤${analysisResult.exerciseDefinition?.angleRanges.inflectionTargetAngle || 85}°`}
            </div>
          </div>

          {/* Secondary Joint / Posture Diagnostic */}
          <div
            className={`p-2 rounded-2xl bg-neutral-950/90 backdrop-blur-md text-right shadow-xl border transition-colors ${
              analysisResult.isSpineAligned
                ? 'border-neutral-800 text-neutral-300'
                : 'border-red-500 text-red-400'
            }`}
          >
            <div className="text-[8px] font-mono text-neutral-400 font-bold uppercase tracking-wider">
              {analysisResult.secondaryAngleName || 'θ_SPINE (≥160°)'}
            </div>
            <div className="text-sm sm:text-base font-black font-['Share_Tech_Mono'] text-white">
              {analysisResult.secondaryAngle}°
            </div>
            <div className="text-[7.5px] font-mono font-bold">
              {analysisResult.isSpineAligned ? '✓ STRICT ALIGNMENT' : '✗ POSTURE FLAW'}
            </div>
          </div>

          {/* Hand / Stance Placement Diagnostic */}
          <div
            className={`p-2 rounded-xl bg-neutral-950/90 text-right border ${
              analysisResult.handPlacement.status === 'valid'
                ? 'border-neutral-800 text-neutral-300'
                : 'border-red-500 text-red-300'
            }`}
          >
            <div className="text-[8px] font-mono text-neutral-400 uppercase tracking-wider">STANCE / PLACEMENT</div>
            <div className="text-[10px] font-mono font-bold text-white leading-tight mt-0.5">
              {analysisResult.placementStatusText || analysisResult.handPlacement.cueText}
            </div>
          </div>
        </div>

        {/* Analyst Mode Diagnostic Overlay Card */}
        {visionHudMode === 'analyst' && (
          <div className="absolute top-24 left-3 z-30 p-3.5 rounded-2xl bg-black/92 border border-purple-500/40 text-[10px] font-mono text-neutral-300 space-y-1.5 backdrop-blur-xl max-w-xs shadow-2xl pointer-events-none">
            <div className="flex items-center justify-between border-b border-purple-500/30 pb-1">
              <span className="font-bold text-purple-300 uppercase tracking-widest flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-purple-400" />
                ANALYST DIAGNOSTICS
              </span>
              <span className="text-[9px] text-neutral-500">{fps} FPS</span>
            </div>
            <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[9.5px]">
              <div>LATENCY: <span className="text-white font-bold">{latencyMs} ms</span></div>
              <div>POSE CONF: <span className="text-white font-bold">{(analysisResult.visibilityScore * 100).toFixed(0)}%</span></div>
              <div>REP PHASE: <span className="text-cyan-300 font-bold">{analysisResult.repPhase}</span></div>
              <div>VECTOR: <span className="text-white font-bold">{analysisResult.movementVector}</span></div>
              <div>ELBOW TUCK: <span className={analysisResult.isElbowTucked ? 'text-cyan-400 font-bold' : 'text-red-400 font-bold'}>{analysisResult.isElbowTucked ? '45° ARROW' : 'FLARED'}</span></div>
              <div>GHOST MATCH: <span className="text-purple-300 font-bold">{analysisResult.ghostMatch?.matchScore ?? 95}%</span></div>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Explainable Form Score Breakdown Modal */}
      {showFormBreakdownModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl">
          <div className="relative w-full max-w-md rounded-3xl bg-[#0b0f19] border border-cyan-500/40 p-5 sm:p-6 shadow-2xl text-slate-100 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black font-['Orbitron'] text-white">EXPLAINABLE FORM SCORE</h3>
                  <p className="text-[10px] font-mono text-cyan-400">Biomechanical Breakdown & Correction Logic</p>
                </div>
              </div>
              <button
                onClick={() => setShowFormBreakdownModal(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Score Gauges */}
            <div className="space-y-2 text-xs font-mono">
              {[
                { label: 'Spine & Core Alignment', val: analysisResult.formBreakdown?.alignmentScore || 95 },
                { label: 'Elbow Arrowhead Tuck (45°)', val: analysisResult.formBreakdown?.elbowScore || 98 },
                { label: 'Depth Inflection (<85°)', val: analysisResult.formBreakdown?.depthScore || 92 },
                { label: 'Hand Stance Ratio', val: analysisResult.formBreakdown?.handScore || 96 },
                { label: 'Left/Right Symmetry', val: analysisResult.formBreakdown?.symmetryScore || 94 },
              ].map((item) => (
                <div key={item.label} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">{item.label}</span>
                    <span className="font-bold text-cyan-400">{item.val}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        item.val >= 85 ? 'bg-cyan-400' : item.val >= 70 ? 'bg-amber-400' : 'bg-red-500'
                      }`}
                      style={{ width: `${item.val}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Primary Issue & Why */}
            <div className="p-3.5 rounded-2xl bg-black/60 border border-slate-800 space-y-2 text-xs font-mono">
              <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
                <Info className="w-3.5 h-3.5" />
                <span>BIOMECHANICAL WHY:</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                {analysisResult.formBreakdown?.whyExplanation}
              </p>
            </div>

            {/* Actionable Fix Cue */}
            <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 space-y-1.5 text-xs font-mono">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>COACHING FIX CUE:</span>
              </div>
              <p className="text-slate-200 text-[11px] leading-relaxed">
                {analysisResult.formBreakdown?.howToFixCue}
              </p>
            </div>

            <button
              onClick={() => setShowFormBreakdownModal(false)}
              className="w-full py-2.5 rounded-xl bg-white text-black font-bold font-mono text-xs hover:bg-slate-200 transition-all cursor-pointer"
            >
              RESUME WORKOUT
            </button>
          </div>
        </div>
      )}

      {/* Bottom Control Deck & Cinematic Rep Counter */}
      <div className="relative z-30 p-3 sm:p-4 bg-black border-t border-neutral-800 backdrop-blur-2xl">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-6">
          {/* Rep Counter / Hold Timer Display */}
          <div className="flex items-center gap-3 sm:gap-4 w-full sm:w-auto justify-between sm:justify-start">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl bg-neutral-900 border border-neutral-700 flex flex-col items-center justify-center shadow-2xl">
                <span className="text-2xl sm:text-3xl font-black font-['Orbitron'] text-white leading-none">
                  {repCount}
                </span>
                <span className="text-[8.5px] font-mono font-bold text-neutral-400 tracking-wider mt-0.5 uppercase">
                  {(analysisResult.exerciseDefinition?.isIsometric || analysisResult.exerciseDefinition?.isHoldExercise) ? 'SEC' : 'REPS'}
                </span>
              </div>

              <div>
                <div className="flex items-center gap-1.5 text-xs font-mono text-neutral-300">
                  <span>SET:</span>
                  <span className="font-bold text-white">{currentSetNum} / {questExercise?.sets || 3}</span>
                </div>
                <div className="text-xs font-mono text-neutral-400 mt-0.5">
                  TARGET: <span className="text-white font-bold">{questExercise?.repsPerSet || 15} {(analysisResult.exerciseDefinition?.isIsometric || analysisResult.exerciseDefinition?.isHoldExercise) ? 'seconds' : 'reps'}</span>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-mono text-white mt-1">
                  <Flame className="w-3 h-3 text-white" />
                  <span>+{(questExercise?.xpPerRep || 10) * repCount} XP ACCUMULATED</span>
                </div>
              </div>
            </div>

            {/* Rep Quality Telemetry Badges (Recent 3 reps) */}
            <div className="hidden md:flex items-center gap-1.5 text-[9px] font-mono">
              {sessionRepQualityLog.slice(0, 3).map((r, i) => (
                <div
                  key={i}
                  className={`px-2 py-1 rounded-lg border flex flex-col items-center ${
                    r.grade === 'PERFECT'
                      ? 'bg-cyan-950/60 border-cyan-400/50 text-cyan-300'
                      : r.grade === 'GOOD'
                      ? 'bg-slate-900 border-slate-700 text-slate-300'
                      : 'bg-red-950/60 border-red-500/50 text-red-300'
                  }`}
                >
                  <span className="font-bold">REP #{r.repIndex}</span>
                  <span>{r.qualityScore}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleFinishSet}
              className="w-full sm:w-auto py-3 px-6 sm:px-8 rounded-2xl font-mono font-bold text-xs sm:text-sm tracking-wider bg-white text-black hover:bg-neutral-200 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
            >
              <CheckCircle2 className="w-4 h-4 text-black" />
              COMPLETE SET
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const CameraTracker = VisionTracker;
export default VisionTracker;
