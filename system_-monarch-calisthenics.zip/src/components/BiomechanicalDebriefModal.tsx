import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Award,
  ShieldCheck,
  AlertTriangle,
  Zap,
  Volume2,
  CheckCircle2,
  TrendingUp,
  X,
  RefreshCw,
  Sliders
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { requestBiomechanicalSessionDebrief } from '../services/geminiService';
import { BiomechanicalSessionReport } from '../server/geminiBackend';
import { soundEngine } from '../utils/soundEngine';
import { aiTts } from '../utils/aiTtsEngine';
import confetti from 'canvas-confetti';

interface BiomechanicalDebriefModalProps {
  onClose: () => void;
  sessionData?: {
    totalReps: number;
    totalSets: number;
    averageAngleDepth: number;
    repCadenceSeconds: number;
    antiCheatViolations: number;
    exerciseName: string;
    durationMinutes: number;
  };
}

export const BiomechanicalDebriefModal: React.FC<BiomechanicalDebriefModalProps> = ({
  onClose,
  sessionData
}) => {
  const {
    profile,
    geminiApiKey,
    latestDebrief,
    setLatestDebrief,
    allocateStat,
    ttsEnabled
  } = useGameStore();

  const [loading, setLoading] = useState<boolean>(!latestDebrief);
  const [report, setReport] = useState<BiomechanicalSessionReport | null>(latestDebrief);

  const fallbackSession = sessionData || {
    totalReps: 45,
    totalSets: 3,
    averageAngleDepth: 78,
    repCadenceSeconds: 2.1,
    antiCheatViolations: 0,
    exerciseName: 'Monarch Calisthenics Routine',
    durationMinutes: 14
  };

  useEffect(() => {
    if (!report) {
      loadDebrief();
    }
  }, []);

  const loadDebrief = async () => {
    setLoading(true);
    try {
      const res = await requestBiomechanicalSessionDebrief({
        sessionData: fallbackSession,
        profile: {
          name: profile.name,
          age: profile.age,
          weightKg: profile.weightKg,
          heightCm: profile.heightCm,
          hunterClass: profile.hunterClass,
          currentRank: profile.currentRank,
          level: profile.level,
          str: profile.str,
          agi: profile.agi,
          end: profile.end,
          sen: profile.sen
        },
        apiKey: geminiApiKey
      });
      setReport(res);
      setLatestDebrief(res);

      if (ttsEnabled) {
        aiTts.speak(`Biomechanical Debrief complete. Grade: ${res.grade}. Score: ${res.overallScore}.`);
      }
    } catch (e) {
      console.error('Debrief error:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyStatRecommendations = () => {
    if (!report?.recommendedStatAllocation) return;
    const { str, agi, end, sen } = report.recommendedStatAllocation;
    let available = profile.statPoints;

    soundEngine.playLevelUp();
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 }
    });

    for (let i = 0; i < str && available > 0; i++) {
      allocateStat('str');
      available--;
    }
    for (let i = 0; i < agi && available > 0; i++) {
      allocateStat('agi');
      available--;
    }
    for (let i = 0; i < end && available > 0; i++) {
      allocateStat('end');
      available--;
    }
    for (let i = 0; i < sen && available > 0; i++) {
      allocateStat('sen');
      available--;
    }

    aiTts.speak('Recommended attribute points allocated.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-[#08090d] border border-cyan-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(0,240,255,0.2)] overflow-hidden max-h-[90vh] flex flex-col">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-950 border border-cyan-400/40 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.3)]">
              <Sparkles className="w-5 h-5 text-cyan-300 animate-pulse" />
            </div>
            <div>
              <div className="text-[10px] font-mono font-bold text-cyan-400 tracking-widest uppercase">
                AI BIOMECHANICAL AUDIT
              </div>
              <h2 className="text-xl font-black font-['Orbitron'] text-white">
                POST-WORKOUT SYSTEM DEBRIEF
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadDebrief}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all cursor-pointer"
              title="Recalculate Debrief"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-4 font-mono text-center">
            <div className="w-12 h-12 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
            <p className="text-cyan-300 text-sm font-bold animate-pulse">
              ANALYZING JOINT ANGULAR VELOCITIES & KINETIC DEPTH...
            </p>
          </div>
        ) : report ? (
          <div className="flex-1 overflow-y-auto py-5 space-y-5 pr-1 font-mono text-xs sm:text-sm">
            {/* Grade & Score Banner */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/60 to-purple-950/60 border border-cyan-500/30 flex items-center justify-between">
              <div className="space-y-1">
                <div className="text-[10px] text-slate-400 font-bold uppercase">
                  BIOMECHANICAL EFFICIENCY RATING
                </div>
                <div className="text-3xl sm:text-4xl font-black font-['Orbitron'] text-white flex items-center gap-2">
                  <span>{report.overallScore}</span>
                  <span className="text-base text-cyan-400 font-mono">/ 100</span>
                </div>
              </div>

              <div className="text-center px-5 py-2 rounded-2xl bg-black/60 border border-purple-500/50 shadow-[0_0_20px_rgba(139,92,246,0.3)]">
                <div className="text-[10px] text-purple-300 font-bold">GRADE</div>
                <div className="text-3xl sm:text-4xl font-black font-['Orbitron'] text-purple-300">
                  {report.grade}
                </div>
              </div>
            </div>

            {/* System Monarch Evaluation Narrative */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/20 space-y-2">
              <div className="flex items-center justify-between text-cyan-400 text-xs font-bold">
                <span className="flex items-center gap-1.5">
                  <Award className="w-4 h-4" />
                  <span>SYSTEM ARCHITECT EVALUATION</span>
                </span>
                <button
                  onClick={() => aiTts.speak(report.systemEvaluation)}
                  className="text-[11px] text-cyan-300 hover:text-cyan-200 flex items-center gap-1 cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>LISTEN</span>
                </button>
              </div>
              <p className="text-slate-200 text-xs sm:text-sm leading-relaxed">
                "{report.systemEvaluation}"
              </p>
            </div>

            {/* Strengths & Weaknesses Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Strengths */}
              <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                <div className="text-emerald-400 font-bold text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>IDENTIFIED STRENGTHS</span>
                </div>
                <ul className="space-y-1.5 text-xs text-emerald-200">
                  {report.strengths.map((item, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-emerald-400 font-bold">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Weaknesses */}
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-2">
                <div className="text-amber-400 font-bold text-xs flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  <span>BIOMECHANICAL LEAKS</span>
                </div>
                <ul className="space-y-1.5 text-xs text-amber-200">
                  {report.biomechanicalWeaknesses.map((item, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-amber-400 font-bold">!</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Recommended Stat Point Allocation */}
            {report.recommendedStatAllocation && (
              <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-purple-300 font-bold text-xs flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4" />
                    <span>RECOMMENDED ATTRIBUTE ALLOCATION</span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    AVAILABLE: {profile.statPoints} PTS
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2 rounded-xl bg-slate-900 border border-cyan-500/30">
                    <div className="text-[10px] text-slate-400">STR</div>
                    <div className="text-base font-bold text-cyan-300">
                      +{report.recommendedStatAllocation.str}
                    </div>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900 border border-emerald-500/30">
                    <div className="text-[10px] text-slate-400">AGI</div>
                    <div className="text-base font-bold text-emerald-300">
                      +{report.recommendedStatAllocation.agi}
                    </div>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900 border border-amber-500/30">
                    <div className="text-[10px] text-slate-400">END</div>
                    <div className="text-base font-bold text-amber-300">
                      +{report.recommendedStatAllocation.end}
                    </div>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900 border border-purple-500/30">
                    <div className="text-[10px] text-slate-400">SEN</div>
                    <div className="text-base font-bold text-purple-300">
                      +{report.recommendedStatAllocation.sen}
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-300 italic">
                  "{report.recommendedStatAllocation.reasoning}"
                </p>

                {profile.statPoints > 0 && (
                  <button
                    onClick={handleApplyStatRecommendations}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs transition-all cursor-pointer shadow-[0_0_20px_rgba(139,92,246,0.3)] flex items-center justify-center gap-2"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>AUTO-DISTRIBUTE {Math.min(profile.statPoints, (report.recommendedStatAllocation.str + report.recommendedStatAllocation.agi + report.recommendedStatAllocation.end + report.recommendedStatAllocation.sen))} STAT POINTS</span>
                  </button>
                )}
              </div>
            )}

            {/* Next Prescription */}
            {report.nextWorkoutPrescription && (
              <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-1">
                <div className="text-[10px] text-cyan-400 font-bold uppercase">
                  NEXT WORKOUT PRESCRIPTION
                </div>
                <p className="text-xs text-cyan-200">
                  {report.nextWorkoutPrescription}
                </p>
              </div>
            )}
          </div>
        ) : null}

        {/* Bottom Actions */}
        <div className="pt-4 border-t border-cyan-500/20 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-cyan-500 text-black font-mono font-bold text-xs hover:bg-cyan-400 transition-all cursor-pointer shadow-[0_0_20px_rgba(0,240,255,0.4)]"
          >
            DISMISS REPORT
          </button>
        </div>
      </div>
    </div>
  );
};
