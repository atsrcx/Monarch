import React from 'react';
import {
  Flame,
  Target,
  Shield,
  Sparkles,
  Play,
  Layers,
  ChevronRight,
  TrendingUp,
  Award,
  Zap,
  Activity,
  Bot,
  Sword
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';
import { ExerciseDemonstrator } from './ExerciseDemonstrator';

interface MonarchDashboardProps {
  onInitiateWorkout: () => void;
  onNavigateToTab: (tab: any) => void;
}

export const MonarchDashboard: React.FC<MonarchDashboardProps> = ({
  onInitiateWorkout,
  onNavigateToTab,
}) => {
  const {
    profile,
    currentQuest,
    completedSetsMap,
    streak,
    workoutHistory,
    openModal,
  } = useGameStore();

  const [showDemonstrator, setShowDemonstrator] = React.useState(false);

  const primaryExercise = currentQuest.exercises[0] || {
    id: 'push-standard',
    name: 'Standard Push-ups (45° Arrowhead)',
    sets: 3,
    repsPerSet: 10,
    xpPerRep: 10,
  };

  const totalTargetReps =
    currentQuest.totalTargetReps || primaryExercise.sets * primaryExercise.repsPerSet;
  const setsDone = completedSetsMap[primaryExercise.id] || 0;
  const completedReps = Math.min(
    totalTargetReps,
    setsDone * primaryExercise.repsPerSet
  );
  const completionPercentage = Math.min(
    100,
    Math.round((completedReps / Math.max(1, totalTargetReps)) * 100)
  );

  const xpPercentage = Math.min(
    100,
    Math.round((profile.xp / Math.max(1, profile.maxXp)) * 100)
  );

  const todayDateStr = new Date()
    .toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    })
    .toUpperCase();

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-24 text-white">
      {/* 1. Top Header Banner: Date & Level */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span>MONARCH V3 PROTOCOL • {todayDateStr}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black font-['Orbitron'] tracking-wider text-white mt-1">
              COMMAND HUD
            </h1>
            <p className="text-xs font-mono text-neutral-400 mt-1">
              ATHLETE {profile.name.toUpperCase()} — {profile.hunterClass.toUpperCase()}
            </p>
          </div>

          {/* Quick Metrics Badges */}
          <div className="flex items-center gap-2">
            <div className="px-4 py-2 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
              <div className="text-[9px] font-mono text-neutral-500 uppercase">STREAK</div>
              <div className="text-lg font-black font-['Orbitron'] text-white flex items-center gap-1 justify-center">
                <Flame className="w-4 h-4 text-white" />
                <span>{streak}D</span>
              </div>
            </div>

            <div className="px-4 py-2 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
              <div className="text-[9px] font-mono text-neutral-500 uppercase">LEVEL</div>
              <div className="text-lg font-black font-['Orbitron'] text-white">
                LV.{profile.level}
              </div>
            </div>

            <div className="px-4 py-2 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
              <div className="text-[9px] font-mono text-neutral-500 uppercase">RANK</div>
              <div className="text-xs font-black font-mono text-white mt-1">
                {profile.currentRank}
              </div>
            </div>
          </div>
        </div>

        {/* Dual Progress Bars: XP & Target Completion */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6 pt-6 border-t border-neutral-800">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-neutral-400 uppercase">DAILY TARGET PROGRESS</span>
              <span className="font-bold text-white">
                {completedReps} / {totalTargetReps} REPS ({completionPercentage}%)
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-neutral-900 overflow-hidden border border-neutral-800">
              <div
                className="h-full rounded-full bg-white transition-all duration-500 shadow-[0_0_10px_#ffffff]"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-neutral-400 uppercase">EXPERIENCE XP</span>
              <span className="font-bold text-neutral-300">
                {profile.xp} / {profile.maxXp} XP ({xpPercentage}%)
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-neutral-900 overflow-hidden border border-neutral-800">
              <div
                className="h-full rounded-full bg-neutral-400 transition-all duration-500"
                style={{ width: `${xpPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 2. Today's Main Active Workout & Massive Initiate Button */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
          <div>
            <span className="text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase bg-neutral-900 px-2.5 py-1 rounded-full border border-neutral-800">
              ACTIVE PROTOCOL
            </span>
            <h2 className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white mt-2">
              {currentQuest.questTitle}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundEngine.playClick();
                setShowDemonstrator(!showDemonstrator);
              }}
              className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-mono font-bold text-neutral-200 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>{showDemonstrator ? 'HIDE 3D GUIDE' : '3D FORM GUIDE'}</span>
            </button>
            <button
              onClick={() => {
                soundEngine.playClick();
                openModal('debrief');
              }}
              className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-mono font-bold text-neutral-200 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI DEBRIEF</span>
            </button>
          </div>
        </div>

        {/* Exercise Specifications */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
            <div className="text-xs font-mono text-neutral-400 uppercase flex items-center gap-1.5">
              <Target className="w-4 h-4 text-white" />
              <span>PRESCRIPTION</span>
            </div>
            <div className="text-2xl font-black font-['Orbitron'] text-white">
              {primaryExercise.sets} SETS × {primaryExercise.repsPerSet} REPS
            </div>
            <div className="text-xs font-mono text-neutral-400">
              {primaryExercise.name}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1 text-xs font-mono text-neutral-300">
            <div className="text-neutral-400 uppercase font-bold flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-white" />
              <span>BIOMECHANICAL TARGETS</span>
            </div>
            <ul className="space-y-1 pt-1 text-neutral-300">
              <li>• <strong className="text-white">45° Arrowhead:</strong> Tuck elbows close to lat line.</li>
              <li>• <strong className="text-white">Depth:</strong> Full descent below 85° elbow angle.</li>
              <li>• <strong className="text-white">Lockout:</strong> Complete protraction at 160°+.</li>
            </ul>
          </div>
        </div>

        {/* 3D Anatomical Kinetic Guide preview */}
        {showDemonstrator && (
          <div className="pt-4 border-t border-neutral-800">
            <ExerciseDemonstrator
              exerciseType="pushup_standard"
              cadenceBpm={28}
              showTelemetry={true}
            />
          </div>
        )}

        {/* Launch Primary Vision Tracking Workout */}
        <button
          onClick={onInitiateWorkout}
          className="w-full py-5 px-6 rounded-2xl font-black font-['Orbitron'] text-base sm:text-xl tracking-wider uppercase bg-white text-black hover:bg-neutral-200 active:scale-[0.99] transition-all flex items-center justify-center gap-3 cursor-pointer shadow-2xl"
        >
          <Play className="w-6 h-6 fill-current text-black" />
          <span>START AI VISION WORKOUT</span>
        </button>
      </div>

      {/* 3. Quick Access Modules Hub */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => {
            soundEngine.playClick();
            onNavigateToTab('skills');
          }}
          className="p-5 rounded-3xl bg-neutral-950 border border-neutral-800 hover:border-white text-left transition-all cursor-pointer group shadow-xl"
        >
          <div className="w-10 h-10 rounded-2xl bg-neutral-900 border border-neutral-700 flex items-center justify-center mb-3 group-hover:bg-white group-hover:text-black transition-colors">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold font-['Orbitron'] text-white flex items-center justify-between">
            <span>SKILL TREE</span>
            <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white" />
          </h3>
          <p className="text-xs font-mono text-neutral-400 mt-1">
            Planche, Muscle-Up, Handstand mastery paths & unlockable progressions.
          </p>
        </button>

        <button
          onClick={() => {
            soundEngine.playClick();
            onNavigateToTab('combat');
          }}
          className="p-5 rounded-3xl bg-neutral-950 border border-neutral-800 hover:border-white text-left transition-all cursor-pointer group shadow-xl"
        >
          <div className="w-10 h-10 rounded-2xl bg-neutral-900 border border-neutral-700 flex items-center justify-center mb-3 group-hover:bg-white group-hover:text-black transition-colors">
            <Sword className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold font-['Orbitron'] text-white flex items-center justify-between">
            <span>COMBAT FITNESS</span>
            <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white" />
          </h3>
          <p className="text-xs font-mono text-neutral-400 mt-1">
            Pre-workout joint prehab, wrist conditioning, and high-intensity kinetic rounds.
          </p>
        </button>

        <button
          onClick={() => {
            soundEngine.playClick();
            onNavigateToTab('chat');
          }}
          className="p-5 rounded-3xl bg-neutral-950 border border-neutral-800 hover:border-white text-left transition-all cursor-pointer group shadow-xl"
        >
          <div className="w-10 h-10 rounded-2xl bg-neutral-900 border border-neutral-700 flex items-center justify-center mb-3 group-hover:bg-white group-hover:text-black transition-colors">
            <Bot className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold font-['Orbitron'] text-white flex items-center justify-between">
            <span>AI MASTER COACH</span>
            <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-white" />
          </h3>
          <p className="text-xs font-mono text-neutral-400 mt-1">
            Biomechanics consultations, recovery protocols, and real-time audio analysis.
          </p>
        </button>
      </div>
    </div>
  );
};

export default MonarchDashboard;
