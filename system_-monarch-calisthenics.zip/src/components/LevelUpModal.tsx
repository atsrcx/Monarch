import React from 'react';
import { Award, Sparkles, Zap, ArrowRight, ShieldCheck } from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

export const LevelUpModal: React.FC = () => {
  const { profile, levelUpData, closeModal } = useGameStore();

  const handleClaim = () => {
    soundEngine.playClick();
    closeModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl animate-fade-in">
      <div className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#0e1424] via-[#090c14] to-[#08090d] border-2 border-cyan-400 shadow-[0_0_80px_rgba(0,240,255,0.4)] text-slate-100 p-6 sm:p-8 text-center space-y-6 overflow-hidden">
        {/* Glow halo */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-cyan-400/20 blur-3xl pointer-events-none" />

        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-400 text-cyan-300 text-xs font-mono font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(0,240,255,0.3)]">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            SYSTEM LEVEL UP NOTIFICATION
          </div>

          <h2 className="text-3xl sm:text-4xl font-black font-['Orbitron'] text-white tracking-wider pt-2">
            LEVEL UP!
          </h2>

          <div className="text-5xl sm:text-6xl font-black font-['Orbitron'] bg-gradient-to-r from-cyan-300 via-blue-400 to-purple-400 bg-clip-text text-transparent py-1">
            LV. {levelUpData?.newLevel || profile.level}
          </div>

          {levelUpData?.rankUnlocked && (
            <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-400 text-purple-200 text-xs font-mono font-bold">
              ★ RANK ADVANCEMENT UNLOCKED: {levelUpData.rankUnlocked} ★
            </div>
          )}

          <p className="text-xs font-mono text-slate-300 max-w-xs mx-auto">
            Your physical vessel has absorbed calisthenic kinetic energy and evolved.
          </p>
        </div>

        {/* Rewards Received Box */}
        <div className="grid grid-cols-2 gap-3 relative z-10 font-mono">
          <div className="p-3 rounded-2xl bg-black/60 border border-purple-500/40">
            <div className="text-[10px] text-purple-400 font-bold">STAT POINTS</div>
            <div className="text-xl font-black text-white mt-1">
              +{levelUpData?.statPointsAwarded || 3} PTS
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-black/60 border border-amber-500/40">
            <div className="text-[10px] text-amber-400 font-bold">MONARCH GOLD</div>
            <div className="text-xl font-black text-amber-300 mt-1">+500 G</div>
          </div>
        </div>

        {/* Accept Button */}
        <button
          onClick={handleClaim}
          className="relative z-10 w-full py-3.5 px-6 rounded-2xl font-['Orbitron'] font-black text-sm tracking-widest bg-gradient-to-r from-cyan-400 to-blue-600 text-black hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(0,240,255,0.5)] cursor-pointer"
        >
          <ShieldCheck className="w-5 h-5 text-black" />
          ACCEPT REWARDS & CONTINUE
        </button>
      </div>
    </div>
  );
};

export default LevelUpModal;
