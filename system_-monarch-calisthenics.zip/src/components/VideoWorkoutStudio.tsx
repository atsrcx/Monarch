import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Sparkles,
  Camera,
  Activity,
  Layers,
  ChevronRight,
  ShieldCheck,
  Flame,
  Zap,
  Info,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  Maximize2
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';
import { aiTts } from '../utils/aiTtsEngine';
import { VisionTracker } from './VisionTracker';

export interface VideoMovement {
  id: string;
  name: string;
  category: 'push' | 'legs' | 'core' | 'elite';
  rankRequired: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Master';
  tempo: string; // e.g. '3-1-1-0'
  targetAngle: number;
  lockoutAngle: number;
  description: string;
  primaryMuscles: string[];
  secondaryMuscles: string[];
  formCues: string[];
  commonMistakes: string[];
  animationType: 'pushup' | 'diamond' | 'archer' | 'squat' | 'pistol' | 'plank' | 'pseudo_planche';
}

const MOVEMENTS: VideoMovement[] = [
  {
    id: 'pushup-standard',
    name: 'Standard Military Push-up',
    category: 'push',
    rankRequired: 'E-Rank',
    difficulty: 'Beginner',
    tempo: '2-1-1-0',
    targetAngle: 80,
    lockoutAngle: 160,
    description: 'The cornerstone of calisthenics upper body pushing strength. Builds pectoralis major, anterior deltoids, and triceps brachii.',
    primaryMuscles: ['Chest (Pectoralis Major)', 'Triceps Brachii'],
    secondaryMuscles: ['Anterior Deltoids', 'Transverse Abdominis', 'Glutes'],
    formCues: [
      'Hands slightly wider than shoulder width',
      'Elbows tracking back at a 45-degree angle (arrowhead shape)',
      'Tight core and squeezed glutes for straight spine line',
      'Lower until chest is 2 inches off the floor (80° elbow angle)',
      'Full lockout at top with active scapular protraction'
    ],
    commonMistakes: [
      'Flaring elbows out to 90 degrees (strains rotator cuff)',
      'Sagging lower back / dropped pelvis',
      'Half-reps (not touching bottom depth)'
    ],
    animationType: 'pushup'
  },
  {
    id: 'pushup-diamond',
    name: 'Diamond Triceps Push-up',
    category: 'push',
    rankRequired: 'D-Rank',
    difficulty: 'Intermediate',
    tempo: '3-1-1-0',
    targetAngle: 75,
    lockoutAngle: 165,
    description: 'Close-grip pushup forming a diamond between thumbs and index fingers, placing extreme mechanical leverage on the triceps and sternal chest.',
    primaryMuscles: ['Triceps (Long & Lateral Head)', 'Inner Pectoral Sternal Head'],
    secondaryMuscles: ['Anterior Deltoids', 'Core Stabilizers'],
    formCues: [
      'Index fingers and thumbs touching directly below sternum',
      'Keep elbows tightly pinned alongside ribs during descent',
      'Lower sternum until it gently taps your hands',
      'Violently press through palms to lock out triceps'
    ],
    commonMistakes: [
      'Placing hands too far forward past collarbones',
      'Excessive wrist bending without prior mobility warmup'
    ],
    animationType: 'diamond'
  },
  {
    id: 'pushup-archer',
    name: 'Archer Asymmetric Push-up',
    category: 'push',
    rankRequired: 'C-Rank',
    difficulty: 'Advanced',
    tempo: '3-1-1-0',
    targetAngle: 70,
    lockoutAngle: 165,
    description: 'One-arm push-up progression. One working arm bears 80% of bodyweight while the straight assist arm provides lateral balance.',
    primaryMuscles: ['Single-Arm Pectoralis', 'Unilateral Triceps'],
    secondaryMuscles: ['Serratus Anterior', 'Obliques', 'Scapular Stabilizers'],
    formCues: [
      'Very wide hand placement (2x shoulder width)',
      'Shift torso completely over the working arm while keeping assist arm locked straight',
      'Rotate palm outward on extended arm if needed for shoulder comfort',
      'Drive upward through the working palm back to center'
    ],
    commonMistakes: [
      'Bending the assisting arm instead of keeping it straight',
      'Rotating pelvis open instead of keeping hips parallel'
    ],
    animationType: 'archer'
  },
  {
    id: 'pushup-pseudo',
    name: 'Pseudo Planche Push-up',
    category: 'elite',
    rankRequired: 'B-Rank',
    difficulty: 'Master',
    tempo: '3-2-1-0',
    targetAngle: 75,
    lockoutAngle: 165,
    description: 'Elite straight-arm shoulder lean push-up. Hands placed near the waist with extreme forward lean to mimic planche mechanics.',
    primaryMuscles: ['Anterior Deltoids', 'Serratus Anterior', 'Upper Chest'],
    secondaryMuscles: ['Biceps Brachii Tendons', 'Core Hollow Body'],
    formCues: [
      'Turn fingers outward at 45 degrees, place hands near mid-torso/hips',
      'Lean shoulders far past fingertips before starting descent',
      'Maintain hollow body posture with rounded upper back at apex',
      'Keep shoulders forward throughout the entire repetition'
    ],
    commonMistakes: [
      'Losing forward lean when pressing up',
      'Arching lower spine'
    ],
    animationType: 'pseudo_planche'
  },
  {
    id: 'squat-standard',
    name: 'Monarch Deep Bodyweight Squat',
    category: 'legs',
    rankRequired: 'E-Rank',
    difficulty: 'Beginner',
    tempo: '3-1-1-0',
    targetAngle: 85,
    lockoutAngle: 170,
    description: 'Full kinetic chain lower-body calisthenics movement. Forges explosive quads, hamstrings, and hip mobility.',
    primaryMuscles: ['Quadriceps Femoris', 'Gluteus Maximus'],
    secondaryMuscles: ['Hamstrings', 'Soleus / Calves', 'Erector Spinae'],
    formCues: [
      'Feet shoulder-width apart, toes flared slightly out (15-20°)',
      'Initiate by breaking at the hips, keeping chest upright',
      'Descend until hip crease drops below top of knees (below parallel)',
      'Drive upward through midfoot and heels, locking out hips at top'
    ],
    commonMistakes: [
      'Knees collapsing inward (valgus fault)',
      'Heels lifting off the ground (inadequate ankle dorsiflexion)'
    ],
    animationType: 'squat'
  },
  {
    id: 'squat-pistol',
    name: 'Pistol Squat (Single-Leg Mastery)',
    category: 'legs',
    rankRequired: 'C-Rank',
    difficulty: 'Advanced',
    tempo: '3-1-1-0',
    targetAngle: 75,
    lockoutAngle: 170,
    description: 'The pinnacle of lower-body unilateral strength and ankle mobility. Entire bodyweight hoisted by a single leg.',
    primaryMuscles: ['Quadriceps (Vastus Medialis)', 'Gluteus Medius & Maximus'],
    secondaryMuscles: ['Hip Flexors', 'Core Stabilizers', 'Ankle Dorsiflexors'],
    formCues: [
      'Extend non-working leg straight out in front parallel to floor',
      'Reach arms forward for counter-balance',
      'Control descent slowly all the way to rock-bottom depth',
      'Drive through heel without letting torso collapse'
    ],
    commonMistakes: [
      'Allowing heel of working foot to elevate',
      'Letting non-working leg touch floor before completion'
    ],
    animationType: 'pistol'
  },
  {
    id: 'core-plank',
    name: 'Iron Hollow Body Plank Hold',
    category: 'core',
    rankRequired: 'E-Rank',
    difficulty: 'Beginner',
    tempo: 'Static Hold',
    targetAngle: 180,
    lockoutAngle: 180,
    description: 'Isometric anti-extension core fortress. Teaches total body tension and protects lumbar spine during heavy athletic maneuvers.',
    primaryMuscles: ['Rectus Abdominis', 'Transverse Abdominis'],
    secondaryMuscles: ['Obliques', 'Serratus Anterior', 'Gluteus Maximus', 'Quads'],
    formCues: [
      'Forearms parallel on ground with elbows under shoulders',
      'Tuck pelvis into posterior pelvic tilt (suck belly button to spine)',
      'Squeeze quadriceps and glutes as hard as possible',
      'Breathe steadily through nose while maintaining maximum abdominal brace'
    ],
    commonMistakes: [
      'Piking hips into an inverted V-shape',
      'Sagging hips toward the ground and compressing lower spine'
    ],
    animationType: 'plank'
  }
];

interface VideoWorkoutStudioProps {
  onStartInVisionAI?: (exerciseId: string) => void;
}

export const VideoWorkoutStudio: React.FC<VideoWorkoutStudioProps> = ({ onStartInVisionAI }) => {
  const {
    profile,
    selectedVideoExercise,
    videoSplitMode,
    setSelectedVideoExercise,
    toggleVideoSplitMode,
    recordRep,
    completeSet,
    startRestTimer,
    currentQuest,
    isMuted
  } = useGameStore();

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [repCount, setRepCount] = useState<number>(0);
  const [targetReps, setTargetReps] = useState<number>(12);
  const [currentSet, setCurrentSet] = useState<number>(1);
  const [totalSets, setTotalSets] = useState<number>(3);
  const [cadenceBpm, setCadenceBpm] = useState<number>(30); // 30 reps per min (2s cycle)
  const [activeCategory, setActiveCategory] = useState<'all' | 'push' | 'legs' | 'core' | 'elite'>('all');
  const [viewTab, setViewTab] = useState<'video' | 'anatomy' | 'checklist'>('video');

  const currentMovement = MOVEMENTS.find((m) => m.id === selectedVideoExercise) || MOVEMENTS[0];
  const animCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number | null>(null);
  const phaseRef = useRef<number>(0);

  // Sync with daily quest target reps if available
  useEffect(() => {
    const matchedQuestEx = currentQuest.exercises.find(
      (e) => e.name.toLowerCase().includes(currentMovement.name.toLowerCase().split(' ')[0])
    );
    if (matchedQuestEx) {
      setTargetReps(matchedQuestEx.repsPerSet);
      setTotalSets(matchedQuestEx.sets);
    }
  }, [currentMovement, currentQuest]);

  // Cadence Metronome & Biomechanical Canvas Loop
  useEffect(() => {
    let lastTime = performance.now();
    let repAccumulator = 0;

    const render = (time: number) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      if (isPlaying) {
        // Speed scaling based on cadence BPM
        const speed = (cadenceBpm / 60) * Math.PI * 2;
        phaseRef.current += dt * speed;

        // Rep detection trigger on sine peak (Apex lockout)
        const currentSin = Math.sin(phaseRef.current);
        const prevSin = Math.sin(phaseRef.current - dt * speed);

        if (prevSin < 0 && currentSin >= 0) {
          // Bottom reached transition or Apex reached
          soundEngine.playBottomValid();
        }

        if (prevSin < 0.98 && currentSin >= 0.98) {
          setRepCount((prev) => {
            const next = prev + 1;
            soundEngine.playRepCounted();
            aiTts.speakRepMilestone(next, targetReps);
            return next;
          });
        }
      }

      // Draw custom cyberpunk kinetic wireframe
      const canvas = animCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          drawKineticAnatomy(ctx, canvas.width, canvas.height, currentMovement.animationType, phaseRef.current);
        }
      }

      requestRef.current = requestAnimationFrame(render);
    };

    requestRef.current = requestAnimationFrame(render);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isPlaying, cadenceBpm, currentMovement, targetReps]);

  const handleFinishCurrentSet = () => {
    soundEngine.playLevelUp();
    completeSet(currentMovement.id, Math.max(1, repCount), 98);
    setRepCount(0);
    if (currentSet < totalSets) {
      setCurrentSet((prev) => prev + 1);
    } else {
      setCurrentSet(1);
    }
  };

  const handleResetSet = () => {
    soundEngine.playClick();
    setRepCount(0);
  };

  const filteredMovements = MOVEMENTS.filter((m) =>
    activeCategory === 'all' ? true : m.category === activeCategory
  );

  return (
    <div className="space-y-6">
      {/* Studio Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900/80 border border-cyan-500/25 backdrop-blur-xl shadow-[0_0_30px_rgba(0,240,255,0.1)]">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-400/40 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.3)]">
            <Layers className="w-6 h-6 text-cyan-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold tracking-widest text-cyan-400 uppercase">
                CALISTHENICS MASTERCLASS
              </span>
              <span className="px-2 py-0.5 rounded-full bg-purple-950/80 text-purple-300 text-[10px] font-mono border border-purple-400/40">
                HD FORM VIDEO HUD
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-['Orbitron'] text-white tracking-wide">
              {currentMovement.name}
            </h2>
          </div>
        </div>

        {/* Dual Mode Split Screen Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleVideoSplitMode}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer border ${
              videoSplitMode
                ? 'bg-cyan-500 text-black border-cyan-300 shadow-[0_0_20px_rgba(0,240,255,0.4)]'
                : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-cyan-400/50'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>{videoSplitMode ? 'SPLIT CAMERA ACTIVE' : 'SPLIT SCREEN DUAL MODE'}</span>
          </button>
        </div>
      </div>

      {/* Main Studio Viewport (Split or Solo) */}
      <div className={`grid gap-6 ${videoSplitMode ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
        {/* Left: Masterclass Interactive Movement Canvas & Video Player */}
        <div className="rounded-3xl bg-[#08090d] border border-cyan-500/30 overflow-hidden shadow-[0_0_40px_rgba(0,240,255,0.15)] flex flex-col relative">
          {/* Top Video Stage Controls */}
          <div className="p-3.5 bg-slate-950/90 border-b border-cyan-500/20 flex items-center justify-between z-10">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-mono text-cyan-300 font-bold">
                BIOMECHANICAL CADENCE: {cadenceBpm} BPM
              </span>
            </div>

            {/* View Mode Selector Tabs */}
            <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-[11px] font-mono">
              <button
                onClick={() => setViewTab('video')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  viewTab === 'video' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                }`}
              >
                KINETIC HUD
              </button>
              <button
                onClick={() => setViewTab('anatomy')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  viewTab === 'anatomy' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                }`}
              >
                ANATOMY
              </button>
              <button
                onClick={() => setViewTab('checklist')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  viewTab === 'checklist' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                }`}
              >
                FORM CUES
              </button>
            </div>
          </div>

          {/* Interactive Screen Display */}
          <div className="relative w-full h-[360px] sm:h-[420px] bg-[#050608] flex items-center justify-center overflow-hidden">
            {viewTab === 'video' && (
              <>
                <canvas
                  ref={animCanvasRef}
                  width={640}
                  height={420}
                  className="w-full h-full object-contain"
                />

                {/* Overlaid Biomechanical HUD Telemetry */}
                <div className="absolute top-4 left-4 p-3 rounded-2xl bg-black/70 backdrop-blur-md border border-cyan-500/30 text-xs font-mono space-y-1 pointer-events-none">
                  <div className="text-cyan-400 font-bold flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5" />
                    <span>TARGET DEPTH: ≤ {currentMovement.targetAngle}°</span>
                  </div>
                  <div className="text-slate-300">LOCKOUT APEX: ≥ {currentMovement.lockoutAngle}°</div>
                  <div className="text-amber-400 font-bold">TEMPO: {currentMovement.tempo}</div>
                </div>

                {/* Current Set Rep Counter Floating Badge */}
                <div className="absolute top-4 right-4 p-3 rounded-2xl bg-black/70 backdrop-blur-md border border-purple-500/40 text-right pointer-events-none">
                  <div className="text-[10px] font-mono text-purple-300 tracking-wider">SET {currentSet} OF {totalSets}</div>
                  <div className="text-2xl sm:text-3xl font-black font-['Orbitron'] text-cyan-300">
                    {repCount} <span className="text-sm font-mono text-slate-400">/ {targetReps}</span>
                  </div>
                </div>
              </>
            )}

            {viewTab === 'anatomy' && (
              <div className="w-full h-full p-6 overflow-y-auto space-y-4 bg-slate-950/95">
                <h3 className="text-sm font-['Orbitron'] text-cyan-300 font-bold tracking-wider">
                  PRIMARY MUSCULAR RECRUITMENT
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentMovement.primaryMuscles.map((muscle, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/40 flex items-center gap-2 text-cyan-200 text-xs font-mono font-bold"
                    >
                      <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>{muscle}</span>
                    </div>
                  ))}
                </div>

                <h3 className="text-sm font-['Orbitron'] text-purple-300 font-bold tracking-wider pt-2">
                  SECONDARY & STABILIZING TENDONS
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentMovement.secondaryMuscles.map((muscle, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/40 flex items-center gap-2 text-purple-200 text-xs font-mono"
                    >
                      <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0" />
                      <span>{muscle}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {viewTab === 'checklist' && (
              <div className="w-full h-full p-6 overflow-y-auto space-y-4 bg-slate-950/95 text-xs font-mono">
                <div>
                  <h3 className="text-sm font-['Orbitron'] text-emerald-400 font-bold tracking-wider mb-2 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>SYSTEM EXECUTION PROTOCOL</span>
                  </h3>
                  <ul className="space-y-2">
                    {currentMovement.formCues.map((cue, idx) => (
                      <li key={idx} className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-200 flex items-start gap-2">
                        <span className="text-emerald-400 font-bold">0{idx + 1}.</span>
                        <span>{cue}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-sm font-['Orbitron'] text-red-400 font-bold tracking-wider mb-2 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    <span>ANTI-CHEAT CRITICAL ERRORS</span>
                  </h3>
                  <ul className="space-y-2">
                    {currentMovement.commonMistakes.map((mistake, idx) => (
                      <li key={idx} className="p-2.5 rounded-xl bg-red-950/20 border border-red-500/30 text-red-200 flex items-start gap-2">
                        <span className="text-red-400 font-bold">✗</span>
                        <span>{mistake}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Interactive Workout Controls */}
          <div className="p-4 bg-slate-950 border-t border-cyan-500/20 flex flex-wrap items-center justify-between gap-3">
            {/* Play/Pause Cadence & Speed Slider */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  setIsPlaying(!isPlaying);
                }}
                className="p-3 rounded-2xl bg-cyan-500 text-black hover:bg-cyan-400 transition-all font-bold cursor-pointer shadow-[0_0_20px_rgba(0,240,255,0.4)]"
                title={isPlaying ? 'Pause Metronome Loop' : 'Resume Metronome Loop'}
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
              </button>

              <button
                onClick={handleResetSet}
                className="p-3 rounded-2xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all cursor-pointer"
                title="Reset Rep Counter"
              >
                <RotateCcw className="w-5 h-5" />
              </button>

              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-slate-400">PACE:</span>
                <input
                  type="range"
                  min="20"
                  max="45"
                  value={cadenceBpm}
                  onChange={(e) => setCadenceBpm(Number(e.target.value))}
                  className="w-20 accent-cyan-400 cursor-pointer"
                />
                <span className="text-cyan-300 font-bold">{cadenceBpm} BPM</span>
              </div>
            </div>

            {/* Set Management Action Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleFinishCurrentSet}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-black font-bold text-xs font-mono hover:from-emerald-400 hover:to-teal-500 transition-all cursor-pointer shadow-[0_0_20px_rgba(16,185,129,0.3)] flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>COMPLETE SET ({repCount} REPS)</span>
              </button>

              {onStartInVisionAI && (
                <button
                  onClick={() => onStartInVisionAI(currentMovement.id)}
                  className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold text-xs font-mono hover:from-cyan-400 transition-all cursor-pointer shadow-[0_0_20px_rgba(0,240,255,0.3)] flex items-center gap-1.5"
                >
                  <Camera className="w-4 h-4" />
                  <span className="hidden sm:inline">LAUNCH CAMERA</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right Split: Live AI Vision Tracker in Dual Mode */}
        {videoSplitMode && (
          <div className="rounded-3xl bg-black border border-cyan-500/30 overflow-hidden shadow-[0_0_40px_rgba(0,240,255,0.2)] h-[480px] sm:h-[540px]">
            <VisionTracker overrideExerciseId={currentMovement.id} />
          </div>
        )}
      </div>

      {/* Movement Library Grid */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="text-base font-black font-['Orbitron'] text-white tracking-wider flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>CALISTHENICS PROGRESSION MATRIX</span>
          </h3>

          {/* Category Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {(['all', 'push', 'legs', 'core', 'elite'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  soundEngine.playClick();
                  setActiveCategory(cat);
                }}
                className={`px-3 py-1 rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === cat
                    ? 'bg-cyan-500 text-black shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                    : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMovements.map((move) => {
            const isSelected = move.id === selectedVideoExercise;
            return (
              <div
                key={move.id}
                onClick={() => {
                  soundEngine.playClick();
                  setSelectedVideoExercise(move.id);
                  setRepCount(0);
                  aiTts.speak(`Masterclass selected: ${move.name}.`);
                }}
                className={`p-5 rounded-3xl transition-all duration-300 cursor-pointer relative overflow-hidden border flex flex-col justify-between gap-3 ${
                  isSelected
                    ? 'bg-gradient-to-br from-cyan-950/50 to-blue-950/40 border-cyan-400 shadow-[0_0_25px_rgba(0,240,255,0.25)]'
                    : 'bg-slate-900/60 border-slate-800/80 hover:border-cyan-500/40 hover:bg-slate-900'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                      {move.difficulty}
                    </span>
                    <span className="text-[10px] font-mono text-purple-300 font-bold">
                      {move.rankRequired}
                    </span>
                  </div>

                  <h4 className="text-base font-bold font-['Orbitron'] text-white">
                    {move.name}
                  </h4>

                  <p className="text-xs text-slate-400 line-clamp-2">
                    {move.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] font-mono text-slate-400">
                  <span>TEMPO: {move.tempo}</span>
                  <span className="text-cyan-400 font-bold flex items-center gap-1">
                    <span>VIEW</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// Kinetic Calisthenics Anatomy Drawing Routine (Mathematical Canvas Engine)
function drawKineticAnatomy(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  type: VideoMovement['animationType'],
  phase: number
) {
  ctx.clearRect(0, 0, width, height);

  // Background Cyber Grid
  ctx.strokeStyle = 'rgba(0, 240, 255, 0.05)';
  ctx.lineWidth = 1;
  const gridSize = 40;
  for (let x = 0; x < width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 0; y < height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // Ground Line
  const groundY = height * 0.78;
  ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(40, groundY);
  ctx.lineTo(width - 40, groundY);
  ctx.stroke();

  const cycle = (Math.sin(phase) + 1) / 2; // 0 (bottom) to 1 (top)

  if (type === 'pushup' || type === 'diamond' || type === 'archer' || type === 'pseudo_planche') {
    // Pushup Wireframe Model
    const headX = width * 0.68;
    const feetX = width * 0.25;
    const feetY = groundY - 10;

    const shoulderMinY = groundY - 55;
    const shoulderMaxY = groundY - 145;
    const shoulderY = shoulderMinY + cycle * (shoulderMaxY - shoulderMinY);
    const shoulderX = width * 0.58;

    const handX = shoulderX + (type === 'pseudo_planche' ? -35 : 0);
    const handY = groundY;

    const hipX = width * 0.42;
    const hipY = shoulderY + (feetY - shoulderY) * 0.4;

    // Draw Floor Contact Points
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(handX, handY, 6, 0, Math.PI * 2);
    ctx.arc(feetX, feetY, 6, 0, Math.PI * 2);
    ctx.fill();

    // Body Spine Line
    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(feetX, feetY);
    ctx.lineTo(hipX, hipY);
    ctx.lineTo(shoulderX, shoulderY);
    ctx.stroke();

    // Head
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(headX, shoulderY - 15, 16, 0, Math.PI * 2);
    ctx.fill();

    // Arm (Elbow joint calculation)
    const elbowX = (shoulderX + handX) / 2 + (type === 'diamond' ? 25 : 35) * (1 - cycle);
    const elbowY = (shoulderY + handY) / 2 - 10 * (1 - cycle);

    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(shoulderX, shoulderY);
    ctx.lineTo(elbowX, elbowY);
    ctx.lineTo(handX, handY);
    ctx.stroke();

    // Joint glowing dots
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(elbowX, elbowY, 5, 0, Math.PI * 2);
    ctx.arc(shoulderX, shoulderY, 5, 0, Math.PI * 2);
    ctx.fill();

    // Calculated Real-Time Elbow Angle Display
    const angle = Math.round(80 + cycle * 80);
    ctx.fillStyle = angle <= 90 ? '#00f0ff' : '#10b981';
    ctx.font = "bold 14px 'Share Tech Mono'";
    ctx.fillText(`${angle}°`, elbowX + 15, elbowY);
  } else if (type === 'squat' || type === 'pistol') {
    // Squat Wireframe Model
    const centerX = width * 0.5;
    const feetY = groundY;

    const hipMinY = groundY - 60;
    const hipMaxY = groundY - 150;
    const hipY = hipMinY + cycle * (hipMaxY - hipMinY);

    const shoulderY = hipY - 90;
    const headY = shoulderY - 25;

    // Spine
    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(centerX, hipY);
    ctx.lineTo(centerX + (1 - cycle) * 15, shoulderY);
    ctx.stroke();

    // Head
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(centerX + (1 - cycle) * 15, headY, 18, 0, Math.PI * 2);
    ctx.fill();

    // Legs (Knee joints)
    const kneeX = centerX + 40 * (1 - cycle);
    const kneeY = (hipY + feetY) / 2 + 10 * (1 - cycle);

    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(centerX, hipY);
    ctx.lineTo(kneeX, kneeY);
    ctx.lineTo(centerX, feetY);
    ctx.stroke();

    if (type === 'pistol') {
      // Extended leg
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
      ctx.beginPath();
      ctx.moveTo(centerX, hipY);
      ctx.lineTo(centerX + 90, hipY + 10);
      ctx.stroke();
    }

    const kneeAngle = Math.round(75 + cycle * 95);
    ctx.fillStyle = kneeAngle <= 90 ? '#00f0ff' : '#10b981';
    ctx.font = "bold 14px 'Share Tech Mono'";
    ctx.fillText(`${kneeAngle}°`, kneeX + 15, kneeY);
  } else {
    // Plank Static Wireframe
    const headX = width * 0.72;
    const feetX = width * 0.22;
    const feetY = groundY - 10;
    const shoulderY = groundY - 45;
    const elbowX = width * 0.62;

    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(feetX, feetY);
    ctx.lineTo(width * 0.45, shoulderY);
    ctx.lineTo(elbowX, shoulderY);
    ctx.stroke();

    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(headX, shoulderY - 10, 16, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(elbowX, shoulderY);
    ctx.lineTo(elbowX, groundY);
    ctx.lineTo(elbowX + 35, groundY);
    ctx.stroke();

    ctx.fillStyle = '#10b981';
    ctx.font = "bold 14px 'Share Tech Mono'";
    ctx.fillText('180° RIGID SPINE', width * 0.38, shoulderY - 20);
  }
}
