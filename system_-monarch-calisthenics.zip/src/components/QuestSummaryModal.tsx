import React from 'react';
import { Award, CheckCircle2, Flame, Sparkles, Zap, ShieldCheck } from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';

export const QuestSummaryModal: React.FC = () => {
  const { currentQuest, profile, streak, closeModal, openModal } = useGameStore();

  const handleClaim = () => {
    soundEngine.playLevelUp();
    closeModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl animate-fade-in">
      <div className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#0c1322] via-[#08090d] to-[#050608] border-2 border-emerald-400 shadow-[0_0_80px_rgba(16,185,129,0.4)] text-slate-100 p-6 sm:p-8 text-center space-y-6 overflow-hidden">
        {/* Glow */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none" />

        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-400 text-emerald-300 text-xs font-mono font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(16,185,129,0.3)]">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            QUEST OBJECTIVE CLEARED
          </div>

          <h2 className="text-2xl sm:text-3xl font-black font-['Orbitron'] text-white tracking-wider pt-2">
            DAILY PROTOCOL COMPLETE!
          </h2>

          <p className="text-xs font-mono text-slate-300 max-w-sm mx-auto">
            You have successfully conquered all Calisthenics drills for today with AI computer vision verification.
          </p>
        </div>

        {/* Rewards grid */}
        <div className="grid grid-cols-3 gap-3 relative z-10 font-mono">
          <div className="p-3.5 rounded-2xl bg-black/60 border border-cyan-500/40">
            <div className="text-[10px] text-cyan-400 font-bold">EXP AWARDED</div>
            <div className="text-lg font-black text-white mt-1">+{currentQuest.rewards.xp} XP</div>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/60 border border-purple-500/40">
            <div className="text-[10px] text-purple-400 font-bold">STAT POINTS</div>
            <div className="text-lg font-black text-white mt-1">+{currentQuest.rewards.statPoints} PTS</div>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/60 border border-amber-500/40">
            <div className="text-[10px] text-amber-400 font-bold">STREAK BADGE</div>
            <div className="text-lg font-black text-amber-300 mt-1 flex items-center justify-center gap-1">
              <Flame className="w-4 h-4 text-amber-400" />
              {streak} Days
            </div>
          </div>
        </div>

        {/* Claim Rewards & Debrief Actions */}
        <div className="space-y-2 relative z-10">
          <button
            onClick={() => {
              soundEngine.playLevelUp();
              openModal('debrief');
            }}
            className="w-full py-3.5 px-6 rounded-2xl font-['Orbitron'] font-black text-xs sm:text-sm tracking-wider bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(139,92,246,0.4)] cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-cyan-300 animate-pulse" />
            <span>AI BIOMECHANICAL AUDIT & STAT ADVISOR</span>
          </button>

          <button
            onClick={handleClaim}
            className="w-full py-3 px-6 rounded-2xl font-['Orbitron'] font-bold text-xs tracking-widest bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:border-cyan-400 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>CLAIM REWARDS & CLOSE</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuestSummaryModal;
