import React, { useState, useEffect } from 'react';
import {
  Award,
  Lock,
  Unlock,
  CheckCircle2,
  ChevronRight,
  Flame,
  Zap,
  Target,
  Play,
  Shield,
  Activity,
  Video,
  ExternalLink,
  Sparkles,
  Search,
  X,
  Clock,
  BookOpen,
  Eye,
  Maximize2
} from 'lucide-react';
import { useGameStore } from '../store/useGameStore';
import { soundEngine } from '../utils/soundEngine';
import { fetchSkillVideos } from '../services/geminiService';
import { SkillVideoItem } from '../server/skillVideosBackend';

interface SkillNode {
  id: string;
  name: string;
  category: 'push' | 'pull' | 'core' | 'balance' | 'isometric';
  tier: 1 | 2 | 3 | 4;
  xpCost: number;
  prerequisites: string[];
  description: string;
  masteryBenchmark: string;
  cameraExerciseId: string;
}

const SKILL_TREE: SkillNode[] = [
  // TIER 1: FOUNDATION
  {
    id: 'push-knee',
    name: 'Incline / Knee Push-Up',
    category: 'push',
    tier: 1,
    xpCost: 0,
    prerequisites: [],
    description: 'Foundation kinetic angle control, establishing 45° elbow arrowhead tuck.',
    masteryBenchmark: '3 Sets of 15 Reps with 85° Depth',
    cameraExerciseId: 'pushup',
  },
  {
    id: 'push-standard',
    name: 'Strict 45° Standard Push-Up',
    category: 'push',
    tier: 1,
    xpCost: 100,
    prerequisites: ['push-knee'],
    description: 'The golden baseline. Strict hollow body plank and full scapular protraction.',
    masteryBenchmark: '20 Strict Reps with Locked Core',
    cameraExerciseId: 'pushup',
  },
  {
    id: 'plank-hollow',
    name: 'Hollow Body Isometric Plank',
    category: 'core',
    tier: 1,
    xpCost: 50,
    prerequisites: [],
    description: 'Posterior pelvic tilt and anti-extension trunk rigidity for levers.',
    masteryBenchmark: '60 Seconds Continuous Hold',
    cameraExerciseId: 'plank',
  },

  // TIER 2: INTERMEDIATE
  {
    id: 'push-diamond',
    name: 'Diamond Triceps Leverage',
    category: 'push',
    tier: 2,
    xpCost: 300,
    prerequisites: ['push-standard'],
    description: 'Close hand positioning directing load onto triceps and medial chest fibers.',
    masteryBenchmark: '12 Strict Reps to Chest Tap',
    cameraExerciseId: 'diamond_pushup',
  },
  {
    id: 'push-archer',
    name: 'Archer Push-Up',
    category: 'push',
    tier: 2,
    xpCost: 450,
    prerequisites: ['push-standard'],
    description: 'Unilateral overload transitioning toward one-arm pressing.',
    masteryBenchmark: '8 Reps per Side with Straight Assist Arm',
    cameraExerciseId: 'archer_pushup',
  },
  {
    id: 'push-pike',
    name: 'Elevated Pike Push-Up',
    category: 'balance',
    tier: 2,
    xpCost: 400,
    prerequisites: ['push-standard'],
    description: 'Vertical pressing development targeting anterior deltoids and trapezius.',
    masteryBenchmark: '10 Reps with Head Touching Forward Floor',
    cameraExerciseId: 'pike_pushup',
  },
  {
    id: 'core-lsit',
    name: 'L-Sit Ground / Bar Hold',
    category: 'core',
    tier: 2,
    xpCost: 500,
    prerequisites: ['plank-hollow'],
    description: 'Depression of scapula with 90° straight leg hip flexion hold.',
    masteryBenchmark: '20 Seconds Clean L-Sit',
    cameraExerciseId: 'lsit',
  },

  // TIER 3: ADVANCED
  {
    id: 'planche-lean',
    name: 'Planche Lean Protraction',
    category: 'isometric',
    tier: 3,
    xpCost: 800,
    prerequisites: ['push-diamond', 'core-lsit'],
    description: 'Forward center of mass displacement with maximum scapular protraction.',
    masteryBenchmark: '45° Forward Lean Hold for 25s',
    cameraExerciseId: 'planche_lean',
  },
  {
    id: 'handstand-wall',
    name: 'Wall Handstand Push-Up',
    category: 'balance',
    tier: 3,
    xpCost: 850,
    prerequisites: ['push-pike'],
    description: 'Full inverted bodyweight vertical press with tripod head touch.',
    masteryBenchmark: '6 Full Depth Reps',
    cameraExerciseId: 'handstand_pushup',
  },
  {
    id: 'planche-tuck',
    name: 'Tuck Planche Static Hold',
    category: 'isometric',
    tier: 3,
    xpCost: 1200,
    prerequisites: ['planche-lean'],
    description: 'Full elevation of feet off ground with knees tucked tight to chest.',
    masteryBenchmark: '15 Seconds Stable Hold',
    cameraExerciseId: 'planche_lean',
  },

  // TIER 4: ELITE MONARCH
  {
    id: 'planche-full',
    name: 'Full Straddle / Full Planche',
    category: 'isometric',
    tier: 4,
    xpCost: 2500,
    prerequisites: ['planche-tuck'],
    description: 'The pinnacle of straight-arm pressing power and horizontal leverage.',
    masteryBenchmark: '10 Seconds Full Planche Hold',
    cameraExerciseId: 'planche_lean',
  },
  {
    id: 'handstand-freestanding',
    name: 'Freestanding 90° Push-Up',
    category: 'balance',
    tier: 4,
    xpCost: 3000,
    prerequisites: ['handstand-wall'],
    description: 'Descent from freestanding handstand into bent arm planche and press back up.',
    masteryBenchmark: '3 Freestanding Strict Reps',
    cameraExerciseId: 'handstand_pushup',
  },
];

interface CalisthenicsMasterTreeProps {
  onStartExercise: (exerciseId: string) => void;
}

export const CalisthenicsMasterTree: React.FC<CalisthenicsMasterTreeProps> = ({
  onStartExercise,
}) => {
  const { profile } = useGameStore();
  const [selectedSkill, setSelectedSkill] = useState<SkillNode>(SKILL_TREE[1]);
  const [filterTier, setFilterTier] = useState<number>(0);

  // Video Discovery State
  const [videos, setVideos] = useState<SkillVideoItem[]>([]);
  const [isLoadingVideos, setIsLoadingVideos] = useState<boolean>(false);
  const [activeVideoModal, setActiveVideoModal] = useState<SkillVideoItem | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'videos'>('overview');

  // Load videos for selected skill
  useEffect(() => {
    let isMounted = true;
    const loadSkillVideos = async () => {
      setIsLoadingVideos(true);
      try {
        const res = await fetchSkillVideos({
          skillId: selectedSkill.id,
          skillName: selectedSkill.name,
          category: selectedSkill.category,
          tier: selectedSkill.tier,
          exerciseId: selectedSkill.cameraExerciseId,
        });
        if (isMounted && res && res.videos) {
          setVideos(res.videos);
        }
      } catch (err) {
        console.warn('Video discovery notice:', err);
      } finally {
        if (isMounted) {
          setIsLoadingVideos(false);
        }
      }
    };

    loadSkillVideos();
    return () => {
      isMounted = false;
    };
  }, [selectedSkill.id, selectedSkill.name, selectedSkill.category, selectedSkill.tier, selectedSkill.cameraExerciseId]);

  // Determine unlocked skills based on player level & XP
  const isSkillUnlocked = (skill: SkillNode) => {
    if (skill.tier === 1) return true;
    if (skill.tier === 2 && profile.level >= 2) return true;
    if (skill.tier === 3 && profile.level >= 5) return true;
    if (skill.tier === 4 && profile.level >= 10) return true;
    return false;
  };

  const filteredSkills =
    filterTier === 0
      ? SKILL_TREE
      : SKILL_TREE.filter((s) => s.tier === filterTier);

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 pb-24 text-white">
      {/* Skill Tree Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
              <Award className="w-4 h-4 text-white" />
              <span>MONARCH CALISTHENICS MASTERY ARCHITECTURE</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black font-['Orbitron'] tracking-wider text-white mt-1">
              PROGRESSION SKILL TREE
            </h1>
            <p className="text-xs font-mono text-neutral-400 mt-1">
              Progressive biomechanical mastery coupled with verified masterclass video tutorials.
            </p>
          </div>

          <div className="px-4 py-2 rounded-2xl bg-neutral-900 border border-neutral-800 text-right">
            <span className="text-[9px] font-mono text-neutral-500 uppercase block">ATHLETE RANK</span>
            <span className="text-sm font-black font-['Orbitron'] text-white">
              LV.{profile.level} • {profile.currentRank}
            </span>
          </div>
        </div>

        {/* Tier Filter Pills */}
        <div className="flex items-center gap-2 mt-6 pt-6 border-t border-neutral-800 overflow-x-auto">
          {[
            { id: 0, label: 'ALL SKILLS' },
            { id: 1, label: 'TIER 1 • FOUNDATION' },
            { id: 2, label: 'TIER 2 • INTERMEDIATE' },
            { id: 3, label: 'TIER 3 • ADVANCED' },
            { id: 4, label: 'TIER 4 • ELITE MONARCH' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => {
                soundEngine.playClick();
                setFilterTier(t.id);
              }}
              className={`px-3.5 py-1.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                filterTier === t.id
                  ? 'bg-white text-black border border-white'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Skill Cards & Detailed Inspector */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Skill Node List */}
        <div className="md:col-span-6 space-y-3">
          {filteredSkills.map((skill) => {
            const unlocked = isSkillUnlocked(skill);
            const isSelected = selectedSkill.id === skill.id;

            return (
              <div
                key={skill.id}
                onClick={() => {
                  soundEngine.playClick();
                  setSelectedSkill(skill);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-neutral-900 border-white shadow-xl'
                    : unlocked
                    ? 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                    : 'bg-neutral-950/60 border-neutral-900 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center font-mono font-bold text-xs ${
                      unlocked
                        ? 'bg-neutral-900 border-neutral-700 text-white'
                        : 'bg-neutral-950 border-neutral-900 text-neutral-600'
                    }`}
                  >
                    {unlocked ? <Unlock className="w-4 h-4 text-white" /> : <Lock className="w-4 h-4 text-neutral-600" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono font-bold text-neutral-500 uppercase">
                        TIER {skill.tier} • {skill.category}
                      </span>
                      {unlocked && (
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-neutral-900 border border-neutral-800 text-neutral-300">
                          READY
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-bold font-['Orbitron'] text-white">
                      {skill.name}
                    </h3>
                  </div>
                </div>

                <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-neutral-600'}`} />
              </div>
            );
          })}
        </div>

        {/* Selected Skill Details & Video Discovery Panel */}
        <div className="md:col-span-6 p-6 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl space-y-5 h-fit">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[9px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
                TIER {selectedSkill.tier} • {selectedSkill.category.toUpperCase()} MASTERY
              </span>
              <h2 className="text-lg sm:text-xl font-black font-['Orbitron'] text-white">
                {selectedSkill.name}
              </h2>
            </div>

            {/* Toggle Tabs: Overview vs Video Masterclasses */}
            <div className="flex items-center bg-neutral-900 p-1 rounded-xl border border-neutral-800">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  setActiveTab('overview');
                }}
                className={`px-3 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                  activeTab === 'overview' ? 'bg-white text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                SPECS
              </button>
              <button
                onClick={() => {
                  soundEngine.playClick();
                  setActiveTab('videos');
                }}
                className={`px-3 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  activeTab === 'videos' ? 'bg-white text-black' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Video className="w-3 h-3" />
                <span>VIDEOS ({videos.length})</span>
              </button>
            </div>
          </div>

          {activeTab === 'overview' ? (
            <>
              <p className="text-xs font-mono text-neutral-300 leading-relaxed">
                {selectedSkill.description}
              </p>

              <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1 text-xs font-mono">
                <span className="text-[10px] text-neutral-500 uppercase block">MASTERY BENCHMARK:</span>
                <div className="text-white font-bold">{selectedSkill.masteryBenchmark}</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1 text-xs font-mono">
                <span className="text-[10px] text-neutral-500 uppercase block">UNLOCK CRITERIA:</span>
                <div className="text-neutral-300">
                  {selectedSkill.tier === 1 ? 'Available immediately for all athletes' : `Requires Level ${selectedSkill.tier * 2} and prerequisites`}
                </div>
              </div>

              {/* Quick Video Preview Strip */}
              {videos.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase flex items-center gap-1">
                      <Video className="w-3 h-3 text-white" />
                      MASTER COACH TUTORIAL
                    </span>
                    <button
                      onClick={() => setActiveTab('videos')}
                      className="text-[10px] font-mono text-neutral-400 hover:text-white underline cursor-pointer"
                    >
                      VIEW ALL ({videos.length})
                    </button>
                  </div>

                  <div
                    onClick={() => setActiveVideoModal(videos[0])}
                    className="group relative rounded-xl overflow-hidden border border-neutral-800 bg-black cursor-pointer hover:border-neutral-600 transition-all flex items-center gap-3 p-2"
                  >
                    <div className="relative w-24 h-14 rounded-lg overflow-hidden shrink-0 bg-neutral-800">
                      <img
                        src={videos[0].thumbnailUrl}
                        alt={videos[0].title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <div className="w-6 h-6 rounded-full bg-white/90 flex items-center justify-center">
                          <Play className="w-3 h-3 fill-black text-black ml-0.5" />
                        </div>
                      </div>
                      <span className="absolute bottom-1 right-1 px-1 py-0.2 rounded bg-black/80 text-[8px] font-mono text-white">
                        {videos[0].duration}
                      </span>
                    </div>

                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs font-bold text-white truncate group-hover:underline">
                        {videos[0].title}
                      </h4>
                      <p className="text-[10px] font-mono text-neutral-400 truncate">
                        {videos[0].channel} • {videos[0].difficulty}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <button
                onClick={() => onStartExercise(selectedSkill.cameraExerciseId)}
                className="w-full py-3.5 px-4 rounded-xl bg-white text-black font-bold font-mono text-xs tracking-wider uppercase hover:bg-neutral-200 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
              >
                <Play className="w-4 h-4 fill-current text-black" />
                <span>TRAIN WITH VISION AI</span>
              </button>
            </>
          ) : (
            /* Video Discovery List */
            <div className="space-y-3">
              <div className="text-[10px] font-mono text-neutral-400">
                Verified calisthenics tutorials for <strong className="text-white">{selectedSkill.name}</strong>:
              </div>

              {isLoadingVideos ? (
                <div className="p-8 text-center space-y-2 border border-neutral-800 rounded-2xl bg-neutral-900">
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-xs font-mono text-neutral-400">DISCOVERING MASTER TUTORIALS...</p>
                </div>
              ) : videos.length === 0 ? (
                <div className="p-6 text-center border border-neutral-800 rounded-2xl bg-neutral-900 text-neutral-400 font-mono text-xs">
                  No video masterclasses found.
                </div>
              ) : (
                <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                  {videos.map((vid) => (
                    <div
                      key={vid.id}
                      onClick={() => setActiveVideoModal(vid)}
                      className="group p-3 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-white transition-all cursor-pointer space-y-2"
                    >
                      <div className="flex gap-3">
                        <div className="relative w-28 h-16 rounded-xl overflow-hidden shrink-0 bg-neutral-800">
                          <img
                            src={vid.thumbnailUrl}
                            alt={vid.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                            <div className="w-7 h-7 rounded-full bg-white flex items-center justify-center shadow-lg">
                              <Play className="w-3.5 h-3.5 fill-black text-black ml-0.5" />
                            </div>
                          </div>
                          <span className="absolute bottom-1 right-1 px-1 py-0.2 rounded bg-black/90 text-[8.5px] font-mono text-white">
                            {vid.duration}
                          </span>
                        </div>

                        <div className="min-w-0 flex-1 space-y-0.5">
                          <div className="flex items-center gap-1.5 text-[8.5px] font-mono text-neutral-400">
                            <span className="px-1.5 py-0.2 rounded bg-neutral-800 border border-neutral-700 text-white font-bold">
                              {vid.difficulty}
                            </span>
                            <span>{vid.relevanceScore}% MATCH</span>
                          </div>
                          <h4 className="text-xs font-bold text-white line-clamp-2 leading-snug group-hover:text-neutral-200">
                            {vid.title}
                          </h4>
                          <p className="text-[10px] font-mono text-neutral-400">
                            {vid.channel}
                          </p>
                        </div>
                      </div>

                      {vid.keyCues && vid.keyCues.length > 0 && (
                        <div className="pt-2 border-t border-neutral-800/80 flex flex-wrap gap-1">
                          {vid.keyCues.map((cue, idx) => (
                            <span
                              key={idx}
                              className="text-[9px] font-mono px-2 py-0.5 rounded-md bg-neutral-950 border border-neutral-800 text-neutral-300"
                            >
                              • {cue}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={() => onStartExercise(selectedSkill.cameraExerciseId)}
                className="w-full py-3 px-4 rounded-xl bg-white text-black font-bold font-mono text-xs tracking-wider uppercase hover:bg-neutral-200 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl mt-2"
              >
                <Play className="w-4 h-4 fill-current text-black" />
                <span>LAUNCH VISION AI TRACKER</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Embedded Video Masterclass Modal */}
      {activeVideoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl bg-neutral-950 border border-neutral-800 shadow-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-white" />
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400">
                  COACHING MASTERCLASS • {activeVideoModal.channel}
                </span>
              </div>
              <button
                onClick={() => setActiveVideoModal(null)}
                className="p-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Official YouTube Embed Player */}
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black border border-neutral-800">
              <iframe
                src={`${activeVideoModal.embedUrl}?autoplay=1&rel=0&modestbranding=1`}
                title={activeVideoModal.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>

            <div className="space-y-2">
              <h3 className="text-sm sm:text-base font-bold font-['Orbitron'] text-white">
                {activeVideoModal.title}
              </h3>
              <div className="flex items-center gap-2 text-[10px] font-mono text-neutral-400">
                <span className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-white font-bold">
                  {activeVideoModal.difficulty}
                </span>
                <span>DURATION: {activeVideoModal.duration}</span>
                <span>•</span>
                <span>CHANNEL: {activeVideoModal.channel}</span>
              </div>
            </div>

            {activeVideoModal.keyCues && activeVideoModal.keyCues.length > 0 && (
              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1 text-xs font-mono">
                <span className="text-[10px] text-neutral-500 uppercase block">KEY BIOMECHANICAL CUES:</span>
                <ul className="list-disc list-inside text-neutral-300 space-y-0.5 text-[11px]">
                  {activeVideoModal.keyCues.map((cue, idx) => (
                    <li key={idx}>{cue}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <a
                href={activeVideoModal.videoUrl}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2.5 px-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-600 text-neutral-300 hover:text-white font-mono text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>OPEN ON YOUTUBE</span>
              </a>

              <button
                onClick={() => {
                  setActiveVideoModal(null);
                  onStartExercise(selectedSkill.cameraExerciseId);
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-white text-black font-mono text-xs font-bold hover:bg-neutral-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg"
              >
                <Play className="w-3.5 h-3.5 fill-black text-black" />
                <span>START VISION AI REPS</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalisthenicsMasterTree;
