/**
 * SYSTEM: MONARCH CALISTHENICS - Advanced 3D Computer Vision Biomechanical Engine
 * Cinematic Black & White / High-Contrast Precision HUD,
 * Sub-Pixel 2nd-Order EMA Landmark Smoothing with Velocity Clamping (α = 0.70),
 * Scalable Exercise Registry (Push-ups, Diamond Push-ups, Wide Push-ups, Pike Push-ups, Squats, Pistol Squats, Planks, Lunges),
 * Deterministic Form Scoring (0-100%), Ghost Trainer Pose Matching & Match Score,
 * Diamond Hand Placement Target Zone (◇), Motion Trails & Trajectory Path,
 * and Dynamic Bone Flaw Highlighting (Electric Cyan for valid, Crimson #ff003c for flawed).
 */

import {
  ExerciseDefinition,
  getExerciseDefinition,
  EXERCISE_DEFINITIONS,
  ExerciseId
} from './exerciseDefinitions';

export type { ExerciseDefinition, ExerciseId };
export { getExerciseDefinition, EXERCISE_DEFINITIONS };

export interface Landmark {
  x: number;
  y: number;
  z?: number;
  visibility?: number;
}

export type ExerciseType =
  | 'pushup'
  | 'diamond_pushup'
  | 'wide_pushup'
  | 'archer_pushup'
  | 'pike_pushup'
  | 'squat'
  | 'pistol_squat'
  | 'plank'
  | 'planche_lean'
  | 'lsit'
  | 'handstand_pushup'
  | 'lunge';

export type RepPhase =
  | 'LOCKED_UP'           // Phase 0: Lockout apex (θ > 160°, visibility >= 0.65)
  | 'DESCENDING'          // Phase 1: Controlled eccentric descent
  | 'CHEST_DEPTH_REACHED' // Phase 2: Valid depth inflection (θ <= 85°, held >= 80ms)
  | 'ASCENDING'           // Phase 3: Concentric ascent with proper alignment
  | 'REP_VALIDATED'       // Phase 4: Rep completed and validated with high score
  | 'FORM_INVALID';       // Rep invalidated due to posture break

export interface BoneFlawMap {
  spine: boolean;
  leftUpperArm: boolean;
  rightUpperArm: boolean;
  leftForearm: boolean;
  rightForearm: boolean;
  wrists: boolean;
  leftThigh: boolean;
  rightThigh: boolean;
  leftShin: boolean;
  rightShin: boolean;
  hips: boolean;
  neck: boolean;
}

export interface HandPlacementGuide {
  ratio: number;           // Distance(wrists) / Distance(shoulders)
  idealMin: number;
  idealMax: number;
  status: 'valid' | 'too_wide' | 'too_narrow' | 'too_forward' | 'too_back';
  cueText: string;
  diamondCenter?: { x: number; y: number };
}

export interface FormBreakdown {
  alignmentScore: number;     // 0-100%
  elbowScore: number;         // 0-100%
  depthScore: number;         // 0-100%
  handScore: number;          // 0-100%
  symmetryScore: number;      // 0-100%
  primaryIssue: string;
  whyExplanation: string;
  howToFixCue: string;
}

export interface GhostMatchData {
  ghostLandmarks: Landmark[];
  matchScore: number;         // 0-100%
  isAligned: boolean;
  statusText: string;
}

export interface VisionQualityStatus {
  status: 'CALIBRATING' | 'READY' | 'WARNING' | 'CRITICAL';
  confidenceScore: number;    // 0-100%
  framingMessage: string;
  lightingQuality: 'OPTIMAL' | 'FAIR' | 'POOR';
  isCalibrated: boolean;
}

export interface MotionTrailPoint {
  x: number;
  y: number;
  timestamp: number;
  type: 'elbow' | 'knee' | 'wrist';
}

export interface FormAnalysisResult {
  primaryAngle: number;         // Primary Joint Angle (e.g. Elbow θ or Knee θ)
  secondaryAngle: number;       // Secondary Joint Angle (e.g. Spine θ)
  repPhase: RepPhase;
  repCount: number;
  feedbackText: string;
  feedbackSeverity: 'info' | 'success' | 'warning' | 'error';
  depthPercentage: number;      // 0 to 100%
  formScore: number;            // Deterministic Real-time 0 to 100%
  formGrade: 'S' | 'A' | 'B' | 'C' | 'F';
  isCheatDetected: boolean;
  cheatReason?: string;
  isBottomTriggered: boolean;   // Signals "Depth Valid" audio ping
  isRepCountedTriggered: boolean; // Signals rep increment and XP celebration
  holdDurationMs: number;
  spineAngle: number;
  isSpineAligned: boolean;
  visibilityScore: number;
  isBodyInFrame: boolean;
  framingWarning?: string;
  isElbowTucked: boolean;
  elbowSpineProjection: number;
  handPlacement: HandPlacementGuide;
  movementVector: 'DESCEND' | 'DRIVE' | 'HOLD' | 'STABILIZE';
  flawType?: 'waist_sagging' | 'shallow_depth' | 'flared_elbows' | 'hand_width' | 'squat_shallow' | 'plank_sagging' | 'pike_angle';
  boneFlaws: BoneFlawMap;
  fatigueWarning: boolean;

  // V2 Upgrades
  ghostMatch?: GhostMatchData;
  formBreakdown?: FormBreakdown;
  visionQuality?: VisionQualityStatus;

  // Exercise Awareness & Definition
  exerciseDefinition?: ExerciseDefinition;
  primaryAngleName?: string;
  secondaryAngleName?: string;
  cameraAdviceText?: string;
  placementStatusText?: string;
  currentExerciseName?: string;
  isReadyForExercise?: boolean;
  calibrationHint?: string;
  orientation?: string;
}

// MediaPipe Pose Landmark Indices (Standard 33 keypoints)
export const POSE_LANDMARKS = {
  NOSE: 0,
  LEFT_EYE: 2,
  RIGHT_EYE: 5,
  LEFT_SHOULDER: 11,
  RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13,
  RIGHT_ELBOW: 14,
  LEFT_WRIST: 15,
  RIGHT_WRIST: 16,
  LEFT_PINKY: 17,
  RIGHT_PINKY: 18,
  LEFT_INDEX: 19,
  RIGHT_INDEX: 20,
  LEFT_HIP: 23,
  RIGHT_HIP: 24,
  LEFT_KNEE: 25,
  RIGHT_KNEE: 26,
  LEFT_ANKLE: 27,
  RIGHT_ANKLE: 28,
  LEFT_HEEL: 29,
  RIGHT_HEEL: 30,
  LEFT_FOOT_INDEX: 31,
  RIGHT_FOOT_INDEX: 32,
};

/**
 * 2nd-Order Exponential Moving Average (EMA) Smoother with Velocity Clamping
 * P_filtered(t) = α * P_raw(t) + (1 - α) * (P_prev + V_prev) (α = 0.70)
 * Eliminates sub-pixel jitter, noise, and sudden camera glitch leaps.
 */
export class LandmarkSmoother {
  private smoothedLandmarks: Landmark[] = [];
  private velocities: { vx: number; vy: number; vz: number }[] = [];
  private alpha: number;
  private readonly maxVelocity: number = 0.12; // Clamping maximum displacement per frame

  constructor(alpha: number = 0.70) {
    this.alpha = Math.max(0.01, Math.min(1.0, alpha));
  }

  public setAlpha(alpha: number) {
    this.alpha = Math.max(0.01, Math.min(1.0, alpha));
  }

  public reset() {
    this.smoothedLandmarks = [];
    this.velocities = [];
  }

  public smooth(rawLandmarks: Landmark[]): Landmark[] {
    if (!rawLandmarks || rawLandmarks.length === 0) {
      return [];
    }

    if (this.smoothedLandmarks.length !== rawLandmarks.length) {
      this.smoothedLandmarks = rawLandmarks.map((pt) => ({
        x: pt.x,
        y: pt.y,
        z: pt.z || 0,
        visibility: pt.visibility !== undefined ? pt.visibility : 1.0,
      }));
      this.velocities = rawLandmarks.map(() => ({ vx: 0, vy: 0, vz: 0 }));
      return this.smoothedLandmarks;
    }

    return rawLandmarks.map((raw, i) => {
      const prev = this.smoothedLandmarks[i];
      const vel = this.velocities[i];

      // Estimate raw velocity
      let rawVx = raw.x - prev.x;
      let rawVy = raw.y - prev.y;
      let rawVz = (raw.z || 0) - (prev.z || 0);

      // Clamp max velocity to prevent physics glitch spikes
      const speed = Math.sqrt(rawVx * rawVx + rawVy * rawVy);
      if (speed > this.maxVelocity && speed > 0) {
        const factor = this.maxVelocity / speed;
        rawVx *= factor;
        rawVy *= factor;
      }

      // Smooth velocity
      vel.vx = this.alpha * rawVx + (1 - this.alpha) * vel.vx;
      vel.vy = this.alpha * rawVy + (1 - this.alpha) * vel.vy;
      vel.vz = this.alpha * rawVz + (1 - this.alpha) * vel.vz;

      // Predict and update smoothed position
      const predictedX = prev.x + vel.vx;
      const predictedY = prev.y + vel.vy;
      const predictedZ = (prev.z || 0) + vel.vz;

      const smoothedX = this.alpha * raw.x + (1 - this.alpha) * predictedX;
      const smoothedY = this.alpha * raw.y + (1 - this.alpha) * predictedY;
      const smoothedZ = this.alpha * (raw.z || 0) + (1 - this.alpha) * predictedZ;
      const smoothedVis = this.alpha * (raw.visibility ?? 1.0) + (1 - this.alpha) * (prev.visibility ?? 1.0);

      this.smoothedLandmarks[i] = {
        x: smoothedX,
        y: smoothedY,
        z: smoothedZ,
        visibility: smoothedVis,
      };

      return this.smoothedLandmarks[i];
    });
  }
}

/**
 * Calculates 2D planar joint angle in degrees (0 - 180°) given 3 keypoints:
 * Vertex point B between limbs BA and BC.
 */
export function calculateJointAngle(a: Landmark, b: Landmark, c: Landmark): number {
  if (!a || !b || !c) return 180;

  const bax = a.x - b.x;
  const bay = a.y - b.y;
  const bcx = c.x - b.x;
  const bcy = c.y - b.y;

  const dot = bax * bcx + bay * bcy;
  const magBA = Math.sqrt(bax * bax + bay * bay);
  const magBC = Math.sqrt(bcx * bcx + bcy * bcy);

  if (magBA * magBC === 0) return 180;

  let cosine = dot / (magBA * magBC);
  cosine = Math.max(-1.0, Math.min(1.0, cosine));

  const radians = Math.acos(cosine);
  return (radians * 180) / Math.PI;
}

/**
 * Calculates euclidean distance between two landmarks
 */
export function calculateDistance(a: Landmark, b: Landmark): number {
  if (!a || !b) return 0;
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Dynamic Ghost Trainer Hologram Generator:
 * Computes the anatomically ideal skeleton position for the current user's scale,
 * orientation, exercise, and phase of movement.
 */
export function generateGhostPose(
  landmarks: Landmark[],
  exercise: ExerciseType,
  repPhase: RepPhase,
  depthPercent: number
): Landmark[] {
  if (!landmarks || landmarks.length < 33) return [];

  const ghost = landmarks.map((pt) => ({ ...pt }));

  const lShoulder = landmarks[POSE_LANDMARKS.LEFT_SHOULDER];
  const rShoulder = landmarks[POSE_LANDMARKS.RIGHT_SHOULDER];
  const lHip = landmarks[POSE_LANDMARKS.LEFT_HIP];
  const rHip = landmarks[POSE_LANDMARKS.RIGHT_HIP];
  const lAnkle = landmarks[POSE_LANDMARKS.LEFT_ANKLE];
  const rAnkle = landmarks[POSE_LANDMARKS.RIGHT_ANKLE];
  const lWrist = landmarks[POSE_LANDMARKS.LEFT_WRIST];
  const rWrist = landmarks[POSE_LANDMARKS.RIGHT_WRIST];

  if (!lShoulder || !rShoulder || !lHip || !rHip) return ghost;

  const shoulderY = (lShoulder.y + rShoulder.y) / 2;
  const hipY = (lHip.y + rHip.y) / 2;
  const bodyLen = Math.abs(hipY - shoulderY) || 0.3;

  // Pushup Variations Ghost Pose
  if (exercise.includes('pushup') || exercise === 'plank') {
    // Ideal spine: perfectly straight line from shoulder through hip to ankle
    if (lAnkle && rAnkle) {
      const avgAnkleY = (lAnkle.y + rAnkle.y) / 2;
      const avgAnkleX = (lAnkle.x + rAnkle.x) / 2;
      const avgShoulderX = (lShoulder.x + rShoulder.x) / 2;
      const avgShoulderY = (lShoulder.y + rShoulder.y) / 2;

      // Straight spine hip placement (midpoint interpolation)
      const idealHipX = avgShoulderX + (avgAnkleX - avgShoulderX) * 0.45;
      const idealHipY = avgShoulderY + (avgAnkleY - avgShoulderY) * 0.45;

      ghost[POSE_LANDMARKS.LEFT_HIP] = { ...ghost[POSE_LANDMARKS.LEFT_HIP], x: idealHipX - 0.04, y: idealHipY };
      ghost[POSE_LANDMARKS.RIGHT_HIP] = { ...ghost[POSE_LANDMARKS.RIGHT_HIP], x: idealHipX + 0.04, y: idealHipY };
    }

    // Ideal elbow placement: 45° tucked arrowhead
    const progress = repPhase === 'CHEST_DEPTH_REACHED' ? 1.0 : depthPercent / 100;
    const elbowDropY = shoulderY + bodyLen * 0.35 + progress * (bodyLen * 0.25);

    if (exercise === 'diamond_pushup' && lWrist && rWrist) {
      const midWristX = (lWrist.x + rWrist.x) / 2;
      const midWristY = (lWrist.y + rWrist.y) / 2;
      ghost[POSE_LANDMARKS.LEFT_WRIST] = { ...ghost[POSE_LANDMARKS.LEFT_WRIST], x: midWristX - 0.025, y: midWristY };
      ghost[POSE_LANDMARKS.RIGHT_WRIST] = { ...ghost[POSE_LANDMARKS.RIGHT_WRIST], x: midWristX + 0.025, y: midWristY };
    }

    ghost[POSE_LANDMARKS.LEFT_ELBOW] = {
      ...ghost[POSE_LANDMARKS.LEFT_ELBOW],
      x: lShoulder.x - 0.04 - progress * 0.03,
      y: elbowDropY,
    };
    ghost[POSE_LANDMARKS.RIGHT_ELBOW] = {
      ...ghost[POSE_LANDMARKS.RIGHT_ELBOW],
      x: rShoulder.x + 0.04 + progress * 0.03,
      y: elbowDropY,
    };
  } else if (exercise.includes('squat')) {
    // Ideal Squat: Torso upright (<25° lean), knees track over toes, thighs parallel (<85°) at bottom
    const progress = repPhase === 'CHEST_DEPTH_REACHED' ? 1.0 : depthPercent / 100;
    const squatDepthY = hipY + progress * (bodyLen * 0.7);

    ghost[POSE_LANDMARKS.LEFT_HIP] = { ...ghost[POSE_LANDMARKS.LEFT_HIP], y: squatDepthY };
    ghost[POSE_LANDMARKS.RIGHT_HIP] = { ...ghost[POSE_LANDMARKS.RIGHT_HIP], y: squatDepthY };
    ghost[POSE_LANDMARKS.LEFT_KNEE] = { ...ghost[POSE_LANDMARKS.LEFT_KNEE], x: lShoulder.x - 0.02 };
    ghost[POSE_LANDMARKS.RIGHT_KNEE] = { ...ghost[POSE_LANDMARKS.RIGHT_KNEE], x: rShoulder.x + 0.02 };
  }

  return ghost;
}

/**
 * Deterministic Calisthenics Biomechanical Form Tracker
 * Strict Validation across Push-ups, Diamond Push-ups, Wide Push-ups, Pike Push-ups, Squats, Pistol Squats, Planks, and Lunges.
 */
export class CalisthenicsFormTracker {
  private smoother: LandmarkSmoother = new LandmarkSmoother(0.70);
  private repPhase: RepPhase = 'LOCKED_UP';
  private repCount: number = 0;
  private depthReachedTimestamp: number | null = null;
  private hasHitValidDepth: boolean = false;
  private repHasFormViolation: boolean = false;
  private violationReason: string = '';
  private consecutiveFlawFrames: number = 0;

  private minLockoutAngle: number = 160; // θ > 160° for lockout
  private maxChestDepthAngle: number = 85; // θ <= 85° for chest depth
  private readonly minSpineAngleConstraint: number = 160; // θ_spine >= 160° strict
  private readonly minDepthHoldMs: number = 80;

  // Exercise Definition Awareness
  private currentDefinition: ExerciseDefinition = getExerciseDefinition('pushup');

  // Static hold tracking for Planks / Isometrics
  private plankStartTime: number | null = null;
  private plankHoldSeconds: number = 0;

  // Calibration & Trajectory Buffer
  private calibrationFrames: number = 0;
  private motionTrails: MotionTrailPoint[] = [];

  constructor(lockoutAngle = 160, depthAngle = 85) {
    this.minLockoutAngle = lockoutAngle;
    this.maxChestDepthAngle = depthAngle;
  }

  public setSmoothingAlpha(alpha: number) {
    this.smoother.setAlpha(alpha);
  }

  public setAngles(lockoutAngle: number, depthAngle: number) {
    this.minLockoutAngle = lockoutAngle;
    this.maxChestDepthAngle = depthAngle;
  }

  public setExercise(exercise: string) {
    this.currentDefinition = getExerciseDefinition(exercise);
    this.minLockoutAngle = this.currentDefinition.angleRanges.lockoutMinAngle;
    this.maxChestDepthAngle = this.currentDefinition.angleRanges.inflectionTargetAngle;
    this.reset(0);
  }

  public getCurrentDefinition(): ExerciseDefinition {
    return this.currentDefinition;
  }

  public reset(initialReps = 0) {
    this.smoother.reset();
    this.repPhase = 'LOCKED_UP';
    this.repCount = initialReps;
    this.depthReachedTimestamp = null;
    this.hasHitValidDepth = false;
    this.repHasFormViolation = false;
    this.violationReason = '';
    this.consecutiveFlawFrames = 0;
    this.plankStartTime = null;
    this.plankHoldSeconds = 0;
    this.calibrationFrames = 0;
    this.motionTrails = [];
  }

  public setReps(reps: number) {
    this.repCount = reps;
  }

  public getRepCount(): number {
    return this.repCount;
  }

  public getMotionTrails(): MotionTrailPoint[] {
    return this.motionTrails;
  }

  public analyzeFrame(
    rawLandmarks: Landmark[],
    exercise: ExerciseType = 'pushup',
    antiCheatEnabled = true,
    confidenceThreshold = 0.55
  ): FormAnalysisResult {
    const incomingDef = getExerciseDefinition(exercise);
    if (incomingDef.canonicalKey !== this.currentDefinition.canonicalKey) {
      this.setExercise(exercise);
    }
    const currentDef = this.currentDefinition;

    const defaultFlaws: BoneFlawMap = {
      spine: false,
      leftUpperArm: false,
      rightUpperArm: false,
      leftForearm: false,
      rightForearm: false,
      wrists: false,
      leftThigh: false,
      rightThigh: false,
      leftShin: false,
      rightShin: false,
      hips: false,
      neck: false,
    };

    const defaultHandPlacement: HandPlacementGuide = {
      ratio: 1.0,
      idealMin: currentDef.placementRules.idealRatioMin,
      idealMax: currentDef.placementRules.idealRatioMax,
      status: 'valid',
      cueText: currentDef.placementRules.description,
    };

    if (!rawLandmarks || rawLandmarks.length < 33) {
      return {
        primaryAngle: currentDef.angleRanges.lockoutMinAngle,
        secondaryAngle: 180,
        repPhase: this.repPhase,
        repCount: this.repCount,
        feedbackText: 'POSITION FULL BODY IN FRAME',
        feedbackSeverity: 'warning',
        depthPercentage: 0,
        formScore: 0,
        formGrade: 'F',
        isCheatDetected: false,
        isBottomTriggered: false,
        isRepCountedTriggered: false,
        holdDurationMs: 0,
        spineAngle: 180,
        isSpineAligned: true,
        visibilityScore: 0,
        isBodyInFrame: false,
        framingWarning: 'STEP BACK • FULL BODY NOT VISIBLE',
        isElbowTucked: true,
        elbowSpineProjection: 0,
        handPlacement: defaultHandPlacement,
        movementVector: 'STABILIZE',
        boneFlaws: defaultFlaws,
        fatigueWarning: false,
        exerciseDefinition: currentDef,
        primaryAngleName: currentDef.angleRanges.primaryJointName,
        secondaryAngleName: currentDef.angleRanges.secondaryJointName,
        cameraAdviceText: currentDef.cameraAngleAdvice,
        placementStatusText: defaultHandPlacement.cueText,
        currentExerciseName: currentDef.name,
        visionQuality: {
          status: 'CRITICAL',
          confidenceScore: 0,
          framingMessage: 'MOVE INTO FRAME',
          lightingQuality: 'POOR',
          isCalibrated: false,
        },
      };
    }

    // Step A: 2nd-Order EMA Sub-Pixel Smoothing (α = 0.70)
    const landmarks = this.smoother.smooth(rawLandmarks);

    // Identify dominant visible anatomical side
    const leftArmVis =
      ((landmarks[POSE_LANDMARKS.LEFT_SHOULDER]?.visibility ?? 1) +
        (landmarks[POSE_LANDMARKS.LEFT_ELBOW]?.visibility ?? 1) +
        (landmarks[POSE_LANDMARKS.LEFT_WRIST]?.visibility ?? 1)) / 3;

    const rightArmVis =
      ((landmarks[POSE_LANDMARKS.RIGHT_SHOULDER]?.visibility ?? 1) +
        (landmarks[POSE_LANDMARKS.RIGHT_ELBOW]?.visibility ?? 1) +
        (landmarks[POSE_LANDMARKS.RIGHT_WRIST]?.visibility ?? 1)) / 3;

    const isLeft = leftArmVis >= rightArmVis;
    const dominantArmVis = isLeft ? leftArmVis : rightArmVis;

    // Body in frame validation based on ExerciseDefinition
    let isBodyInFrame = true;
    let framingWarning: string | undefined = undefined;
    for (const req of currentDef.requiredLandmarks) {
      let maxVis = 0;
      for (const idx of req.indices) {
        const vis = landmarks[idx]?.visibility ?? 0;
        if (vis > maxVis) maxVis = vis;
      }
      if (maxVis < confidenceThreshold) {
        isBodyInFrame = false;
        framingWarning = `OBSCURED: ${req.name.toUpperCase()}`;
        break;
      }
    }

    // Determine Orientation
    const currentOrientation = this.determineOrientation(landmarks);

    // Get Primary Angle early for readiness check
    const primaryAngle = this.calculatePrimaryAngle(landmarks, currentDef, isLeft);

    // Readiness Check
    const isReadyForExercise = isBodyInFrame && (primaryAngle >= currentDef.angleRanges.lockoutMinAngle - 10);
    let calibrationHint = framingWarning;
    if (isBodyInFrame && !isReadyForExercise) {
      calibrationHint = `ASSUME START POSITION (${currentDef.angleRanges.primaryJointName} LOCKED)`;
    } else if (isBodyInFrame && isReadyForExercise) {
      calibrationHint = 'POSITION SECURED. HOLD STILL.';
    }

    // Calibration Gate Tracking
    this.calibrationFrames++;
    const isCalibrated = this.calibrationFrames > 20 && isReadyForExercise && dominantArmVis >= confidenceThreshold;

    const visionQuality: VisionQualityStatus = {
      status: isCalibrated ? 'READY' : isBodyInFrame ? 'CALIBRATING' : 'WARNING',
      confidenceScore: Math.round(dominantArmVis * 100),
      framingMessage: framingWarning || (isCalibrated ? 'EXCELLENT ALIGNMENT' : 'CALIBRATING POSE...'),
      lightingQuality: dominantArmVis > 0.75 ? 'OPTIMAL' : dominantArmVis > 0.45 ? 'FAIR' : 'POOR',
      isCalibrated,
    };

    // Low confidence suppression
    if (dominantArmVis < confidenceThreshold) {
      return {
        primaryAngle: currentDef.angleRanges.lockoutMinAngle,
        secondaryAngle: 180,
        repPhase: this.repPhase,
        repCount: this.repCount,
        feedbackText: framingWarning || 'ALIGN IN FRAME (LOW CONFIDENCE)',
        feedbackSeverity: 'warning',
        depthPercentage: 0,
        formScore: 40,
        formGrade: 'C',
        isCheatDetected: false,
        isBottomTriggered: false,
        isRepCountedTriggered: false,
        holdDurationMs: 0,
        spineAngle: 180,
        isSpineAligned: true,
        visibilityScore: dominantArmVis,
        isBodyInFrame: false,
        framingWarning,
        isElbowTucked: true,
        elbowSpineProjection: 0,
        handPlacement: defaultHandPlacement,
        movementVector: 'STABILIZE',
        boneFlaws: defaultFlaws,
        fatigueWarning: false,
        exerciseDefinition: currentDef,
        primaryAngleName: currentDef.angleRanges.primaryJointName,
        secondaryAngleName: currentDef.angleRanges.secondaryJointName,
        cameraAdviceText: currentDef.cameraAngleAdvice,
        placementStatusText: defaultHandPlacement.cueText,
        currentExerciseName: currentDef.name,
        isReadyForExercise: false,
        calibrationHint: calibrationHint || 'LOW CONFIDENCE',
        orientation: currentOrientation,
        visionQuality,
      };
    }

    const leftShoulder = landmarks[POSE_LANDMARKS.LEFT_SHOULDER];
    const rightShoulder = landmarks[POSE_LANDMARKS.RIGHT_SHOULDER];
    const leftWrist = landmarks[POSE_LANDMARKS.LEFT_WRIST];
    const rightWrist = landmarks[POSE_LANDMARKS.RIGHT_WRIST];
    const leftElbow = landmarks[POSE_LANDMARKS.LEFT_ELBOW];
    const rightElbow = landmarks[POSE_LANDMARKS.RIGHT_ELBOW];
    const leftHip = landmarks[POSE_LANDMARKS.LEFT_HIP];
    const rightHip = landmarks[POSE_LANDMARKS.RIGHT_HIP];
    const leftKnee = landmarks[POSE_LANDMARKS.LEFT_KNEE];
    const rightKnee = landmarks[POSE_LANDMARKS.RIGHT_KNEE];
    const leftAnkle = landmarks[POSE_LANDMARKS.LEFT_ANKLE];
    const rightAnkle = landmarks[POSE_LANDMARKS.RIGHT_ANKLE];

    const shoulder = isLeft ? leftShoulder : rightShoulder;
    const elbow = isLeft ? leftElbow : rightElbow;
    const wrist = isLeft ? leftWrist : rightWrist;
    const hip = isLeft ? leftHip : rightHip;
    const knee = isLeft ? leftKnee : rightKnee;
    const ankle = isLeft ? leftAnkle : rightAnkle;

    let isBottomTriggered = false;
    let isRepCountedTriggered = false;
    const now = Date.now();
    const activeFlaws: BoneFlawMap = { ...defaultFlaws };

    // Record motion trail sample
    if (elbow) {
      this.motionTrails.push({ x: elbow.x, y: elbow.y, timestamp: now, type: 'elbow' });
      if (this.motionTrails.length > 25) this.motionTrails.shift();
    }

    // =========================================================================
    // 1. SQUATS BIOMECHANICAL ENGINE (Deep Squats & Pistol Squats)
    // =========================================================================
    if (exercise === 'squat' || exercise === 'pistol_squat') {
      const kneeAngle = Math.round(calculateJointAngle(hip, knee, ankle));
      const spineAngle = Math.round(calculateJointAngle(shoulder, hip, ankle));

      // Torso vertical angle (prevent extreme forward bending)
      const torsoDy = Math.abs(hip.y - shoulder.y);
      const torsoDx = Math.abs(hip.x - shoulder.x);
      const torsoLeanAngle = Math.round((Math.atan2(torsoDx, Math.max(0.001, torsoDy)) * 180) / Math.PI);

      const depthPercent = Math.max(0, Math.min(100, Math.round(((170 - kneeAngle) / (170 - 85)) * 100)));

      let feedback = 'READY: SQUAT DOWN';
      let severity: 'info' | 'success' | 'warning' | 'error' = 'info';
      let cheat = false;
      let cheatReason: string | undefined = undefined;
      let flawType: FormAnalysisResult['flawType'] = undefined;
      let movementVector: FormAnalysisResult['movementVector'] = 'DESCEND';

      // Anti-cheat checks: chest upright (< 40° lean) and spine straight
      if (antiCheatEnabled) {
        if (torsoLeanAngle > 42) {
          cheat = true;
          cheatReason = 'KEEP CHEST PROUD & UPRIGHT';
          activeFlaws.spine = true;
        } else if (spineAngle < 140) {
          cheat = true;
          cheatReason = 'ALIGN SPINE & HIPS';
          activeFlaws.spine = true;
        }
      }

      // Lockout Top Apex (θ >= 165°)
      if (kneeAngle >= 165) {
        movementVector = 'DESCEND';
        if (this.hasHitValidDepth && (this.repPhase === 'CHEST_DEPTH_REACHED' || this.repPhase === 'ASCENDING')) {
          if (!this.repHasFormViolation && !cheat) {
            this.repCount++;
            this.repPhase = 'REP_VALIDATED';
            isRepCountedTriggered = true;
            feedback = 'REP VALIDATED';
            severity = 'success';
          } else {
            this.repPhase = 'FORM_INVALID';
            feedback = this.violationReason || 'FORM INVALID: REPEAT';
            severity = 'error';
          }
          this.hasHitValidDepth = false;
          this.depthReachedTimestamp = null;
          this.repHasFormViolation = false;
          this.violationReason = '';
        } else {
          this.repPhase = 'LOCKED_UP';
          feedback = 'LOCKOUT: STAND TALL';
          severity = 'info';
        }
      }
      // Valid Squat Bottom Depth (θ <= 85°)
      else if (kneeAngle <= this.maxChestDepthAngle) {
        movementVector = 'DRIVE';
        if (!this.depthReachedTimestamp) {
          this.depthReachedTimestamp = now;
        }
        const holdTime = now - this.depthReachedTimestamp;
        if (holdTime >= this.minDepthHoldMs && !this.hasHitValidDepth) {
          this.hasHitValidDepth = true;
          isBottomTriggered = true;
        }
        this.repPhase = 'CHEST_DEPTH_REACHED';
        feedback = 'PERFECT DEPTH (<85°): DRIVE UP';
        severity = 'success';
      }
      // Descending Phase
      else if (kneeAngle < 165 && !this.hasHitValidDepth) {
        this.repPhase = 'DESCENDING';
        movementVector = 'DESCEND';
        feedback = kneeAngle > 120 ? 'SINK HIPS LOWER' : 'APPROACHING 85° DEPTH';
        severity = 'info';
        if (kneeAngle > 110 && kneeAngle < 130) {
          flawType = 'squat_shallow';
        }
      }
      // Ascending Phase
      else if (this.hasHitValidDepth) {
        this.repPhase = 'ASCENDING';
        movementVector = 'DRIVE';
        feedback = 'DRIVE UP THROUGH MIDFOOT';
        severity = 'info';
      }

      if (cheat && activeFlaws.spine) {
        severity = 'warning';
        feedback = cheatReason || 'ALIGN POSTURE';
      }

      // Compute Form Score (0-100)
      const spineScore = Math.max(0, 100 - Math.abs(180 - spineAngle) * 1.8);
      const depthScore = Math.min(100, (depthPercent * 0.8) + 20);
      const formScore = Math.round(spineScore * 0.5 + depthScore * 0.5);
      const formGrade = formScore >= 95 ? 'S' : formScore >= 85 ? 'A' : formScore >= 75 ? 'B' : formScore >= 65 ? 'C' : 'F';

      const ghostPose = generateGhostPose(landmarks, exercise, this.repPhase, depthPercent);
      const ghostMatchScore = Math.round(Math.max(50, Math.min(100, formScore * 0.95 + 5)));

      const formBreakdown: FormBreakdown = {
        alignmentScore: Math.round(spineScore),
        elbowScore: 100,
        depthScore: Math.round(depthScore),
        handScore: 100,
        symmetryScore: 94,
        primaryIssue: cheat ? (cheatReason || 'Posture Deviation') : 'None - Strict Depth',
        whyExplanation: 'Quadriceps and gluteal engagement peak when femur breaks 90° parallel with neutral spinal loading.',
        howToFixCue: torsoLeanAngle > 42 ? 'Keep chest proud and eyes forward.' : 'Drive through whole foot to stand tall.',
      };

      return {
        primaryAngle: kneeAngle,
        secondaryAngle: spineAngle,
        repPhase: this.repPhase,
        repCount: this.repCount,
        feedbackText: feedback,
        feedbackSeverity: severity,
        depthPercentage: depthPercent,
        formScore,
        formGrade,
        isCheatDetected: cheat,
        cheatReason,
        isBottomTriggered,
        isRepCountedTriggered,
        holdDurationMs: this.depthReachedTimestamp ? now - this.depthReachedTimestamp : 0,
        spineAngle,
        isSpineAligned: !cheat,
        visibilityScore: dominantArmVis,
        isBodyInFrame,
        framingWarning,
        isElbowTucked: true,
        elbowSpineProjection: 0,
        handPlacement: defaultHandPlacement,
        movementVector,
        flawType,
        boneFlaws: activeFlaws,
        fatigueWarning: false,
        ghostMatch: {
          ghostLandmarks: ghostPose,
          matchScore: ghostMatchScore,
          isAligned: ghostMatchScore >= 85,
          statusText: ghostMatchScore >= 85 ? 'GHOST MATCH: ALIGNED' : 'ALIGN TO GHOST TRAINER',
        },
        formBreakdown,
        visionQuality,
        exerciseDefinition: currentDef,
        primaryAngleName: currentDef.angleRanges.primaryJointName,
        secondaryAngleName: currentDef.angleRanges.secondaryJointName,
        cameraAdviceText: currentDef.cameraAngleAdvice,
        placementStatusText: defaultHandPlacement.cueText,
        currentExerciseName: currentDef.name,
      };
    }

    // =========================================================================
    // 2. PLANK ISOMETRIC CORE ENGINE
    // =========================================================================
    if (exercise === 'plank') {
      const spineAngle = Math.round(calculateJointAngle(shoulder, hip, ankle));
      const isLocked = spineAngle >= 165 && spineAngle <= 185;
      const isSagging = spineAngle < 155;
      const isPiking = spineAngle > 195;

      if (isLocked) {
        if (!this.plankStartTime) this.plankStartTime = now;
        this.plankHoldSeconds = Math.floor((now - this.plankStartTime) / 1000);
      } else {
        this.plankStartTime = null;
        activeFlaws.spine = true;
        activeFlaws.hips = true;
      }

      let feedback = `HOLDING RIGID CORE (${this.plankHoldSeconds}s)`;
      let severity: 'info' | 'success' | 'warning' | 'error' = 'success';
      let flawType: FormAnalysisResult['flawType'] = undefined;

      if (!isLocked) {
        severity = 'warning';
        if (isSagging) {
          feedback = 'HIPS TOO LOW: LIFT WAIST & SQUEEZE GLUTES';
          flawType = 'plank_sagging';
        } else if (isPiking) {
          feedback = 'HIPS TOO HIGH: FLATTEN SPINE';
        }
      }

      const spineScore = Math.max(0, 100 - Math.abs(180 - spineAngle) * 3);
      const formScore = isLocked ? Math.round(spineScore) : Math.max(20, Math.round(spineScore * 0.6));
      const formGrade = formScore >= 95 ? 'S' : formScore >= 85 ? 'A' : formScore >= 75 ? 'B' : formScore >= 65 ? 'C' : 'F';

      const ghostPose = generateGhostPose(landmarks, exercise, 'LOCKED_UP', 100);
      const ghostMatchScore = Math.round(Math.max(40, Math.min(100, spineScore)));

      const formBreakdown: FormBreakdown = {
        alignmentScore: Math.round(spineScore),
        elbowScore: 100,
        depthScore: 100,
        handScore: 100,
        symmetryScore: 96,
        primaryIssue: isSagging ? 'Lumbar Sag' : isPiking ? 'Hip Pike' : 'Nominal Plank',
        whyExplanation: 'Spinal neutrality engages transverse abdominis and protects lumbar vertebrae from excessive shearing.',
        howToFixCue: isSagging ? 'Contract glutes and draw navel toward spine.' : 'Lower hips until head, hips, and heels form one line.',
      };

      return {
        primaryAngle: spineAngle,
        secondaryAngle: 180,
        repPhase: isLocked ? 'CHEST_DEPTH_REACHED' : 'LOCKED_UP',
        repCount: this.plankHoldSeconds,
        feedbackText: feedback,
        feedbackSeverity: severity,
        depthPercentage: isLocked ? 100 : Math.max(20, Math.min(90, spineAngle - 90)),
        formScore,
        formGrade,
        isCheatDetected: !isLocked,
        cheatReason: !isLocked ? feedback : undefined,
        isBottomTriggered: false,
        isRepCountedTriggered: false,
        holdDurationMs: this.plankStartTime ? now - this.plankStartTime : 0,
        spineAngle,
        isSpineAligned: isLocked,
        visibilityScore: dominantArmVis,
        isBodyInFrame,
        framingWarning,
        isElbowTucked: true,
        elbowSpineProjection: 0,
        handPlacement: defaultHandPlacement,
        movementVector: isLocked ? 'HOLD' : 'STABILIZE',
        flawType,
        boneFlaws: activeFlaws,
        fatigueWarning: false,
        ghostMatch: {
          ghostLandmarks: ghostPose,
          matchScore: ghostMatchScore,
          isAligned: isLocked,
          statusText: isLocked ? 'GHOST MATCH: PERFECT CORE' : 'ALIGN TO GHOST PLANK',
        },
        formBreakdown,
        visionQuality,
        exerciseDefinition: currentDef,
        primaryAngleName: currentDef.angleRanges.primaryJointName,
        secondaryAngleName: currentDef.angleRanges.secondaryJointName,
        cameraAdviceText: currentDef.cameraAngleAdvice,
        placementStatusText: defaultHandPlacement.cueText,
        currentExerciseName: currentDef.name,
      };
    }

    // =========================================================================
    // 3. LUNGES BIOMECHANICAL ENGINE
    // =========================================================================
    if (exercise === 'lunge') {
      const frontKneeAngle = Math.round(calculateJointAngle(hip, knee, ankle));
      const spineAngle = Math.round(calculateJointAngle(shoulder, hip, knee));
      const depthPercent = Math.max(0, Math.min(100, Math.round(((165 - frontKneeAngle) / (165 - 90)) * 100)));

      let feedback = 'STEP FORWARD & DROP BACK KNEE';
      let severity: 'info' | 'success' | 'warning' | 'error' = 'info';
      let movementVector: FormAnalysisResult['movementVector'] = 'DESCEND';

      if (frontKneeAngle >= 160) {
        movementVector = 'DESCEND';
        if (this.hasHitValidDepth) {
          this.repCount++;
          this.repPhase = 'REP_VALIDATED';
          isRepCountedTriggered = true;
          this.hasHitValidDepth = false;
          feedback = 'REP VALIDATED';
          severity = 'success';
        } else {
          this.repPhase = 'LOCKED_UP';
          feedback = 'STAND UPRIGHT';
        }
      } else if (frontKneeAngle <= 90) {
        movementVector = 'DRIVE';
        if (!this.depthReachedTimestamp) this.depthReachedTimestamp = now;
        if (now - this.depthReachedTimestamp >= this.minDepthHoldMs && !this.hasHitValidDepth) {
          this.hasHitValidDepth = true;
          isBottomTriggered = true;
        }
        this.repPhase = 'CHEST_DEPTH_REACHED';
        feedback = '90° DEPTH: PUSH BACK UP';
        severity = 'success';
      } else {
        this.repPhase = 'DESCENDING';
        movementVector = 'DESCEND';
      }

      const formScore = Math.round(85 + (depthPercent > 80 ? 15 : depthPercent * 0.1));
      const formGrade = formScore >= 95 ? 'S' : formScore >= 85 ? 'A' : formScore >= 75 ? 'B' : formScore >= 65 ? 'C' : 'F';

      return {
        primaryAngle: frontKneeAngle,
        secondaryAngle: spineAngle,
        repPhase: this.repPhase,
        repCount: this.repCount,
        feedbackText: feedback,
        feedbackSeverity: severity,
        depthPercentage: depthPercent,
        formScore,
        formGrade,
        isCheatDetected: false,
        isBottomTriggered,
        isRepCountedTriggered,
        holdDurationMs: 0,
        spineAngle,
        isSpineAligned: true,
        visibilityScore: dominantArmVis,
        isBodyInFrame,
        framingWarning,
        isElbowTucked: true,
        elbowSpineProjection: 0,
        handPlacement: defaultHandPlacement,
        movementVector,
        boneFlaws: activeFlaws,
        fatigueWarning: false,
        visionQuality,
        exerciseDefinition: currentDef,
        primaryAngleName: currentDef.angleRanges.primaryJointName,
        secondaryAngleName: currentDef.angleRanges.secondaryJointName,
        cameraAdviceText: currentDef.cameraAngleAdvice,
        placementStatusText: defaultHandPlacement.cueText,
        currentExerciseName: currentDef.name,
      };
    }

    // =========================================================================
    // 4. PIKE PUSH-UP BIOMECHANICAL ENGINE
    // =========================================================================
    if (exercise === 'pike_pushup') {
      const thetaElbow = Math.round(calculateJointAngle(shoulder, elbow, wrist));
      const thetaHip = Math.round(calculateJointAngle(shoulder, hip, ankle));

      const isPikeValid = thetaHip >= 80 && thetaHip <= 135;
      if (!isPikeValid) {
        activeFlaws.hips = true;
        activeFlaws.spine = true;
      }

      const depthPercent = Math.max(0, Math.min(100, Math.round(((160 - thetaElbow) / (160 - 85)) * 100)));
      let feedback = 'MAINTAIN INVERTED V • HEAD FORWARD';
      let severity: 'info' | 'success' | 'warning' | 'error' = 'info';
      let movementVector: FormAnalysisResult['movementVector'] = 'DESCEND';

      if (thetaElbow >= 155) {
        movementVector = 'DESCEND';
        if (this.hasHitValidDepth) {
          this.repCount++;
          this.repPhase = 'REP_VALIDATED';
          isRepCountedTriggered = true;
          this.hasHitValidDepth = false;
          feedback = 'REP VALIDATED';
          severity = 'success';
        } else {
          this.repPhase = 'LOCKED_UP';
          feedback = 'LOCKOUT: BEGIN DESCENT';
        }
      } else if (thetaElbow <= 85) {
        movementVector = 'DRIVE';
        if (!this.depthReachedTimestamp) this.depthReachedTimestamp = now;
        if (now - this.depthReachedTimestamp >= this.minDepthHoldMs && !this.hasHitValidDepth) {
          this.hasHitValidDepth = true;
          isBottomTriggered = true;
        }
        this.repPhase = 'CHEST_DEPTH_REACHED';
        feedback = 'PEAK DEPTH: PRESS BACK & UP';
        severity = 'success';
      } else {
        this.repPhase = 'DESCENDING';
        movementVector = 'DESCEND';
      }

      if (!isPikeValid) {
        feedback = 'INVERTED V REQUIRED • ELEVATE HIPS';
        severity = 'warning';
      }

      const formScore = isPikeValid ? Math.round(75 + depthPercent * 0.25) : 50;
      const formGrade = formScore >= 95 ? 'S' : formScore >= 85 ? 'A' : formScore >= 75 ? 'B' : formScore >= 65 ? 'C' : 'F';

      return {
        primaryAngle: thetaElbow,
        secondaryAngle: thetaHip,
        repPhase: this.repPhase,
        repCount: this.repCount,
        feedbackText: feedback,
        feedbackSeverity: severity,
        depthPercentage: depthPercent,
        formScore,
        formGrade,
        isCheatDetected: !isPikeValid,
        cheatReason: !isPikeValid ? 'ELEVATE HIPS TO MAINTAIN PIKE' : undefined,
        isBottomTriggered,
        isRepCountedTriggered,
        holdDurationMs: 0,
        spineAngle: thetaHip,
        isSpineAligned: isPikeValid,
        visibilityScore: dominantArmVis,
        isBodyInFrame,
        framingWarning,
        isElbowTucked: true,
        elbowSpineProjection: 0,
        handPlacement: defaultHandPlacement,
        movementVector,
        flawType: !isPikeValid ? 'pike_angle' : undefined,
        boneFlaws: activeFlaws,
        fatigueWarning: false,
        visionQuality,
        exerciseDefinition: currentDef,
        primaryAngleName: currentDef.angleRanges.primaryJointName,
        secondaryAngleName: currentDef.angleRanges.secondaryJointName,
        cameraAdviceText: currentDef.cameraAngleAdvice,
        placementStatusText: defaultHandPlacement.cueText,
        currentExerciseName: currentDef.name,
      };
    }

    // =========================================================================
    // 5. PUSH-UP VARIATIONS (Standard 45°, Diamond Push-up, Wide Push-up)
    // =========================================================================

    // 1. Joint Angles
    const thetaElbow = Math.round(calculateJointAngle(shoulder, elbow, wrist));
    const thetaSpine = Math.round(calculateJointAngle(shoulder, hip, ankle));

    // 2. Hand Width Diagnostic: W_ratio = Distance(Wrists) / Distance(Shoulders)
    const wristDist = calculateDistance(leftWrist, rightWrist);
    const shoulderDist = calculateDistance(leftShoulder, rightShoulder);
    const handWidthRatio = shoulderDist > 0.01 ? parseFloat((wristDist / shoulderDist).toFixed(2)) : 1.1;

    let idealMin = 0.75;
    let idealMax = 1.35;
    if (exercise === 'diamond_pushup') {
      idealMin = 0.15;
      idealMax = 0.55;
    } else if (exercise === 'wide_pushup') {
      idealMin = 1.35;
      idealMax = 1.95;
    }

    let handStatus: HandPlacementGuide['status'] = 'valid';
    let handCue = 'HAND PLACEMENT NOMINAL';

    if (handWidthRatio < idealMin) {
      handStatus = 'too_narrow';
      handCue = exercise === 'wide_pushup' ? 'WIDEN HAND STANCE' : 'SPACE HANDS SLIGHTLY';
      activeFlaws.wrists = true;
    } else if (handWidthRatio > idealMax) {
      handStatus = 'too_wide';
      handCue = exercise === 'diamond_pushup' ? '← MOVE HANDS IN (DIAMOND ◇) →' : 'HANDS TOO WIDE';
      activeFlaws.wrists = true;
    }

    const handPlacement: HandPlacementGuide = {
      ratio: handWidthRatio,
      idealMin,
      idealMax,
      status: handStatus,
      cueText: handCue,
      diamondCenter: {
        x: (leftWrist.x + rightWrist.x) / 2,
        y: (leftWrist.y + rightWrist.y) / 2,
      },
    };

    // 3. Arrowhead Vector Projection:
    // Torso spine vector: Shoulder (S) to Hip (H)
    const spineVecX = hip.x - shoulder.x;
    const spineVecY = hip.y - shoulder.y;
    const spineMag = Math.sqrt(spineVecX * spineVecX + spineVecY * spineVecY) || 0.001;
    const uSpineX = spineVecX / spineMag;
    const uSpineY = spineVecY / spineMag;

    // Vector from Shoulder (S) to Elbow (E)
    const elbowVecX = elbow.x - shoulder.x;
    const elbowVecY = elbow.y - shoulder.y;

    // Scalar projection of Elbow along torso line
    const elbowSpineProj = elbowVecX * uSpineX + elbowVecY * uSpineY;
    const isFlaringForward = elbowSpineProj < -0.035;
    const isElbowTucked = !isFlaringForward;

    if (!isElbowTucked) {
      if (isLeft) activeFlaws.leftUpperArm = true;
      else activeFlaws.rightUpperArm = true;
    }

    // 4. Spine & Waist Alignment Diagnostic (Anti-Sag / Anti-Pike)
    const isSpineValid = thetaSpine >= this.minSpineAngleConstraint && thetaSpine <= 195;
    if (!isSpineValid) {
      activeFlaws.spine = true;
      activeFlaws.hips = true;
    }

    // 5. Anti-Cheat Evaluation
    let isCheatDetected = false;
    let cheatReason: string | undefined = undefined;
    let flawType: FormAnalysisResult['flawType'] = undefined;
    let movementVector: FormAnalysisResult['movementVector'] = 'DESCEND';

    if (antiCheatEnabled) {
      if (!isElbowTucked && thetaElbow < 140) {
        isCheatDetected = true;
        cheatReason = 'ELBOWS FLARED: TUCK TO 45° ARROWHEAD';
        flawType = 'flared_elbows';
        this.repHasFormViolation = true;
        this.violationReason = cheatReason;
      } else if (!isSpineValid) {
        isCheatDetected = true;
        cheatReason = thetaSpine < 155 ? 'HIPS TOO LOW: SQUEEZE CORE' : 'HIPS TOO HIGH: FLATTEN SPINE';
        flawType = 'waist_sagging';
        this.repHasFormViolation = true;
        this.violationReason = cheatReason;
      } else if (handStatus !== 'valid' && thetaElbow > 140) {
        isCheatDetected = true;
        cheatReason = handCue;
        flawType = 'hand_width';
      }
    }

    if (isCheatDetected) {
      this.consecutiveFlawFrames++;
    } else {
      this.consecutiveFlawFrames = Math.max(0, this.consecutiveFlawFrames - 1);
    }
    const fatigueWarning = this.consecutiveFlawFrames > 45; // ~1.5s of continuous form breakdown

    // Depth percentage calculation (Lockout = 0%, 85° = 100%)
    const depthPercent = Math.max(
      0,
      Math.min(
        100,
        Math.round(((this.minLockoutAngle - thetaElbow) / (this.minLockoutAngle - this.maxChestDepthAngle)) * 100)
      )
    );

    let feedbackText = 'LOCKOUT (>160°): READY';
    let feedbackSeverity: 'info' | 'success' | 'warning' | 'error' = 'info';

    // ----------------------------------------------------
    // PHASE 0 & 4: LOCKOUT (θ_elbow >= 160°)
    // ----------------------------------------------------
    if (thetaElbow >= this.minLockoutAngle) {
      movementVector = 'DESCEND';
      if (this.hasHitValidDepth && (this.repPhase === 'CHEST_DEPTH_REACHED' || this.repPhase === 'ASCENDING')) {
        if (!this.repHasFormViolation && !isCheatDetected) {
          this.repCount++;
          this.repPhase = 'REP_VALIDATED';
          isRepCountedTriggered = true;
          feedbackText = 'REP VALIDATED';
          feedbackSeverity = 'success';
        } else {
          this.repPhase = 'FORM_INVALID';
          feedbackText = this.violationReason || 'FORM INVALID: REPEAT';
          feedbackSeverity = 'error';
        }

        this.hasHitValidDepth = false;
        this.depthReachedTimestamp = null;
        this.repHasFormViolation = false;
        this.violationReason = '';
      } else {
        this.repPhase = 'LOCKED_UP';
        feedbackText = 'LOCKOUT (>160°): BEGIN DESCENT';
        feedbackSeverity = 'info';
      }
    }
    // ----------------------------------------------------
    // PHASE 2: CHEST_DEPTH_REACHED (θ_elbow <= 85°)
    // ----------------------------------------------------
    else if (thetaElbow <= this.maxChestDepthAngle) {
      movementVector = 'DRIVE';
      if (!this.depthReachedTimestamp) {
        this.depthReachedTimestamp = now;
      }

      const holdDuration = now - this.depthReachedTimestamp;
      if (holdDuration >= this.minDepthHoldMs && !this.hasHitValidDepth) {
        this.hasHitValidDepth = true;
        isBottomTriggered = true;
      }

      this.repPhase = 'CHEST_DEPTH_REACHED';

      if (isFlaringForward) {
        this.repHasFormViolation = true;
        this.violationReason = 'TUCK ELBOWS (45°)';
        feedbackText = 'ELBOWS FLARED: TUCK INWARD';
        feedbackSeverity = 'error';
      } else if (isCheatDetected) {
        feedbackText = cheatReason || 'ALIGN POSTURE';
        feedbackSeverity = 'warning';
      } else {
        feedbackText = 'CHEST DEPTH (<85°): DRIVE UP';
        feedbackSeverity = 'success';
      }
    }
    // ----------------------------------------------------
    // PHASE 1: DESCENDING (85° < θ_elbow < 160°)
    // ----------------------------------------------------
    else if (thetaElbow < this.minLockoutAngle && !this.hasHitValidDepth) {
      this.repPhase = 'DESCENDING';
      movementVector = 'DESCEND';
      if (isFlaringForward) {
        this.repHasFormViolation = true;
        this.violationReason = 'TUCK ELBOWS';
        feedbackText = 'TUCK ELBOWS INWARD (45°)';
        feedbackSeverity = 'warning';
      } else {
        feedbackText = thetaElbow > 115 ? 'DESCEND SMOOTHLY' : 'APPROACHING 85° DEPTH';
        feedbackSeverity = 'info';
      }
    }
    // ----------------------------------------------------
    // PHASE 3: ASCENDING (85° < θ_elbow < 160°)
    // ----------------------------------------------------
    else if (this.hasHitValidDepth) {
      this.repPhase = 'ASCENDING';
      movementVector = 'DRIVE';
      if (isFlaringForward) {
        this.repHasFormViolation = true;
        this.violationReason = 'TUCK ELBOWS';
        feedbackText = 'KEEP ELBOWS TUCKED';
        feedbackSeverity = 'error';
      } else {
        feedbackText = 'PUSH TO LOCKOUT (>160°)';
        feedbackSeverity = 'info';
      }
    }

    if (isCheatDetected && this.repPhase !== 'REP_VALIDATED') {
      feedbackText = cheatReason || 'ALIGN POSTURE';
      feedbackSeverity = 'warning';
    }

    // Deterministic Form Score Calculation (0-100%)
    const spineScore = Math.max(0, 100 - Math.abs(180 - thetaSpine) * 2.2);
    const elbowTuckScore = isElbowTucked ? 100 : 45;
    const handPlacementScore = handStatus === 'valid' ? 100 : 60;
    const symmetryScoreRaw = 95; // Simplified for now
    
    let formScore = Math.round(
      spineScore * currentDef.scoringWeights.alignmentWeight + 
      depthPercent * currentDef.scoringWeights.depthWeight + 
      handPlacementScore * currentDef.scoringWeights.handPlacementWeight + 
      symmetryScoreRaw * currentDef.scoringWeights.symmetryWeight
    );

    // Some exercises have strong elbow mechanics (e.g. pushups) which might not fit perfectly into the 4 weights
    if (exercise.includes('pushup')) {
       // Blending elbow tuck score into hand placement or alignment since it's an upper body issue
       formScore = Math.round((formScore * 0.8) + (elbowTuckScore * 0.2));
    }

    formScore = Math.min(100, Math.max(0, formScore));
    const formGrade = formScore >= 95 ? 'S' : formScore >= 85 ? 'A' : formScore >= 75 ? 'B' : formScore >= 65 ? 'C' : 'F';

    // Ghost Trainer Synthesis
    const ghostPose = generateGhostPose(landmarks, exercise, this.repPhase, depthPercent);
    const ghostMatchScore = Math.round(Math.max(45, Math.min(100, formScore * 0.9 + (isElbowTucked ? 10 : 0))));

    // Explainable Form Score Breakdown
    const formBreakdown: FormBreakdown = {
      alignmentScore: Math.round(spineScore),
      elbowScore: isElbowTucked ? 98 : 45,
      depthScore: Math.round(depthPercent),
      handScore: handStatus === 'valid' ? 100 : 65,
      symmetryScore: 95,
      primaryIssue: !isElbowTucked
        ? 'Elbow Flare'
        : !isSpineValid
        ? thetaSpine < 155
          ? 'Hips Sagging'
          : 'Hips Piking'
        : handStatus !== 'valid'
        ? 'Hand Width'
        : 'None - Clean Form',
      whyExplanation: !isElbowTucked
        ? 'Flaring elbows past 70° places excessive impingement torque on the rotator cuff and anterior shoulder capsule.'
        : !isSpineValid
        ? 'A sagging or piked spine disengages the anterior core chain and diverts force from the pectoral chest muscles.'
        : 'Optimal mechanical leverage distributes tension evenly across the sternal pectoralis, anterior deltoids, and triceps.',
      howToFixCue: !isElbowTucked
        ? 'Rotate wrists slightly outward and tuck elbows to create an Arrowhead (45°) trajectory.'
        : !isSpineValid
        ? 'Engage core and squeeze glutes to keep the body rigid as a steel rod.'
        : 'Maintain controlled 2-second descent and explode to full lockout.',
    };

    return {
      primaryAngle: thetaElbow,
      secondaryAngle: thetaSpine,
      repPhase: this.repPhase,
      repCount: this.repCount,
      feedbackText,
      feedbackSeverity,
      depthPercentage: depthPercent,
      formScore,
      formGrade,
      isCheatDetected,
      cheatReason,
      isBottomTriggered,
      isRepCountedTriggered,
      holdDurationMs: this.depthReachedTimestamp ? now - this.depthReachedTimestamp : 0,
      spineAngle: thetaSpine,
      isSpineAligned: isSpineValid,
      visibilityScore: dominantArmVis,
      isBodyInFrame,
      framingWarning,
      isElbowTucked,
      elbowSpineProjection: elbowSpineProj,
      handPlacement,
      movementVector,
      flawType,
      boneFlaws: activeFlaws,
      fatigueWarning,
      ghostMatch: {
        ghostLandmarks: ghostPose,
        matchScore: ghostMatchScore,
        isAligned: ghostMatchScore >= 85,
        statusText: ghostMatchScore >= 85 ? 'GHOST MATCH: NOMINAL' : 'MATCH GHOST TRAINER POSE',
      },
      formBreakdown,
      visionQuality,
      exerciseDefinition: currentDef,
      primaryAngleName: currentDef.angleRanges.primaryJointName,
      secondaryAngleName: currentDef.angleRanges.secondaryJointName,
      cameraAdviceText: currentDef.cameraAngleAdvice,
      placementStatusText: handPlacement.cueText,
      currentExerciseName: currentDef.name,
      orientation: this.determineOrientation(landmarks),
    };
  }

  private calculatePrimaryAngle(landmarks: Landmark[], def: ExerciseDefinition, isLeft: boolean): number {
    const sNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_SHOULDER] : landmarks[POSE_LANDMARKS.RIGHT_SHOULDER];
    const eNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_ELBOW] : landmarks[POSE_LANDMARKS.RIGHT_ELBOW];
    const wNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_WRIST] : landmarks[POSE_LANDMARKS.RIGHT_WRIST];
    const hNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_HIP] : landmarks[POSE_LANDMARKS.RIGHT_HIP];
    const kNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_KNEE] : landmarks[POSE_LANDMARKS.RIGHT_KNEE];
    const aNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_ANKLE] : landmarks[POSE_LANDMARKS.RIGHT_ANKLE];

    if (def.angleRanges.primaryJointName === 'Elbow') {
      if (sNode && eNode && wNode) {
        return Math.round(calculateJointAngle(sNode, eNode, wNode));
      }
    } else if (def.angleRanges.primaryJointName === 'Knee') {
      if (hNode && kNode && aNode) {
        return Math.round(calculateJointAngle(hNode, kNode, aNode));
      }
    } else if (def.angleRanges.primaryJointName === 'Hip') {
      if (sNode && hNode && kNode) {
        return Math.round(calculateJointAngle(sNode, hNode, kNode));
      }
    }
    return 180;
  }

  private determineOrientation(landmarks: Landmark[]): 'STANDING' | 'HORIZONTAL' | 'INVERTED' | 'SEATED' | 'UNKNOWN' {
    const nose = landmarks[POSE_LANDMARKS.NOSE];
    const leftShoulder = landmarks[POSE_LANDMARKS.LEFT_SHOULDER];
    const rightShoulder = landmarks[POSE_LANDMARKS.RIGHT_SHOULDER];
    const leftHip = landmarks[POSE_LANDMARKS.LEFT_HIP];
    const rightHip = landmarks[POSE_LANDMARKS.RIGHT_HIP];
    const leftAnkle = landmarks[POSE_LANDMARKS.LEFT_ANKLE];
    const rightAnkle = landmarks[POSE_LANDMARKS.RIGHT_ANKLE];

    if (!nose || !leftShoulder || !leftHip || !leftAnkle) return 'UNKNOWN';

    const midShoulderY = (leftShoulder.y + rightShoulder.y) / 2;
    const midHipY = (leftHip.y + rightHip.y) / 2;
    const midAnkleY = (leftAnkle.y + rightAnkle.y) / 2;
    
    const midShoulderX = (leftShoulder.x + rightShoulder.x) / 2;
    const midAnkleX = (leftAnkle.x + rightAnkle.x) / 2;

    const verticalSpan = Math.abs(midShoulderY - midAnkleY);
    const horizontalSpan = Math.abs(midShoulderX - midAnkleX);

    if (verticalSpan > horizontalSpan * 1.5 && midShoulderY < midAnkleY) {
      return 'STANDING';
    }
    if (horizontalSpan > verticalSpan * 1.2) {
      return 'HORIZONTAL';
    }
    if (verticalSpan > horizontalSpan * 1.5 && midShoulderY > midAnkleY) {
      return 'INVERTED';
    }
    
    return 'UNKNOWN';
  }
}

/**
 * 3D Holographic Skeletal Overlay with Energy Pulses & Dynamic Red/Cyan Form Feedback
 * Cinematic Minimalist High-Contrast Black & White with Electric Cyan (#00f0ff) & Crimson (#ff003c) Feedback.
 * Supports Ghost Trainer Layer, Motion Trails, Angle Arcs, and Target Zones.
 */
export function drawCyberpunkSkeleton(
  ctx: CanvasRenderingContext2D,
  landmarks: Landmark[],
  width: number,
  height: number,
  analysis: FormAnalysisResult,
  exercise: ExerciseType = 'pushup',
  options: {
    showSkeleton?: boolean;
    showGhostTrainer?: boolean;
    showMotionTrails?: boolean;
    showJointArcs?: boolean;
    showMovementVectors?: boolean;
    showTargetZones?: boolean;
  } = {}
) {
  if (!landmarks || landmarks.length < 33) return;

  const {
    showSkeleton = true,
    showGhostTrainer = true,
    showMotionTrails = true,
    showJointArcs = true,
    showMovementVectors = true,
    showTargetZones = true,
  } = options;

  ctx.save();
  ctx.clearRect(0, 0, width, height);

  const now = performance.now();
  const pulsePhase = (now % 1000) / 1000;

  const BONE_CONNECTIONS: {
    from: number;
    to: number;
    flawKey: keyof BoneFlawMap | null;
  }[] = [
    // Torso Frame & Spine
    { from: POSE_LANDMARKS.LEFT_SHOULDER, to: POSE_LANDMARKS.RIGHT_SHOULDER, flawKey: 'spine' },
    { from: POSE_LANDMARKS.LEFT_SHOULDER, to: POSE_LANDMARKS.LEFT_HIP, flawKey: 'spine' },
    { from: POSE_LANDMARKS.RIGHT_SHOULDER, to: POSE_LANDMARKS.RIGHT_HIP, flawKey: 'spine' },
    { from: POSE_LANDMARKS.LEFT_HIP, to: POSE_LANDMARKS.RIGHT_HIP, flawKey: 'spine' },
    // Upper Arms
    { from: POSE_LANDMARKS.LEFT_SHOULDER, to: POSE_LANDMARKS.LEFT_ELBOW, flawKey: 'leftUpperArm' },
    { from: POSE_LANDMARKS.RIGHT_SHOULDER, to: POSE_LANDMARKS.RIGHT_ELBOW, flawKey: 'rightUpperArm' },
    // Forearms
    { from: POSE_LANDMARKS.LEFT_ELBOW, to: POSE_LANDMARKS.LEFT_WRIST, flawKey: 'leftForearm' },
    { from: POSE_LANDMARKS.RIGHT_ELBOW, to: POSE_LANDMARKS.RIGHT_WRIST, flawKey: 'rightForearm' },
    // Wrists Placement Connector
    { from: POSE_LANDMARKS.LEFT_WRIST, to: POSE_LANDMARKS.RIGHT_WRIST, flawKey: 'wrists' },
    // Thighs
    { from: POSE_LANDMARKS.LEFT_HIP, to: POSE_LANDMARKS.LEFT_KNEE, flawKey: 'leftThigh' },
    { from: POSE_LANDMARKS.RIGHT_HIP, to: POSE_LANDMARKS.RIGHT_KNEE, flawKey: 'rightThigh' },
    // Shins
    { from: POSE_LANDMARKS.LEFT_KNEE, to: POSE_LANDMARKS.LEFT_ANKLE, flawKey: 'leftShin' },
    { from: POSE_LANDMARKS.RIGHT_KNEE, to: POSE_LANDMARKS.RIGHT_ANKLE, flawKey: 'rightShin' },
  ];

  // 1. Ghost Trainer Layer (Subtle Monochrome Holographic Wireframe)
  if (showGhostTrainer && analysis.ghostMatch?.ghostLandmarks && analysis.ghostMatch.ghostLandmarks.length >= 33) {
    const ghost = analysis.ghostMatch.ghostLandmarks;
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);

    BONE_CONNECTIONS.forEach(({ from, to }) => {
      const p1 = ghost[from];
      const p2 = ghost[to];
      if (!p1 || !p2) return;
      ctx.beginPath();
      ctx.moveTo(p1.x * width, p1.y * height);
      ctx.lineTo(p2.x * width, p2.y * height);
      ctx.stroke();
    });

    // Ghost Joint Nodes
    [POSE_LANDMARKS.LEFT_ELBOW, POSE_LANDMARKS.RIGHT_ELBOW, POSE_LANDMARKS.LEFT_HIP, POSE_LANDMARKS.RIGHT_HIP, POSE_LANDMARKS.LEFT_KNEE, POSE_LANDMARKS.RIGHT_KNEE].forEach((idx) => {
      const pt = ghost[idx];
      if (!pt) return;
      ctx.beginPath();
      ctx.arc(pt.x * width, pt.y * height, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.fill();
    });

    ctx.restore();
  }

  // 2. Motion Trails (Cinematic Monochrome Velocity Trail)
  if (showMotionTrails) {
    const leftElbow = landmarks[POSE_LANDMARKS.LEFT_ELBOW];
    const rightElbow = landmarks[POSE_LANDMARKS.RIGHT_ELBOW];
    const targetNode = leftElbow || rightElbow;
    if (targetNode && (targetNode.visibility ?? 1) > 0.4) {
      ctx.save();
      const ex = targetNode.x * width;
      const ey = targetNode.y * height;
      const grad = ctx.createRadialGradient(ex, ey, 2, ex, ey, 32);
      grad.addColorStop(0, analysis.isElbowTucked ? 'rgba(255, 255, 255, 0.35)' : 'rgba(255, 51, 68, 0.45)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(ex, ey, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // 3. Ground Perspective Plane / Alignment Reference Lines
  const leftAnkle = landmarks[POSE_LANDMARKS.LEFT_ANKLE];
  const rightAnkle = landmarks[POSE_LANDMARKS.RIGHT_ANKLE];
  if (leftAnkle && rightAnkle && (leftAnkle.visibility ?? 1) > 0.3) {
    const groundY = Math.max(leftAnkle.y, rightAnkle.y) * height;
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(0, groundY);
    ctx.lineTo(width, groundY);
    ctx.stroke();
    ctx.restore();
  }

  // 4. Draw Spine Alignment Axis (Shoulder -> Hip -> Ankle)
  if (exercise.includes('pushup') || exercise === 'plank') {
    const shoulder = landmarks[POSE_LANDMARKS.LEFT_SHOULDER];
    const hip = landmarks[POSE_LANDMARKS.LEFT_HIP];
    const ankle = landmarks[POSE_LANDMARKS.LEFT_ANKLE];

    if (shoulder && hip && ankle && (shoulder.visibility ?? 1) > 0.4 && (ankle.visibility ?? 1) > 0.3) {
      ctx.save();
      const isAligned = analysis.isSpineAligned;
      ctx.strokeStyle = isAligned ? 'rgba(255, 255, 255, 0.45)' : 'rgba(255, 51, 68, 0.7)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(shoulder.x * width, shoulder.y * height);
      ctx.lineTo(ankle.x * width, ankle.y * height);
      ctx.stroke();
      ctx.restore();
    }
  }

  // 5. Target Zones: Specialized Diamond Target Zone (◇) for Diamond Push-Up
  if (showTargetZones && exercise === 'diamond_pushup') {
    const lW = landmarks[POSE_LANDMARKS.LEFT_WRIST];
    const rW = landmarks[POSE_LANDMARKS.RIGHT_WRIST];
    if (lW && rW && (lW.visibility ?? 1) > 0.35 && (rW.visibility ?? 1) > 0.35) {
      const midX = ((lW.x + rW.x) / 2) * width;
      const midY = ((lW.y + rW.y) / 2) * height;
      const diamondRadius = 26;

      ctx.save();
      const isValid = analysis.handPlacement.status === 'valid';
      ctx.strokeStyle = isValid ? '#ffffff' : '#ff3344';
      ctx.fillStyle = isValid ? 'rgba(255, 255, 255, 0.12)' : 'rgba(255, 51, 68, 0.15)';
      ctx.shadowColor = isValid ? '#ffffff' : '#ff3344';
      ctx.shadowBlur = 10;
      ctx.lineWidth = 2;

      ctx.beginPath();
      ctx.moveTo(midX, midY - diamondRadius);
      ctx.lineTo(midX + diamondRadius, midY);
      ctx.lineTo(midX, midY + diamondRadius);
      ctx.lineTo(midX - diamondRadius, midY);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Diamond Label
      ctx.font = 'bold 9px "Orbitron", monospace';
      ctx.fillStyle = isValid ? '#ffffff' : '#ff3344';
      ctx.textAlign = 'center';
      ctx.fillText(isValid ? 'DIAMOND ◇' : 'TOUCH HANDS ◇', midX, midY + diamondRadius + 14);
      ctx.restore();
    }
  }

  // 6. Draw Bones & Limbs with Exact Flaw Highlight
  if (showSkeleton) {
    const isDepthValid = analysis.repPhase === 'CHEST_DEPTH_REACHED';
    const isRepCounted = analysis.repPhase === 'REP_VALIDATED';

    BONE_CONNECTIONS.forEach(({ from, to, flawKey }) => {
      const ptA = landmarks[from];
      const ptB = landmarks[to];
      if (!ptA || !ptB) return;
      if ((ptA.visibility ?? 1) < 0.25 || (ptB.visibility ?? 1) < 0.25) return;

      const ax = ptA.x * width;
      const ay = ptA.y * height;
      const bx = ptB.x * width;
      const by = ptB.y * height;

      const isSegmentFlawed = flawKey ? analysis.boneFlaws[flawKey] : false;

      // Pure Cinematic Monochrome: Bright White base for valid; Pure Red only for flawed segments
      const segmentStroke = isSegmentFlawed
        ? '#ff3344'
        : isRepCounted
        ? '#ffffff'
        : isDepthValid
        ? '#ffffff'
        : '#d4d4d8';

      const segmentGlow = isSegmentFlawed
        ? 'rgba(255, 51, 68, 0.95)'
        : isDepthValid
        ? 'rgba(255, 255, 255, 0.85)'
        : 'rgba(255, 255, 255, 0.25)';

      ctx.save();
      ctx.shadowColor = segmentGlow;
      ctx.shadowBlur = isSegmentFlawed || isDepthValid ? 12 : 3;
      ctx.lineWidth = isSegmentFlawed ? 3.5 : isDepthValid ? 3 : 2;
      ctx.strokeStyle = segmentStroke;
      ctx.lineCap = 'round';

      // Base Bone Line
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(bx, by);
      ctx.stroke();

      // Directional Precision Pulse along Limb Vector
      if (!isSegmentFlawed) {
        const pulseX = ax + (bx - ax) * pulsePhase;
        const pulseY = ay + (by - ay) * pulsePhase;

        ctx.beginPath();
        ctx.arc(pulseX, pulseY, 2, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#ffffff';
        ctx.shadowBlur = 8;
        ctx.fill();
      }

      ctx.restore();
    });

    // 7. Render Joints with Depth-Scaled Radii
    const KEY_JOINTS = [
      POSE_LANDMARKS.LEFT_SHOULDER,
      POSE_LANDMARKS.RIGHT_SHOULDER,
      POSE_LANDMARKS.LEFT_ELBOW,
      POSE_LANDMARKS.RIGHT_ELBOW,
      POSE_LANDMARKS.LEFT_WRIST,
      POSE_LANDMARKS.RIGHT_WRIST,
      POSE_LANDMARKS.LEFT_HIP,
      POSE_LANDMARKS.RIGHT_HIP,
      POSE_LANDMARKS.LEFT_KNEE,
      POSE_LANDMARKS.RIGHT_KNEE,
      POSE_LANDMARKS.LEFT_ANKLE,
      POSE_LANDMARKS.RIGHT_ANKLE,
    ];

    KEY_JOINTS.forEach((idx) => {
      const pt = landmarks[idx];
      if (!pt || (pt.visibility ?? 1) < 0.25) return;

      const jx = pt.x * width;
      const jy = pt.y * height;
      const z = pt.z || 0;

      const radius = Math.max(3, Math.min(7, 4 * (1.0 - z * 1.5)));

      ctx.save();
      ctx.shadowColor = isDepthValid ? '#ffffff' : 'rgba(255,255,255,0.6)';
      ctx.shadowBlur = 10;

      // Outer Rim
      ctx.beginPath();
      ctx.arc(jx, jy, radius + 1.5, 0, Math.PI * 2);
      ctx.fillStyle = isDepthValid ? 'rgba(255, 255, 255, 0.35)' : 'rgba(255, 255, 255, 0.15)';
      ctx.fill();

      // Solid Inner Core
      ctx.beginPath();
      ctx.arc(jx, jy, radius, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.lineWidth = 1;
      ctx.strokeStyle = isDepthValid ? '#ffffff' : '#71717a';
      ctx.stroke();
      ctx.restore();
    });
  }

  // 8. Joint Angle Arcs & Real-Time Degree Badges
  if (showJointArcs) {
    const leftVis =
      ((landmarks[POSE_LANDMARKS.LEFT_SHOULDER]?.visibility || 0) +
        (landmarks[POSE_LANDMARKS.LEFT_ELBOW]?.visibility || 0)) / 2;
    const rightVis =
      ((landmarks[POSE_LANDMARKS.RIGHT_SHOULDER]?.visibility || 0) +
        (landmarks[POSE_LANDMARKS.RIGHT_ELBOW]?.visibility || 0)) / 2;
    const isLeft = leftVis >= rightVis;

    if (exercise.includes('pushup') || exercise === 'pike_pushup') {
      const eNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_ELBOW] : landmarks[POSE_LANDMARKS.RIGHT_ELBOW];

      if (eNode && (eNode.visibility ?? 1) > 0.4) {
        const ex = eNode.x * width;
        const ey = eNode.y * height;

        ctx.save();
        ctx.beginPath();
        ctx.arc(ex, ey, 22, 0, (analysis.primaryAngle * Math.PI) / 180, false);
        ctx.strokeStyle = analysis.isElbowTucked ? '#ffffff' : '#ff3344';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Degree Badge Box
        const badgeW = 44;
        const badgeH = 18;
        const badgeX = ex + 10;
        const badgeY = ey - 22;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        ctx.strokeStyle = analysis.isElbowTucked ? '#ffffff' : '#ff3344';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 3);
        ctx.fill();
        ctx.stroke();

        ctx.font = 'bold 11px "Orbitron", monospace';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(`${analysis.primaryAngle}°`, badgeX + badgeW / 2, badgeY + 13);
        ctx.restore();
      }
    } else if (exercise.includes('squat')) {
      const kNode = isLeft ? landmarks[POSE_LANDMARKS.LEFT_KNEE] : landmarks[POSE_LANDMARKS.RIGHT_KNEE];
      if (kNode && (kNode.visibility ?? 1) > 0.4) {
        const kx = kNode.x * width;
        const ky = kNode.y * height;

        ctx.save();
        ctx.beginPath();
        ctx.arc(kx, ky, 24, 0, (analysis.primaryAngle * Math.PI) / 180, false);
        ctx.strokeStyle = analysis.primaryAngle <= 85 ? '#ffffff' : '#a1a1aa';
        ctx.lineWidth = 2;
        ctx.stroke();

        const badgeW = 44;
        const badgeH = 18;
        const badgeX = kx + 10;
        const badgeY = ky - 22;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
        ctx.strokeStyle = analysis.primaryAngle <= 85 ? '#ffffff' : '#52525b';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 3);
        ctx.fill();
        ctx.stroke();

        ctx.font = 'bold 11px "Orbitron", monospace';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(`${analysis.primaryAngle}°`, badgeX + badgeW / 2, badgeY + 13);
        ctx.restore();
      }
    }
  }

  // 9. Movement Vector Indicator (↓ LOWER, ↑ DRIVE, etc.)
  if (showMovementVectors) {
    const sNode = landmarks[POSE_LANDMARKS.LEFT_SHOULDER] || landmarks[POSE_LANDMARKS.RIGHT_SHOULDER];
    if (sNode && (sNode.visibility ?? 1) > 0.4) {
      const sx = sNode.x * width;
      const sy = sNode.y * height - 35;

      ctx.save();
      ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
      ctx.strokeStyle = analysis.movementVector === 'DRIVE' ? '#ffffff' : 'rgba(255, 255, 255, 0.25)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(sx - 35, sy, 70, 18, 3);
      ctx.fill();
      ctx.stroke();

      ctx.font = 'bold 9px "Orbitron", monospace';
      ctx.fillStyle = analysis.movementVector === 'DRIVE' ? '#ffffff' : '#d4d4d8';
      ctx.textAlign = 'center';
      ctx.fillText(
        analysis.movementVector === 'DRIVE'
          ? '↑ DRIVE'
          : analysis.movementVector === 'DESCEND'
          ? '↓ LOWER'
          : 'HOLD',
        sx,
        sy + 13
      );
      ctx.restore();
    }
  }

  ctx.restore();
}
