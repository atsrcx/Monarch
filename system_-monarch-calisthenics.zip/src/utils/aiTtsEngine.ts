/**
 * SYSTEM: MONARCH AI TEXT-TO-SPEECH (TTS) & INTELLIGENT VOICE COACH ENGINE
 * Real-time spoken biomechanical feedback, 3.5s anti-spam debounce,
 * 0.5s error persistence validation, and multi-lingual voice cues.
 */

export type TtsPersona = 'monarch' | 'architect' | 'commander' | 'anime';

export interface TtsSettings {
  enabled: boolean;
  persona: TtsPersona;
  rate: number;
  pitch: number;
  volume: number;
  autoRepMilestones: boolean;
  autoFormCues: boolean;
  language: 'en' | 'hi' | 'bilingual';
}

export type BiomechanicalFlawType =
  | 'waist_sagging'
  | 'shallow_depth'
  | 'flared_elbows'
  | 'hand_width'
  | 'squat_shallow'
  | 'plank_sagging'
  | 'pike_angle'
  | 'good_depth'
  | 'lockout_top'
  | 'cadence_speed_up'
  | 'cadence_slow_down';

class AiTtsEngine {
  private synth: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private isMuted: boolean = false;
  private settings: TtsSettings = {
    enabled: true,
    persona: 'monarch',
    rate: 1.05,
    pitch: 0.9,
    volume: 1.0,
    autoRepMilestones: true,
    autoFormCues: true,
    language: 'en'
  };

  // Anti-spam debounce timers
  private lastSpokenTime: number = 0;
  private lastFeedbackType: string = '';
  private errorStartTimestamps: Map<BiomechanicalFlawType, number> = new Map();
  private readonly ANTI_SPAM_DEBOUNCE_MS = 3500; // 3.5-second anti-spam debounce
  private readonly ERROR_PERSISTENCE_THRESHOLD_MS = 500; // Must persist > 0.5s before spoken

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    this.voices = this.synth.getVoices();
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted && this.synth) {
      this.synth.cancel();
    }
  }

  public updateSettings(newSettings: Partial<TtsSettings>) {
    this.settings = { ...this.settings, ...newSettings };
  }

  public getSettings(): TtsSettings {
    return { ...this.settings };
  }

  private selectVoiceForPersona(): SpeechSynthesisVoice | null {
    if (!this.voices || this.voices.length === 0) {
      this.loadVoices();
    }
    if (this.voices.length === 0) return null;

    // Prefer English/Hindi voices depending on language setting
    const langPrefix = this.settings.language === 'hi' ? 'hi' : 'en';
    const targetVoices = this.voices.filter((v) => v.lang.startsWith(langPrefix));
    const pool = targetVoices.length > 0 ? targetVoices : this.voices;

    // Persona-specific preference matching
    if (this.settings.persona === 'monarch') {
      return (
        pool.find((v) => v.name.toLowerCase().includes('google') && v.name.toLowerCase().includes('uk')) ||
        pool.find((v) => v.name.toLowerCase().includes('daniel') || v.name.toLowerCase().includes('george')) ||
        pool.find((v) => v.name.toLowerCase().includes('male')) ||
        pool[0]
      );
    } else if (this.settings.persona === 'architect') {
      return (
        pool.find((v) => v.name.toLowerCase().includes('natural') || v.name.toLowerCase().includes('online')) ||
        pool.find((v) => v.name.toLowerCase().includes('google us')) ||
        pool[0]
      );
    } else if (this.settings.persona === 'commander') {
      return (
        pool.find((v) => v.name.toLowerCase().includes('alex') || v.name.toLowerCase().includes('fred')) ||
        pool.find((v) => v.name.toLowerCase().includes('us')) ||
        pool[0]
      );
    } else {
      // Anime system
      return (
        pool.find((v) => v.name.toLowerCase().includes('samantha') || v.name.toLowerCase().includes('victoria')) ||
        pool.find((v) => v.name.toLowerCase().includes('female')) ||
        pool[0]
      );
    }
  }

  /**
   * Speak a raw text string with System Persona audio adjustments
   */
  public speak(text: string, force: boolean = false): void {
    if (!this.synth || !this.settings.enabled || this.isMuted) return;

    const now = Date.now();
    // Anti-spam debounce for non-forced messages
    if (!force && now - this.lastSpokenTime < this.ANTI_SPAM_DEBOUNCE_MS) {
      return;
    }

    try {
      this.synth.cancel(); // Cancel stale speech for instant responsiveness
      const utterance = new SpeechSynthesisUtterance(text);

      const voice = this.selectVoiceForPersona();
      if (voice) {
        utterance.voice = voice;
      }

      let pitchModifier = this.settings.pitch;
      let rateModifier = this.settings.rate;

      switch (this.settings.persona) {
        case 'monarch':
          pitchModifier = 0.85;
          rateModifier = 1.05;
          break;
        case 'architect':
          pitchModifier = 0.95;
          rateModifier = 1.0;
          break;
        case 'commander':
          pitchModifier = 0.9;
          rateModifier = 1.18;
          break;
        case 'anime':
          pitchModifier = 1.2;
          rateModifier = 1.1;
          break;
      }

      utterance.pitch = Math.max(0.5, Math.min(2.0, pitchModifier));
      utterance.rate = Math.max(0.5, Math.min(2.0, rateModifier));
      utterance.volume = Math.max(0.1, Math.min(1.0, this.settings.volume));

      this.lastSpokenTime = now;
      this.synth.speak(utterance);
    } catch (e) {
      console.warn('AI TTS vocalization interrupted:', e);
    }
  }

  /**
   * Smart Biomechanical Error Handler:
   * Only triggers voice when the flaw persists for > 0.5s, with 3.5s anti-spam cooldown.
   */
  public reportBiomechanicsFlaw(flawType: BiomechanicalFlawType, isCurrentlyFlawed: boolean): void {
    if (!this.settings.autoFormCues || !this.settings.enabled || this.isMuted) return;

    const now = Date.now();

    if (!isCurrentlyFlawed) {
      this.errorStartTimestamps.delete(flawType);
      return;
    }

    if (!this.errorStartTimestamps.has(flawType)) {
      this.errorStartTimestamps.set(flawType, now);
      return;
    }

    const firstDetectedAt = this.errorStartTimestamps.get(flawType)!;
    const persistence = now - firstDetectedAt;

    // Must persist > 0.5s before spoken
    if (persistence >= this.ERROR_PERSISTENCE_THRESHOLD_MS) {
      if (now - this.lastSpokenTime >= this.ANTI_SPAM_DEBOUNCE_MS) {
        this.speakFormCorrection(flawType);
        // Reset timestamp so it doesn't immediately repeat
        this.errorStartTimestamps.set(flawType, now);
      }
    }
  }

  /**
   * Spoken Form Corrections with Bilingual English/Hindi options
   */
  public speakFormCorrection(type: BiomechanicalFlawType): void {
    const isHindi = this.settings.language === 'hi';

    const phrasesEn: Record<BiomechanicalFlawType, string[]> = {
      waist_sagging: [
        'Keep your core tight and lift your waist.',
        'Engage your glutes and align your spine.',
        'Do not sag your waist, hold straight.'
      ],
      shallow_depth: [
        'Go lower, chest to the floor.',
        'Push deeper, reach 85 degrees depth.',
        'Full range of motion required.'
      ],
      flared_elbows: [
        'Tuck your elbows back at 45 degrees.',
        'Arrowhead trajectory! Keep elbows back.',
        'Do not flare your elbows outward.'
      ],
      hand_width: [
        'Adjust hand width to shoulder level.',
        'Place wrists directly under shoulders.',
        'Hand alignment too wide, bring them in.'
      ],
      squat_shallow: [
        'Squat deeper, hips below parallel.',
        'Sink your hips down to 85 degrees.',
        'Full squat depth required.'
      ],
      plank_sagging: [
        'Hold iron core straight, lift your hips.',
        'Tighten your abdomen and glutes.'
      ],
      pike_angle: [
        'Form an inverted V shape, elevate your hips.',
        'Drive head forward into tripod position.',
        'Keep pike angle sharp for shoulder loading.'
      ],
      good_depth: [
        'Perfect depth! Drive up!',
        'Optimal angle reached!'
      ],
      lockout_top: [
        'Lock out at the apex.',
        'Full lockout achieved.'
      ],
      cadence_speed_up: [
        'Pick up the pace, Hunter!',
        'Maintain the rep rhythm.'
      ],
      cadence_slow_down: [
        'Control the descent, explode up.'
      ]
    };

    const phrasesHi: Record<BiomechanicalFlawType, string[]> = {
      waist_sagging: ['कमर सीधी रखो और कोर टाइट करो।'],
      shallow_depth: ['छाती पूरी नीचे ले जाओ।'],
      flared_elbows: ['कोहनी पीछे 45 डिग्री पर रखो।'],
      hand_width: ['हाथों के बीच सही दूरी बनाओ।'],
      squat_shallow: ['पूरा नीचे बैठो, हिप्स नीचे लाओ।'],
      plank_sagging: ['कमर सीधी रखो, हिप्स ऊपर उठाओ।'],
      pike_angle: ['हिप्स ऊपर उठाकर उल्टा V आकार बनाओ।'],
      good_depth: ['शानदार गहराई! ऊपर आओ!'],
      lockout_top: ['पूरा ऊपर लॉक करो।'],
      cadence_speed_up: ['रफ़्तार बढ़ाओ!'],
      cadence_slow_down: ['धीरे नीचे जाओ।']
    };

    const pool = isHindi ? phrasesHi[type] : phrasesEn[type];
    if (pool && pool.length > 0) {
      const selected = pool[Math.floor(Math.random() * pool.length)];
      this.speak(selected, false);
    }
  }

  /**
   * Positive Encouragement & Rep Count callouts
   */
  public speakRepCount(currentReps: number, targetReps: number): void {
    if (!this.settings.autoRepMilestones || !this.settings.enabled || this.isMuted) return;

    const repNames = [
      'Zero', 'One!', 'Two!', 'Three!', 'Four!', 'Five!',
      'Six!', 'Seven!', 'Eight!', 'Nine!', 'Ten!',
      'Eleven!', 'Twelve!', 'Thirteen!', 'Fourteen!', 'Fifteen!',
      'Sixteen!', 'Seventeen!', 'Eighteen!', 'Nineteen!', 'Twenty!'
    ];

    const repStr = repNames[currentReps] || `${currentReps}!`;

    if (currentReps === Math.floor(targetReps / 2) && targetReps >= 6) {
      this.speak(`${repStr} Halfway there! Great form, keep going!`, true);
    } else if (currentReps === targetReps - 1) {
      this.speak(`${repStr} Final rep, push it!`, true);
    } else if (currentReps >= targetReps) {
      this.speak(`${repStr} Target cleared! Outstanding power!`, true);
    } else {
      this.speak(repStr, false);
    }
  }

  public speakFormCue(type: 'deeper' | 'lockout' | 'sagging' | 'good_depth' | 'cadence_speed_up' | 'cadence_slow_down'): void {
    const map: Record<string, BiomechanicalFlawType> = {
      deeper: 'shallow_depth',
      lockout: 'lockout_top',
      sagging: 'waist_sagging',
      good_depth: 'good_depth',
      cadence_speed_up: 'cadence_speed_up',
      cadence_slow_down: 'cadence_slow_down'
    };
    const mapped = map[type] || 'shallow_depth';
    this.speakFormCorrection(mapped);
  }

  public speakRepMilestone(currentReps: number, targetReps: number): void {
    this.speakRepCount(currentReps, targetReps);
  }

  public speakSetComplete(exerciseName: string, setIndex: number, totalSets: number): void {
    if (setIndex >= totalSets) {
      this.speak(`Exercise complete: ${exerciseName}. All ${totalSets} sets cleared. Rest cycle initiated.`, true);
    } else {
      this.speak(`Set ${setIndex} of ${totalSets} complete. Rest timer started.`, true);
    }
  }

  public speakLevelUp(level: number, rank: string): void {
    this.speak(`System Alert! Level Up! You reached Level ${level}. Rank: ${rank}!`, true);
  }

  public speakQuestComplete(title: string): void {
    this.speak(`Quest Complete: ${title}. Daily mission cleared. Arise, Monarch!`, true);
  }

  public speakPenaltyAlert(): void {
    this.speak(`Warning! Daily Quest incomplete. Penalty Protocol activated!`, true);
  }

  public speakRestCountdown(secondsLeft: number): void {
    if (secondsLeft === 10) {
      this.speak('10 seconds remaining. Get ready.', true);
    } else if (secondsLeft === 3) {
      this.speak('Three, two, one. Begin set!', true);
    }
  }
}

export const aiTts = new AiTtsEngine();
