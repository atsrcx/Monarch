/**
 * SYSTEM: MONARCH CALISTHENICS - Comprehensive Exercise Definitions Registry
 * Defines biomechanical parameters, joint angle thresholds, landmark requirements,
 * hand/foot placement standards, symmetry rules, tempo guidelines, and correction messages
 * for every calisthenics movement in the system.
 */

export type ExerciseId =
  | 'pushup'
  | 'push-standard'
  | 'push-knee'
  | 'diamond_pushup'
  | 'push-diamond'
  | 'wide_pushup'
  | 'archer_pushup'
  | 'push-archer'
  | 'pike_pushup'
  | 'push-pike'
  | 'squat'
  | 'squat-deep'
  | 'pistol_squat'
  | 'plank'
  | 'plank-hollow'
  | 'planche_lean'
  | 'planche-lean'
  | 'planche-tuck'
  | 'planche-full'
  | 'lsit'
  | 'core-lsit'
  | 'handstand_pushup'
  | 'handstand-wall'
  | 'handstand-freestanding'
  | 'lunge';

export type CameraAngleRequirement =
  | 'SIDE_SAGITTAL'      // 90° pure side view
  | 'ANGLED_SAGITTAL'    // 45° diagonal angle (best for arm/body combined)
  | 'FRONT_ANTERIOR'     // 0° straight front view (best for hand width, symmetry)
  | 'SIDE_OR_ANGLED';    // Either 45° or 90°

export interface JointAngleRange {
  primaryJointName: string;
  secondaryJointName: string;
  lockoutMinAngle: number;       // Angle indicating start / lockout
  inflectionTargetAngle: number; // Angle indicating full depth / completion
  maxDepthThreshold: number;     // Maximum allowable depth (prevent hyper-extension)
  spineMinAngle: number;         // Minimum spine alignment angle
  spineMaxAngle: number;         // Maximum spine alignment angle
  secondaryMin?: number;
  secondaryMax?: number;
}

export interface HandFootPlacementRule {
  type: 'hand_width' | 'foot_stance' | 'diamond_geometry' | 'unilateral_stance' | 'planche_lean';
  idealRatioMin: number;         // Distance(Wrists) / Distance(Shoulders) or similar
  idealRatioMax?: number;
  idealMin?: number;
  idealMax?: number;
  description: string;
  cueTooNarrow: string;
  cueTooWide: string;
}

export interface PostureRule {
  id: string;
  title: string;
  instruction: string;
  rule?: string;
  biomechanicalReason: string;
  flawKey: string;
}

export interface ScoringWeights {
  depthWeight: number;           // e.g. 0.35
  alignmentWeight: number;       // e.g. 0.35
  symmetryWeight: number;        // e.g. 0.15
  handPlacementWeight: number;   // e.g. 0.15
}

export interface TempoGuidelines {
  eccentricSeconds: number;      // Target descent time
  isometricPauseMs: number;      // Target inflection hold
  concentricSeconds: number;     // Target drive time
}

export interface ExerciseDefinition {
  exerciseId: string;
  canonicalKey: ExerciseId;
  name: string;
  category: 'push' | 'pull' | 'legs' | 'core' | 'balance' | 'isometric';
  difficultyTier: 1 | 2 | 3 | 4;
  isIsometric: boolean;          // true for planks, planche holds, l-sits (tracked in seconds)
  isHoldExercise?: boolean;      // alias for isIsometric
  requiredCameraAngle: CameraAngleRequirement;
  cameraAngleAdvice: string;
  
  // Landmark keypoint requirements
  requiredLandmarks: {
    name: string;
    indices: number[];
  }[];

  // Joint Angles & ROM
  angleRanges: JointAngleRange;

  // Placement Standards
  placementRules: HandFootPlacementRule;

  // Posture Rules
  postureRules: PostureRule[];

  // Symmetry & Tempo
  symmetryToleranceDegrees: number; // Max allowed disparity between left & right limbs
  tempo: TempoGuidelines;

  // Scoring
  scoringWeights: ScoringWeights;

  // Correction Cues & Voice Feedback
  correctionMessages: {
    lockoutCue: string;
    depthReachedCue: string;
    descendingCue: string;
    ascendingCue: string;
    flawedAlignmentCue: string;
    flawedDepthCue: string;
    flawedPlacementCue: string;
    flawedSymmetryCue: string;
  };

  // 3D Demonstrator mapping
  demonstratorType: 'pushup_standard' | 'pushup_diamond' | 'squat_deep' | 'squat_pistol' | 'plank_iron';
}

export const EXERCISE_DEFINITIONS: Record<string, ExerciseDefinition> = {
  // 1. STANDARD PUSH-UP
  pushup: {
    exerciseId: 'pushup',
    canonicalKey: 'pushup',
    name: 'Standard Push-Up (45° Arrowhead)',
    category: 'push',
    difficultyTier: 1,
    isIsometric: false,
    requiredCameraAngle: 'ANGLED_SAGITTAL',
    cameraAngleAdvice: 'Place camera at 45° angle, capturing hands, chest, and ankles.',
    requiredLandmarks: [
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Elbows', indices: [13, 14] },
      { name: 'Wrists', indices: [15, 16] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Elbow Flexion (θ)',
      secondaryJointName: 'Spine Neutrality (θ)',
      lockoutMinAngle: 160,
      inflectionTargetAngle: 85,
      maxDepthThreshold: 65,
      spineMinAngle: 160,
      spineMaxAngle: 195
    },
    placementRules: {
      type: 'hand_width',
      idealRatioMin: 0.85,
      idealMax: 1.30,
      description: 'Hands shoulder-width apart directly below shoulder joint.',
      cueTooNarrow: 'SPACE HANDS SLIGHTLY WIDER (SHOULDER WIDTH)',
      cueTooWide: 'MOVE HANDS INWARD TO SHOULDER WIDTH'
    },
    postureRules: [
      {
        id: 'arrowhead',
        title: '45° Arrowhead Elbow Tuck',
        instruction: 'Drive elbows backward toward hips, creating a 45° angle with torso.',
        biomechanicalReason: 'Prevents anterior shoulder impingement and maximizes pectoral load.',
        flawKey: 'flared_elbows'
      },
      {
        id: 'spine_neutral',
        title: 'Hollow Body Spinal Lock',
        instruction: 'Squeeze glutes and core to keep head, hips, and heels in one continuous plane.',
        biomechanicalReason: 'Prevents lumbar hyperextension and protects lumbar discs.',
        flawKey: 'waist_sagging'
      },
      {
        id: 'full_rom',
        title: 'Full Depth & Complete Lockout',
        instruction: 'Lower chest until elbow θ <= 85°, then push all the way to 160° lockout.',
        biomechanicalReason: 'Recruits full range muscle fibers and conditions tendon integrity.',
        flawKey: 'shallow_depth'
      }
    ],
    symmetryToleranceDegrees: 12,
    tempo: {
      eccentricSeconds: 2.0,
      isometricPauseMs: 80,
      concentricSeconds: 1.0
    },
    scoringWeights: {
      depthWeight: 0.40,
      alignmentWeight: 0.35,
      symmetryWeight: 0.15,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'LOCKOUT (θ > 160°): READY FOR DESCENT',
      depthReachedCue: 'VALID 85° DEPTH: DRIVE UP',
      descendingCue: 'CONTROLLED ECCENTRIC DESCENT',
      ascendingCue: 'DRIVE UP THROUGH MID-PALM',
      flawedAlignmentCue: 'ALIGN SPINE: LIFT HIPS & TUCK PELVIS',
      flawedDepthCue: 'DESCENT TOO SHALLOW: REACH 85° DEPTH',
      flawedPlacementCue: 'ADJUST HANDS TO SHOULDER WIDTH',
      flawedSymmetryCue: 'EVEN LOAD ON BOTH ARMS'
    },
    demonstratorType: 'pushup_standard'
  },

  // 2. DIAMOND PUSH-UP
  diamond_pushup: {
    exerciseId: 'diamond_pushup',
    canonicalKey: 'diamond_pushup',
    name: 'Diamond Push-Up (Close Stance ◇)',
    category: 'push',
    difficultyTier: 2,
    isIsometric: false,
    requiredCameraAngle: 'ANGLED_SAGITTAL',
    cameraAngleAdvice: 'Position camera at 45° diagonal so hand diamond and elbow tracking are visible.',
    requiredLandmarks: [
      { name: 'Hands / Wrists', indices: [15, 16] },
      { name: 'Elbows', indices: [13, 14] },
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Elbow Angle (θ)',
      secondaryJointName: 'Diamond Hand Ratio (◇)',
      lockoutMinAngle: 160,
      inflectionTargetAngle: 85,
      maxDepthThreshold: 60,
      spineMinAngle: 160,
      spineMaxAngle: 195,
      secondaryMin: 0.15,
      secondaryMax: 0.55
    },
    placementRules: {
      type: 'diamond_geometry',
      idealRatioMin: 0.15,
      idealMax: 0.55,
      description: 'Thumbs and index fingers touching or close under sternum forming a diamond.',
      cueTooNarrow: 'HANDS OVERLAPPING: SEPARATE SLIGHTLY',
      cueTooWide: '← MOVE HANDS CLOSER (DIAMOND ◇) →'
    },
    postureRules: [
      {
        id: 'diamond_geometry',
        title: 'Close Hand Proximity (◇)',
        instruction: 'Keep index fingers and thumbs close under lower sternum.',
        biomechanicalReason: 'Shifts mechanical advantage directly onto triceps brachii and inner pectoralis.',
        flawKey: 'hand_width'
      },
      {
        id: 'elbow_rib_tracking',
        title: 'Elbow Rib Hugging',
        instruction: 'Track elbows tightly along sides of the ribcage during descent.',
        biomechanicalReason: 'Protects wrist extensor tendons from excessive shear stress.',
        flawKey: 'flared_elbows'
      },
      {
        id: 'sternum_touch',
        title: 'Chest-to-Hand Contact Depth',
        instruction: 'Lower sternum until it touches or hovers 1 inch above the diamond.',
        biomechanicalReason: 'Ensures maximum triceps stretch reflex.',
        flawKey: 'shallow_depth'
      }
    ],
    symmetryToleranceDegrees: 10,
    tempo: {
      eccentricSeconds: 2.2,
      isometricPauseMs: 100,
      concentricSeconds: 1.0
    },
    scoringWeights: {
      depthWeight: 0.35,
      alignmentWeight: 0.25,
      symmetryWeight: 0.15,
      handPlacementWeight: 0.25
    },
    correctionMessages: {
      lockoutCue: 'DIAMOND LOCKOUT: BEGIN DESCENT',
      depthReachedCue: 'TOUCH STERNUM TO DIAMOND: DRIVE UP',
      descendingCue: 'HUG ELBOWS TIGHT TO RIBS',
      ascendingCue: 'SQUEEZE TRICEPS & PUSH UP',
      flawedAlignmentCue: 'SQUEEZE GLUTES & HOLD SPINE LEVEL',
      flawedDepthCue: 'LOWER CHEST DIRECTLY TO DIAMOND',
      flawedPlacementCue: 'BRING HANDS TOGETHER (DIAMOND ◇)',
      flawedSymmetryCue: 'PRESS EQUALLY FROM BOTH PALMS'
    },
    demonstratorType: 'pushup_diamond'
  },

  // 3. WIDE PUSH-UP
  wide_pushup: {
    exerciseId: 'wide_pushup',
    canonicalKey: 'wide_pushup',
    name: 'Wide Stance Push-Up (Pectoral Isolation)',
    category: 'push',
    difficultyTier: 2,
    isIsometric: false,
    requiredCameraAngle: 'FRONT_ANTERIOR',
    cameraAngleAdvice: 'Front view captures hand span and bilateral chest lowering.',
    requiredLandmarks: [
      { name: 'Wrists', indices: [15, 16] },
      { name: 'Elbows', indices: [13, 14] },
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Elbow Angle (θ)',
      secondaryJointName: 'Spine Alignment (θ)',
      lockoutMinAngle: 155,
      inflectionTargetAngle: 90,
      maxDepthThreshold: 70,
      spineMinAngle: 160,
      spineMaxAngle: 195
    },
    placementRules: {
      type: 'hand_width',
      idealRatioMin: 1.35,
      idealMax: 1.95,
      description: 'Hands placed at 1.4x to 1.8x shoulder width.',
      cueTooNarrow: 'WIDEN HANDS (1.5× SHOULDER WIDTH)',
      cueTooWide: 'HANDS TOO WIDE: PULL INWARD SLIGHTLY'
    },
    postureRules: [
      {
        id: 'wide_span',
        title: 'Wide Pectoral Span',
        instruction: 'Maintain wide stance to emphasize horizontal adduction of pectorals.',
        biomechanicalReason: 'Maximizes chest stretch across horizontal fiber alignment.',
        flawKey: 'hand_width'
      },
      {
        id: 'scapular_control',
        title: 'Depress & Retract Scapulae',
        instruction: 'Keep shoulders away from ears; do not shrug.',
        biomechanicalReason: 'Shields subacromial space from rotator cuff impingement.',
        flawKey: 'flared_elbows'
      }
    ],
    symmetryToleranceDegrees: 12,
    tempo: {
      eccentricSeconds: 2.0,
      isometricPauseMs: 80,
      concentricSeconds: 1.2
    },
    scoringWeights: {
      depthWeight: 0.35,
      alignmentWeight: 0.35,
      symmetryWeight: 0.15,
      handPlacementWeight: 0.15
    },
    correctionMessages: {
      lockoutCue: 'WIDE LOCKOUT: READY',
      depthReachedCue: 'CHEST DEPTH HIT: DRIVE UP',
      descendingCue: 'LOWER CHEST BETWEEN WIDE HANDS',
      ascendingCue: 'SQUEEZE CHEST TO DRIVE UP',
      flawedAlignmentCue: 'LOCK CORE: PREVENT SAGGING',
      flawedDepthCue: 'LOWER STERNUM CLOSER TO FLOOR',
      flawedPlacementCue: 'ADJUST WIDE HAND SPAN (1.5×)',
      flawedSymmetryCue: 'KEEP PUSH EVEN ACROSS CHEST'
    },
    demonstratorType: 'pushup_standard'
  },

  // 4. ARCHER PUSH-UP
  archer_pushup: {
    exerciseId: 'archer_pushup',
    canonicalKey: 'archer_pushup',
    name: 'Archer Push-Up (Unilateral Pressing)',
    category: 'push',
    difficultyTier: 3,
    isIsometric: false,
    requiredCameraAngle: 'FRONT_ANTERIOR',
    cameraAngleAdvice: 'Front view shows working arm flexion vs assist arm full extension.',
    requiredLandmarks: [
      { name: 'Working Arm', indices: [11, 13, 15] },
      { name: 'Assist Arm', indices: [12, 14, 16] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Working Elbow (θ)',
      secondaryJointName: 'Assist Arm Lock (θ)',
      lockoutMinAngle: 155,
      inflectionTargetAngle: 80,
      maxDepthThreshold: 60,
      spineMinAngle: 155,
      spineMaxAngle: 195,
      secondaryMin: 160,
      secondaryMax: 185
    },
    placementRules: {
      type: 'unilateral_stance',
      idealRatioMin: 1.70,
      idealMax: 2.30,
      description: 'Ultra wide hand position with weight shifted over working palm.',
      cueTooNarrow: 'EXTEND ASSIST HAND FURTHER OUTWARD',
      cueTooWide: 'PULL WORKING HAND CLOSER UNDER SHOULDER'
    },
    postureRules: [
      {
        id: 'assist_arm_lock',
        title: 'Straight Assist Arm',
        instruction: 'Keep non-working assist arm straight (θ > 160°) like an archer drawing a bow.',
        biomechanicalReason: 'Transfers 75-80% of body mass onto the unilateral working shoulder.',
        flawKey: 'flared_elbows'
      },
      {
        id: 'pelvic_stability',
        title: 'Anti-Rotation Core Tension',
        instruction: 'Resist rotational twist in hips; keep pelvis square to the floor.',
        biomechanicalReason: 'Strengthens internal/external obliques and rotational stability.',
        flawKey: 'waist_sagging'
      }
    ],
    symmetryToleranceDegrees: 25,
    tempo: {
      eccentricSeconds: 2.5,
      isometricPauseMs: 120,
      concentricSeconds: 1.2
    },
    scoringWeights: {
      depthWeight: 0.40,
      alignmentWeight: 0.30,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.20
    },
    correctionMessages: {
      lockoutCue: 'ARCHER APEX: SHIFT WEIGHT OVER ONE ARM',
      depthReachedCue: 'DEEP UNILATERAL DEPTH: DRIVE UP',
      descendingCue: 'LOWER TOWARD WORKING WRIST',
      ascendingCue: 'PUSH EXPLOSIVELY THROUGH SINGLE PALM',
      flawedAlignmentCue: 'SQUARE HIPS: DO NOT TWIST PELVIS',
      flawedDepthCue: 'DEEPEN FLEXION IN WORKING ARM',
      flawedPlacementCue: 'EXTEND ASSIST ARM COMPLETELY STRAIGHT',
      flawedSymmetryCue: 'MAINTAIN PURE UNILATERAL BIAS'
    },
    demonstratorType: 'pushup_standard'
  },

  // 5. PIKE PUSH-UP
  pike_pushup: {
    exerciseId: 'pike_pushup',
    canonicalKey: 'pike_pushup',
    name: 'Elevated Pike Push-Up (Vertical Shoulder Press)',
    category: 'balance',
    difficultyTier: 2,
    isIsometric: false,
    requiredCameraAngle: 'SIDE_SAGITTAL',
    cameraAngleAdvice: '90° Side profile is mandatory to track hip angle and head-forward tripod path.',
    requiredLandmarks: [
      { name: 'Head/Nose', indices: [0] },
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Elbows', indices: [13, 14] },
      { name: 'Wrists', indices: [15, 16] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Elbow Angle (θ)',
      secondaryJointName: 'Hip Pike Angle (θ)',
      lockoutMinAngle: 155,
      inflectionTargetAngle: 85,
      maxDepthThreshold: 65,
      spineMinAngle: 75,
      spineMaxAngle: 130
    },
    placementRules: {
      type: 'hand_width',
      idealRatioMin: 0.85,
      idealMax: 1.25,
      description: 'Hands shoulder-width, feet walked in close to hips creating an inverted V.',
      cueTooNarrow: 'HANDS TOO CLOSE: OPEN TO SHOULDER WIDTH',
      cueTooWide: 'BRING HANDS IN TO SHOULDER WIDTH'
    },
    postureRules: [
      {
        id: 'inverted_v_pike',
        title: 'Strict Inverted-V Hip Angle',
        instruction: 'Elevate hips high into the air, keeping hip angle between 80° and 125°.',
        biomechanicalReason: 'Aligns gravitational vector through anterior and lateral deltoids.',
        flawKey: 'pike_angle'
      },
      {
        id: 'tripod_head_path',
        title: 'Forward Tripod Head Path',
        instruction: 'Lower head in front of hands to form a tripod vertex at bottom.',
        biomechanicalReason: 'Preserves vertical forearm angles and protects rotator cuff.',
        flawKey: 'shallow_depth'
      },
      {
        id: 'push_through_shoulders',
        title: 'Lockout Through Scapular Elevation',
        instruction: 'At apex, push head through arms to complete vertical extension.',
        biomechanicalReason: 'Develops upward scapular rotation and overhead mobility.',
        flawKey: 'flared_elbows'
      }
    ],
    symmetryToleranceDegrees: 12,
    tempo: {
      eccentricSeconds: 2.2,
      isometricPauseMs: 100,
      concentricSeconds: 1.0
    },
    scoringWeights: {
      depthWeight: 0.40,
      alignmentWeight: 0.35,
      symmetryWeight: 0.15,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'ELEVATE HIPS (INVERTED V): READY',
      depthReachedCue: 'TRIPOD HEAD TOUCH: PRESS BACK & UP',
      descendingCue: 'MOVE HEAD FORWARD IN FRONT OF HANDS',
      ascendingCue: 'PRESS UP & PUSH HEAD THROUGH ARMS',
      flawedAlignmentCue: 'ELEVATE HIPS HIGHER: TIGHTEN INVERTED V',
      flawedDepthCue: 'LOWER HEAD FORWARD UNTIL ELBOW θ < 85°',
      flawedPlacementCue: 'WALK FEET CLOSER TO ELEVATE PELVIS',
      flawedSymmetryCue: 'PRESS VERTICALLY WITH EQUAL SHOULDER DRIVE'
    },
    demonstratorType: 'pushup_standard'
  },

  // 6. DEEP CALISTHENICS SQUAT
  squat: {
    exerciseId: 'squat',
    canonicalKey: 'squat',
    name: 'Deep Calisthenics Squat (Full ROM)',
    category: 'legs',
    difficultyTier: 1,
    isIsometric: false,
    requiredCameraAngle: 'SIDE_OR_ANGLED',
    cameraAngleAdvice: 'Side or 45° angle captures knee depth below 85° and upright torso posture.',
    requiredLandmarks: [
      { name: 'Hips', indices: [23, 24] },
      { name: 'Knees', indices: [25, 26] },
      { name: 'Ankles', indices: [27, 28] },
      { name: 'Shoulders', indices: [11, 12] }
    ],
    angleRanges: {
      primaryJointName: 'Knee Flexion (θ)',
      secondaryJointName: 'Spine & Torso Lean (θ)',
      lockoutMinAngle: 165,
      inflectionTargetAngle: 85,
      maxDepthThreshold: 60,
      spineMinAngle: 140,
      spineMaxAngle: 180
    },
    placementRules: {
      type: 'foot_stance',
      idealRatioMin: 0.90,
      idealMax: 1.40,
      description: 'Feet shoulder-width apart, toes turned outward 15° to 30°.',
      cueTooNarrow: 'WIDEN STANCE TO SHOULDER WIDTH',
      cueTooWide: 'NARROW FEET SLIGHTLY'
    },
    postureRules: [
      {
        id: 'break_parallel',
        title: 'Deep Femur Depth (θ < 85°)',
        instruction: 'Sink hips below knee joint line to achieve true full range of motion.',
        biomechanicalReason: 'Recruits vastus medialis obliquus (VMO) and full gluteal elongation.',
        flawKey: 'squat_shallow'
      },
      {
        id: 'upright_torso',
        title: 'Proud Chest & Neutral Lumbar',
        instruction: 'Keep torso upright; do not collapse chest forward past 40° lean.',
        biomechanicalReason: 'Minimizes spinal shear forces and maintains balance over midfoot.',
        flawKey: 'waist_sagging'
      },
      {
        id: 'knee_tracking',
        title: 'Knee Tracking Over Toes',
        instruction: 'Drive knees outward in line with 2nd and 3rd toes; avoid valgus collapse.',
        biomechanicalReason: 'Protects ACL/MCL ligaments and activates hip abductors.',
        flawKey: 'flared_elbows'
      }
    ],
    symmetryToleranceDegrees: 10,
    tempo: {
      eccentricSeconds: 2.0,
      isometricPauseMs: 100,
      concentricSeconds: 1.0
    },
    scoringWeights: {
      depthWeight: 0.45,
      alignmentWeight: 0.35,
      symmetryWeight: 0.15,
      handPlacementWeight: 0.05
    },
    correctionMessages: {
      lockoutCue: 'STAND TALL (θ > 165°): READY',
      depthReachedCue: 'DEEP DEPTH (<85°): DRIVE UP THROUGH HEELS',
      descendingCue: 'SINK HIPS BACK AND DOWN',
      ascendingCue: 'DRIVE UP THROUGH MIDFOOT & EXTEND GLUTES',
      flawedAlignmentCue: 'KEEP CHEST PROUD • DO NOT BEND FORWARD',
      flawedDepthCue: 'SINK HIPS LOWER: BREAK 90° PARALLEL',
      flawedPlacementCue: 'CHECK STANCE: FEET SHOULDER-WIDTH',
      flawedSymmetryCue: 'DISTRIBUTE WEIGHT EQUALLY ACROSS BOTH FEET'
    },
    demonstratorType: 'squat_deep'
  },

  // 7. PISTOL SQUAT
  pistol_squat: {
    exerciseId: 'pistol_squat',
    canonicalKey: 'pistol_squat',
    name: 'Pistol Squat (Single Leg Isolation)',
    category: 'legs',
    difficultyTier: 3,
    isIsometric: false,
    requiredCameraAngle: 'SIDE_OR_ANGLED',
    cameraAngleAdvice: 'Side or 45° angle tracks working knee depth and elevated lead leg.',
    requiredLandmarks: [
      { name: 'Working Knee/Ankle', indices: [25, 27] },
      { name: 'Free Leg Knee/Ankle', indices: [26, 28] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Shoulders', indices: [11, 12] }
    ],
    angleRanges: {
      primaryJointName: 'Working Knee (θ)',
      secondaryJointName: 'Free Leg Elevation (θ)',
      lockoutMinAngle: 165,
      inflectionTargetAngle: 75,
      maxDepthThreshold: 50,
      spineMinAngle: 130,
      spineMaxAngle: 180,
      secondaryMin: 150,
      secondaryMax: 185
    },
    placementRules: {
      type: 'unilateral_stance',
      idealRatioMin: 0.0,
      idealMax: 0.5,
      description: 'Single leg balance with opposite leg extended straight forward.',
      cueTooNarrow: 'HOLD WORKING FOOT FLAT',
      cueTooWide: 'ALIGN WORKING KNEE OVER FOOT'
    },
    postureRules: [
      {
        id: 'full_single_depth',
        title: 'Deep Unilateral Flexion (θ < 75°)',
        instruction: 'Lower hamstring to touch calf of working leg.',
        biomechanicalReason: 'Tests extreme unilateral strength, ankle dorsiflexion, and hip stability.',
        flawKey: 'squat_shallow'
      },
      {
        id: 'extended_lead_leg',
        title: 'Elevated Non-Working Leg',
        instruction: 'Hold non-working leg straight out in front without touching the floor.',
        biomechanicalReason: 'Recruits hip flexors and rectus abdominis isometric tension.',
        flawKey: 'waist_sagging'
      }
    ],
    symmetryToleranceDegrees: 25,
    tempo: {
      eccentricSeconds: 2.5,
      isometricPauseMs: 100,
      concentricSeconds: 1.2
    },
    scoringWeights: {
      depthWeight: 0.50,
      alignmentWeight: 0.30,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'STAND BALANCED ON ONE LEG: READY',
      depthReachedCue: 'FULL PISTOL DEPTH: EXPLODE UP',
      descendingCue: 'REACH FORWARD WITH ARMS FOR BALANCE',
      ascendingCue: 'DRIVE HARD THROUGH WORKING HEEL',
      flawedAlignmentCue: 'MAINTAIN ANKLE DORSIFLEXION & TALL CHEST',
      flawedDepthCue: 'LOWER UNTIL HAMSTRING HITS CALF',
      flawedPlacementCue: 'HOLD NON-WORKING LEG OFF FLOOR',
      flawedSymmetryCue: 'STABILIZE WORKING KNEE TRACKING'
    },
    demonstratorType: 'squat_pistol'
  },

  // 8. HOLLOW BODY ISOMETRIC PLANK
  plank: {
    exerciseId: 'plank',
    canonicalKey: 'plank',
    name: 'Hollow Body Isometric Plank',
    category: 'core',
    difficultyTier: 1,
    isIsometric: true,
    requiredCameraAngle: 'SIDE_SAGITTAL',
    cameraAngleAdvice: 'Full side view captures straight head-to-heel spine alignment.',
    requiredLandmarks: [
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Elbows/Wrists', indices: [13, 15] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Knees', indices: [25, 26] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Spine Linearity (θ)',
      secondaryJointName: 'Core Hold Stability',
      lockoutMinAngle: 165,
      inflectionTargetAngle: 180,
      maxDepthThreshold: 195,
      spineMinAngle: 165,
      spineMaxAngle: 185
    },
    placementRules: {
      type: 'hand_width',
      idealRatioMin: 0.80,
      idealMax: 1.25,
      description: 'Elbows or wrists directly under shoulders; feet together or hip-width.',
      cueTooNarrow: 'PLACE ELBOWS DIRECTLY UNDER SHOULDERS',
      cueTooWide: 'BRING ELBOWS UNDER SHOULDERS'
    },
    postureRules: [
      {
        id: 'posterior_pelvic_tilt',
        title: 'Posterior Pelvic Tilt & Hollow Body',
        instruction: 'Tuck tailbone under, squeeze glutes, and draw belly button inward.',
        biomechanicalReason: 'Engages transverse abdominis and rectus abdominis while eliminating lumbar lordosis.',
        flawKey: 'plank_sagging'
      },
      {
        id: 'scapular_protraction',
        title: 'Push Floor Away (Protraction)',
        instruction: 'Spread shoulder blades apart; do not let chest cave between shoulders.',
        biomechanicalReason: 'Activates serratus anterior and establishes solid shoulder girdle foundation.',
        flawKey: 'waist_sagging'
      }
    ],
    symmetryToleranceDegrees: 10,
    tempo: {
      eccentricSeconds: 0,
      isometricPauseMs: 1000,
      concentricSeconds: 0
    },
    scoringWeights: {
      depthWeight: 0.20,
      alignmentWeight: 0.60,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'RIGID HOLLOW PLANK LOCKED: HOLD TIMER ACTIVE',
      depthReachedCue: 'HOLDING ROCK SOLID CORE',
      descendingCue: 'STABILIZE SPINAL HORIZONTAL PLANE',
      ascendingCue: 'MAINTAIN TIGHT ABDOMINAL COMPRESSION',
      flawedAlignmentCue: 'HIPS SAGGING: SQUEEZE GLUTES & LIFT WAIST',
      flawedDepthCue: 'FLATTEN LUMBAR SPINE',
      flawedPlacementCue: 'ALIGN ELBOWS DIRECTLY UNDER SHOULDERS',
      flawedSymmetryCue: 'KEEP HIPS SQUARE TO THE GROUND'
    },
    demonstratorType: 'plank_iron'
  },

  // 9. PLANCHE LEAN (ISOMETRIC)
  planche_lean: {
    exerciseId: 'planche_lean',
    canonicalKey: 'planche_lean',
    name: 'Planche Lean (Protraction Hold)',
    category: 'isometric',
    difficultyTier: 3,
    isIsometric: true,
    requiredCameraAngle: 'SIDE_SAGITTAL',
    cameraAngleAdvice: 'Pure 90° side profile is essential to measure forward shoulder lean angle past wrists.',
    requiredLandmarks: [
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Wrists', indices: [15, 16] },
      { name: 'Elbows', indices: [13, 14] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Forward Lean Angle (θ)',
      secondaryJointName: 'Elbow Lockout (θ)',
      lockoutMinAngle: 170,
      inflectionTargetAngle: 25, // 25° forward lean past wrists
      maxDepthThreshold: 45,
      spineMinAngle: 165,
      spineMaxAngle: 185
    },
    placementRules: {
      type: 'planche_lean',
      idealRatioMin: 0.85,
      idealMax: 1.20,
      description: 'Hands turned slightly outward (30°-45°) for bicep tendon safety.',
      cueTooNarrow: 'HANDS SHOULDER WIDTH',
      cueTooWide: 'BRING HANDS IN TO SHOULDER WIDTH'
    },
    postureRules: [
      {
        id: 'forward_displacement',
        title: 'Forward Shoulder Displacement',
        instruction: 'Lean shoulders forward past wrists while keeping feet on the floor.',
        biomechanicalReason: 'Conditions distal bicep tendons and anterior deltoids for full planche hold.',
        flawKey: 'pike_angle'
      },
      {
        id: 'full_scapular_protraction',
        title: 'Maximum Scapular Protraction',
        instruction: 'Push floor away creating an upper back dome (hollow chest).',
        biomechanicalReason: 'Critical serratus anterior recruitment needed for horizontal static leverage.',
        flawKey: 'waist_sagging'
      },
      {
        id: 'arm_lockout',
        title: 'Straight Arm Lockout (θ >= 170°)',
        instruction: 'Do not bend elbows even 1 degree; lock triceps completely.',
        biomechanicalReason: 'Forces load onto connective tissue and straight-arm kinetic chain.',
        flawKey: 'flared_elbows'
      }
    ],
    symmetryToleranceDegrees: 8,
    tempo: {
      eccentricSeconds: 0,
      isometricPauseMs: 1000,
      concentricSeconds: 0
    },
    scoringWeights: {
      depthWeight: 0.40,
      alignmentWeight: 0.40,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'PLANCHE LEAN LOCKED: HOLD ACTIVE',
      depthReachedCue: 'EXCELLENT FORWARD PROTRACTION',
      descendingCue: 'LEAN SHOULDERS FURTHER FORWARD PAST WRISTS',
      ascendingCue: 'MAINTAIN LOCKED ELBOWS & DOME UPPER BACK',
      flawedAlignmentCue: 'DO NOT SINK: PUSH FLOOR AWAY (PROTRACT)',
      flawedDepthCue: 'LEAN SHOULDERS MORE FORWARD',
      flawedPlacementCue: 'TURN FINGERS SLIGHTLY OUTWARD',
      flawedSymmetryCue: 'KEEP SHOULDERS LEVEL & PARALLEL'
    },
    demonstratorType: 'plank_iron'
  },

  // 10. L-SIT STATIC HOLD
  lsit: {
    exerciseId: 'lsit',
    canonicalKey: 'lsit',
    name: 'L-Sit Compression Ground / Bar Hold',
    category: 'core',
    difficultyTier: 2,
    isIsometric: true,
    requiredCameraAngle: 'SIDE_SAGITTAL',
    cameraAngleAdvice: 'Side view clearly captures 90° leg elevation and scapular depression clearance.',
    requiredLandmarks: [
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Wrists', indices: [15, 16] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Knees', indices: [25, 26] },
      { name: 'Ankles', indices: [27, 28] }
    ],
    angleRanges: {
      primaryJointName: 'Hip Flexion Compression (θ)',
      secondaryJointName: 'Knee Lockout (θ)',
      lockoutMinAngle: 165,
      inflectionTargetAngle: 90,
      maxDepthThreshold: 75,
      spineMinAngle: 80,
      spineMaxAngle: 110,
      secondaryMin: 160,
      secondaryMax: 180
    },
    placementRules: {
      type: 'hand_width',
      idealRatioMin: 0.85,
      idealMax: 1.15,
      description: 'Hands pressed firmly beside hips on ground or parallettes.',
      cueTooNarrow: 'HANDS BESIDE HIPS',
      cueTooWide: 'PULL HANDS CLOSER TO HIPS'
    },
    postureRules: [
      {
        id: 'scapular_depression',
        title: 'Active Scapular Depression',
        instruction: 'Drive shoulders down away from ears to lift hips completely off the floor.',
        biomechanicalReason: 'Latissimus dorsi and lower trapezius fire to elevate entire bodyweight.',
        flawKey: 'waist_sagging'
      },
      {
        id: 'quad_lockout',
        title: 'Legs Straight & Parallel to Floor',
        instruction: 'Lock knees completely and point toes straight forward.',
        biomechanicalReason: 'Demands extreme rectus femoris and iliopsoas isometric contraction.',
        flawKey: 'shallow_depth'
      }
    ],
    symmetryToleranceDegrees: 10,
    tempo: {
      eccentricSeconds: 0,
      isometricPauseMs: 1000,
      concentricSeconds: 0
    },
    scoringWeights: {
      depthWeight: 0.40,
      alignmentWeight: 0.40,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'L-SIT ELEVATION LOCKED: HOLD TIMER ACTIVE',
      depthReachedCue: 'LEGS PARALLEL: HOLD STRONG COMPRESSION',
      descendingCue: 'LIFT HEELS HIGHER OFF GROUND',
      ascendingCue: 'DEPRESS SCAPULA AND SQUEEZE QUADS',
      flawedAlignmentCue: 'DEPRESS SHOULDERS: CLEAR HIPS OFF FLOOR',
      flawedDepthCue: 'LOCK KNEES AND RAISE LEGS TO 90°',
      flawedPlacementCue: 'POSITION HANDS DIRECTLY ALONGSIDE HIPS',
      flawedSymmetryCue: 'MAINTAIN LEVEL LEG HEIGHT'
    },
    demonstratorType: 'plank_iron'
  },

  // 11. WALL / FREESTANDING HANDSTAND PUSH-UP
  handstand_pushup: {
    exerciseId: 'handstand_pushup',
    canonicalKey: 'handstand_pushup',
    name: 'Handstand Push-Up (Vertical Inversion)',
    category: 'balance',
    difficultyTier: 4,
    isIsometric: false,
    requiredCameraAngle: 'SIDE_OR_ANGLED',
    cameraAngleAdvice: 'Side or 45° angle shows vertical line, elbow tracking, and head touch depth.',
    requiredLandmarks: [
      { name: 'Wrists', indices: [15, 16] },
      { name: 'Elbows', indices: [13, 14] },
      { name: 'Shoulders', indices: [11, 12] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Ankles', indices: [27, 28] },
      { name: 'Nose', indices: [0] }
    ],
    angleRanges: {
      primaryJointName: 'Elbow Angle (θ)',
      secondaryJointName: 'Inversion Alignment (θ)',
      lockoutMinAngle: 160,
      inflectionTargetAngle: 85,
      maxDepthThreshold: 65,
      spineMinAngle: 160,
      spineMaxAngle: 195
    },
    placementRules: {
      type: 'hand_width',
      idealRatioMin: 0.90,
      idealMax: 1.30,
      description: 'Hands shoulder-width apart, fingers splayed for grip.',
      cueTooNarrow: 'HANDS SHOULDER WIDTH',
      cueTooWide: 'NARROW HANDS TO SHOULDER WIDTH'
    },
    postureRules: [
      {
        id: 'vertical_line',
        title: 'Tight Hollow Inversion Line',
        instruction: 'Maintain straight line from wrists through shoulders, hips, and toes.',
        biomechanicalReason: 'Eliminates energy leaks and balances center of mass over palm base.',
        flawKey: 'waist_sagging'
      },
      {
        id: 'forward_tripod',
        title: 'Forward Tripod Descent',
        instruction: 'Lower crown of head forward of hands creating a stable tripod.',
        biomechanicalReason: 'Biomechanically optimal pressing path for anterior deltoid and triceps.',
        flawKey: 'shallow_depth'
      }
    ],
    symmetryToleranceDegrees: 10,
    tempo: {
      eccentricSeconds: 2.5,
      isometricPauseMs: 100,
      concentricSeconds: 1.2
    },
    scoringWeights: {
      depthWeight: 0.45,
      alignmentWeight: 0.35,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'HANDSTAND APEX LOCKED: BEGIN DESCENT',
      depthReachedCue: 'TRIPOD HEAD TOUCH: PRESS VERTICAL',
      descendingCue: 'LOWER HEAD FORWARD OF HANDS',
      ascendingCue: 'DRIVE HARD THROUGH PALMS & EXTEND SHOULDERS',
      flawedAlignmentCue: 'TUCK RIBS: PREVENT BANANA BACK ARCH',
      flawedDepthCue: 'LOWER HEAD ALL THE WAY TO FLOOR/PAD',
      flawedPlacementCue: 'SET HANDS SHOULDER WIDTH',
      flawedSymmetryCue: 'PRESS EQUALLY FROM BOTH SHOULDERS'
    },
    demonstratorType: 'pushup_standard'
  },

  // 12. LUNGE
  lunge: {
    exerciseId: 'lunge',
    canonicalKey: 'lunge',
    name: 'Dynamic Calisthenics Lunge (90° Stride)',
    category: 'legs',
    difficultyTier: 1,
    isIsometric: false,
    requiredCameraAngle: 'SIDE_SAGITTAL',
    cameraAngleAdvice: 'Side view tracks both front and back knee 90° angles.',
    requiredLandmarks: [
      { name: 'Lead Knee/Ankle', indices: [25, 27] },
      { name: 'Rear Knee/Ankle', indices: [26, 28] },
      { name: 'Hips', indices: [23, 24] },
      { name: 'Shoulders', indices: [11, 12] }
    ],
    angleRanges: {
      primaryJointName: 'Lead Knee Flexion (θ)',
      secondaryJointName: 'Torso Upright Angle (θ)',
      lockoutMinAngle: 160,
      inflectionTargetAngle: 90,
      maxDepthThreshold: 75,
      spineMinAngle: 150,
      spineMaxAngle: 185
    },
    placementRules: {
      type: 'foot_stance',
      idealRatioMin: 0.8,
      idealMax: 1.5,
      description: 'Long stride allowing front knee to reach 90° with shin vertical.',
      cueTooNarrow: 'STEP DEEPER INTO STRIDE',
      cueTooWide: 'SHORTEN STRIDE SLIGHTLY'
    },
    postureRules: [
      {
        id: 'dual_90_angles',
        title: 'Dual 90° Knee Angles',
        instruction: 'Drop rear knee toward floor until both knees form clean 90° angles.',
        biomechanicalReason: 'Balances quad loading on lead leg with hip flexor stretch on rear leg.',
        flawKey: 'squat_shallow'
      },
      {
        id: 'upright_spine',
        title: 'Vertical Torso Alignment',
        instruction: 'Keep spine perpendicular to floor; do not lean over front thigh.',
        biomechanicalReason: 'Ensures gluteus medius stabilization and pelvic alignment.',
        flawKey: 'waist_sagging'
      }
    ],
    symmetryToleranceDegrees: 12,
    tempo: {
      eccentricSeconds: 2.0,
      isometricPauseMs: 80,
      concentricSeconds: 1.0
    },
    scoringWeights: {
      depthWeight: 0.40,
      alignmentWeight: 0.40,
      symmetryWeight: 0.10,
      handPlacementWeight: 0.10
    },
    correctionMessages: {
      lockoutCue: 'STAND TALL (STRIDE RESET): READY',
      depthReachedCue: '90° DEPTH HIT: DRIVE UP THROUGH FRONT HEEL',
      descendingCue: 'LOWER REAR KNEE STRAIGHT DOWN',
      ascendingCue: 'DRIVE UP THROUGH FRONT MIDFOOT',
      flawedAlignmentCue: 'KEEP TORSO TALL & SPINE VERTICAL',
      flawedDepthCue: 'LOWER REAR KNEE CLOSER TO FLOOR (90°)',
      flawedPlacementCue: 'ADJUST STRIDE LENGTH',
      flawedSymmetryCue: 'KEEP HIPS FACING STRAIGHT AHEAD'
    },
    demonstratorType: 'squat_deep'
  }
};

/**
 * Normalizes any exercise string / ID into a valid ExerciseDefinition
 */
export function getExerciseDefinition(rawIdOrName?: string): ExerciseDefinition {
  if (!rawIdOrName) return EXERCISE_DEFINITIONS.pushup;
  const lower = rawIdOrName.toLowerCase().trim();

  if (lower.includes('diamond')) return EXERCISE_DEFINITIONS.diamond_pushup;
  if (lower.includes('wide')) return EXERCISE_DEFINITIONS.wide_pushup;
  if (lower.includes('archer')) return EXERCISE_DEFINITIONS.archer_pushup;
  if (lower.includes('pike')) return EXERCISE_DEFINITIONS.pike_pushup;
  if (lower.includes('pistol')) return EXERCISE_DEFINITIONS.pistol_squat;
  if (lower.includes('squat')) return EXERCISE_DEFINITIONS.squat;
  if (lower.includes('planche') && (lower.includes('lean') || lower.includes('tuck') || lower.includes('full'))) {
    return EXERCISE_DEFINITIONS.planche_lean;
  }
  if (lower.includes('lsit') || lower.includes('l-sit')) return EXERCISE_DEFINITIONS.lsit;
  if (lower.includes('handstand') || lower.includes('hspu')) return EXERCISE_DEFINITIONS.handstand_pushup;
  if (lower.includes('plank')) return EXERCISE_DEFINITIONS.plank;
  if (lower.includes('lunge')) return EXERCISE_DEFINITIONS.lunge;

  // Direct key lookup
  if (EXERCISE_DEFINITIONS[lower]) {
    return EXERCISE_DEFINITIONS[lower];
  }

  // Fallback to pushup
  return EXERCISE_DEFINITIONS.pushup;
}
