/**
 * SYSTEM: MONARCH CALISTHENICS - Web Audio API Synthesizer
 * Zero external MP3 dependencies. Generates authentic Cyberpunk / Solo Leveling audio cues.
 */

class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private masterGainNode: GainNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
        this.masterGainNode = this.ctx.createGain();
        this.masterGainNode.gain.setValueAtTime(0.3, this.ctx.currentTime);
        this.masterGainNode.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    this.initContext();
    if (this.masterGainNode && this.ctx) {
      this.masterGainNode.gain.setValueAtTime(Math.max(0, Math.min(1, vol)), this.ctx.currentTime);
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  // Futuristic soft ding when reaching valid bottom depth (< 80 deg)
  public playBottomValid() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, now); // A5 note
    osc.frequency.exponentialRampToValueAtTime(1320, now + 0.15); // E6 note

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(gain);
    gain.connect(this.masterGainNode);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  // Punchy resonant chime when a full rep is counted at lockout
  public playRepCounted() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;

    // Harmonic 1 (Lead high chime)
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.setValueAtTime(1174.66, now + 0.08); // D6
    gain1.gain.setValueAtTime(0.25, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc1.connect(gain1);
    gain1.connect(this.masterGainNode);
    osc1.start(now);
    osc1.stop(now + 0.4);

    // Harmonic 2 (Sub bass punch)
    const subOsc = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(180, now);
    subOsc.frequency.exponentialRampToValueAtTime(60, now + 0.2);
    subGain.gain.setValueAtTime(0.3, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    subOsc.connect(subGain);
    subGain.connect(this.masterGainNode);
    subOsc.start(now);
    subOsc.stop(now + 0.25);
  }

  // Solo Leveling System startup / window open sound
  public playSystemOpen() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const chords = [440, 554.37, 659.25, 880]; // A major chord arpeggio

    chords.forEach((freq, index) => {
      if (!this.ctx || !this.masterGainNode) return;
      const startTime = now + index * 0.04;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.15, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.3);

      osc.connect(gain);
      gain.connect(this.masterGainNode);
      osc.start(startTime);
      osc.stop(startTime + 0.35);
    });
  }

  // Quest initiation chime
  public playQuestStart() {
    this.playSystemOpen();
  }

  // Interval timer tick / beep for combat rounds
  public playTimerBeep() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1046.5, now);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(this.masterGainNode);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  // Triumphant Solo Leveling Level Up Fanfare
  public playLevelUp() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const notes = [
      { f: 523.25, t: 0 },    // C5
      { f: 659.25, t: 0.12 }, // E5
      { f: 783.99, t: 0.24 }, // G5
      { f: 1046.5, t: 0.36 }, // C6
      { f: 1318.5, t: 0.52 }, // E6
      { f: 1567.98, t: 0.7 }  // G6 (Grand sustain)
    ];

    notes.forEach((note) => {
      if (!this.ctx || !this.masterGainNode) return;
      const st = now + note.t;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(note.f, st);
      gain.gain.setValueAtTime(0.28, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.6);

      osc.connect(gain);
      gain.connect(this.masterGainNode);
      osc.start(st);
      osc.stop(st + 0.65);
    });
  }

  // Penalty Quest Warning Alarm (Deep resonant siren pulse)
  public playPenaltyAlert() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const st = now + i * 0.3;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(320, st);
      osc.frequency.exponentialRampToValueAtTime(140, st + 0.22);

      gain.gain.setValueAtTime(0.3, st);
      gain.gain.exponentialRampToValueAtTime(0.01, st + 0.25);

      osc.connect(gain);
      gain.connect(this.masterGainNode);
      osc.start(st);
      osc.stop(st + 0.26);
    }
  }

  // Rest timer 1-second countdown tick
  public playRestTick() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, now);
    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(this.masterGainNode);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  // Rest timer completion (GO! signal)
  public playRestComplete() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1046.5, now); // C6
    osc.frequency.setValueAtTime(2093.0, now + 0.1); // C7
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gain);
    gain.connect(this.masterGainNode);
    osc.start(now);
    osc.stop(now + 0.45);
  }

  // Haptic UI micro click
  public playClick() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGainNode) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, now);
    gain.gain.setValueAtTime(0.05, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

    osc.connect(gain);
    gain.connect(this.masterGainNode);
    osc.start(now);
    osc.stop(now + 0.04);
  }
}

export const soundEngine = new SoundSynthesizer();
