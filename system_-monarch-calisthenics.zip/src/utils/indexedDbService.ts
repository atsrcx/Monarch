/**
 * SYSTEM: MONARCH CALISTHENICS - IndexedDB Persistent Storage Layer
 * Stores Hunter profile, daily quest completion history, workout session logs,
 * and calibration metrics with high reliability.
 */

export interface StoredWorkoutLog {
  id: string;
  date: string; // YYYY-MM-DD
  timestamp: number;
  exerciseName: string;
  completedReps: number;
  targetReps: number;
  completionRate: number; // 0.0 - 1.0
  accuracyScore: number;
  xpEarned: number;
  flawsDetected: string[];
}

export interface StoredDailyRecord {
  date: string; // YYYY-MM-DD
  targetReps: number;
  completedReps: number;
  completionPercentage: number;
  isPassed: boolean;
  questTitle: string;
}

const DB_NAME = 'MonarchCalisthenicsDB';
const DB_VERSION = 1;

class IndexedDBService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private getDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB not supported'));
        return;
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Store 1: Workout Logs
        if (!db.objectStoreNames.contains('workouts')) {
          const workoutStore = db.createObjectStore('workouts', { keyPath: 'id' });
          workoutStore.createIndex('date', 'date', { unique: false });
          workoutStore.createIndex('timestamp', 'timestamp', { unique: false });
        }

        // Store 2: Daily Records
        if (!db.objectStoreNames.contains('daily_records')) {
          db.createObjectStore('daily_records', { keyPath: 'date' });
        }

        // Store 3: Key-Value State
        if (!db.objectStoreNames.contains('system_state')) {
          db.createObjectStore('system_state', { keyPath: 'key' });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  public async saveWorkoutLog(log: StoredWorkoutLog): Promise<void> {
    try {
      const db = await this.getDB();
      const tx = db.transaction('workouts', 'readwrite');
      const store = tx.objectStore('workouts');
      store.put(log);
      await new Promise((res, rej) => {
        tx.oncomplete = () => res(undefined);
        tx.onerror = () => rej(tx.error);
      });
    } catch (e) {
      console.warn('IndexedDB saveWorkoutLog fallback to localStorage:', e);
      try {
        const logs = JSON.parse(localStorage.getItem('monarch_db_workouts') || '[]');
        logs.push(log);
        localStorage.setItem('monarch_db_workouts', JSON.stringify(logs.slice(-50)));
      } catch (err) {
        // ignore
      }
    }
  }

  public async getRecentWorkouts(days = 7): Promise<StoredWorkoutLog[]> {
    try {
      const db = await this.getDB();
      const tx = db.transaction('workouts', 'readonly');
      const store = tx.objectStore('workouts');
      const request = store.getAll();

      const results = await new Promise<StoredWorkoutLog[]>((res, rej) => {
        request.onsuccess = () => res(request.result || []);
        request.onerror = () => rej(request.error);
      });

      return results.sort((a, b) => b.timestamp - a.timestamp).slice(0, days * 5);
    } catch (e) {
      try {
        const logs: StoredWorkoutLog[] = JSON.parse(localStorage.getItem('monarch_db_workouts') || '[]');
        return logs.sort((a, b) => b.timestamp - a.timestamp).slice(0, days * 5);
      } catch {
        return [];
      }
    }
  }

  public async saveDailyRecord(record: StoredDailyRecord): Promise<void> {
    try {
      const db = await this.getDB();
      const tx = db.transaction('daily_records', 'readwrite');
      const store = tx.objectStore('daily_records');
      store.put(record);
      await new Promise((res, rej) => {
        tx.oncomplete = () => res(undefined);
        tx.onerror = () => rej(tx.error);
      });
    } catch (e) {
      try {
        const daily = JSON.parse(localStorage.getItem('monarch_db_daily') || '{}');
        daily[record.date] = record;
        localStorage.setItem('monarch_db_daily', JSON.stringify(daily));
      } catch {
        // ignore
      }
    }
  }

  public async getLast3DaysCompletionRate(): Promise<{
    averageCompletion: number;
    daysEvaluated: number;
    passedDays: number;
  }> {
    try {
      const db = await this.getDB();
      const tx = db.transaction('daily_records', 'readonly');
      const store = tx.objectStore('daily_records');
      const request = store.getAll();

      const records = await new Promise<StoredDailyRecord[]>((res, rej) => {
        request.onsuccess = () => res(request.result || []);
        request.onerror = () => rej(request.error);
      });

      if (!records || records.length === 0) {
        return { averageCompletion: 1.0, daysEvaluated: 0, passedDays: 0 };
      }

      // Sort by date descending
      const sorted = records.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 3);
      const sum = sorted.reduce((acc, r) => acc + (r.completionPercentage || 0), 0);
      const passed = sorted.filter((r) => r.isPassed || r.completionPercentage >= 100).length;

      return {
        averageCompletion: sorted.length > 0 ? sum / sorted.length : 1.0,
        daysEvaluated: sorted.length,
        passedDays: passed
      };
    } catch {
      return { averageCompletion: 1.0, daysEvaluated: 0, passedDays: 0 };
    }
  }
}

export const indexedDbService = new IndexedDBService();
