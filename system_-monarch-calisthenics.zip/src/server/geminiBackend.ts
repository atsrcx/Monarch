import { GoogleGenAI } from '@google/genai';

export interface UserProfile {
  name: string;
  age: number;
  weightKg: number;
  heightCm: number;
  hunterClass: string;
  currentRank: string;
  level: number;
  str: number;
  agi: number;
  end: number;
  sen: number;
}

export interface WorkoutHistoryItem {
  date: string;
  exercise: string;
  completedReps: number;
  targetReps: number;
  accuracyScore: number;
}

export interface GeneratedQuestResponse {
  questId: string;
  questTitle: string;
  systemMessage: string;
  difficulty: 'NORMAL' | 'HARD' | 'HELL';
  rankRequirement: string;
  totalEstimatedTimeMin: number;
  estimatedCalories: number;
  totalTargetReps: number;
  drillSergeantCalibration: {
    completionRateLast3Days: number;
    progressionMultiplier: number; // e.g. 1.1 for +10%
    drillOrder: string;
  };
  exercises: {
    id: string;
    name: string;
    category: 'push' | 'core' | 'legs' | 'pull';
    sets: number;
    repsPerSet: number;
    restSeconds: number;
    xpPerRep: number;
    description: string;
    formFocus: string;
    targetAngleDepth: number;
    lockoutAngle: number;
  }[];
  rewards: {
    xp: number;
    statPoints: number;
    gold: number;
    titleUnlock?: string;
  };
  penalty: {
    name: string;
    description: string;
    tasks: string[];
    timeLimitMin: number;
  };
}

export interface ZeroToHeroProgressionTier {
  tierRank: 'E-Rank (Initiate)' | 'D-Rank (Apprentice)' | 'C-Rank (Adept)' | 'B-Rank (Elite)' | 'A-Rank (Shadow Master)' | 'S-Rank (Monarch)';
  levelRange: string;
  title: string;
  benchmarkGoal: string;
  progressionChain: {
    exerciseName: string;
    masteryRequirement: string;
    biomechanicalFocus: string;
    targetAngle: number;
  }[];
  physiologicalBenefits: string[];
}

export interface ZeroToHeroRoadmap {
  hunterName: string;
  currentTier: string;
  nextBenchmark: string;
  tiers: ZeroToHeroProgressionTier[];
  systemAssessment: string;
}

export interface FormRemediationResult {
  detectedFlaws: string[];
  immediateCorrectionCue: string;
  regressionExercise: {
    name: string;
    sets: number;
    reps: number;
    tempo: string;
    description: string;
  };
  muscleActivationDrill: string;
  systemWarning: string;
}

export interface PersonalizedOnboardingRequest {
  name: string;
  age: number;
  weightKg: number;
  heightCm: number;
  experience: 'beginner' | 'intermediate' | 'advanced' | 'elite';
  goals: string[];
  equipment: string[];
  trainingFrequency: number;
  limitations?: string;
  personalDescription: string; // "TELL MONARCH ABOUT YOURSELF"
  apiKey?: string;
}

export interface PersonalizedOnboardingPlan {
  hunterTitle: string;
  hunterArchetype: string;
  biometricAnalysis: string;
  personalizedStrategy: string;
  startingTier: 'FOUNDATION' | 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'ELITE';
  targetKeySkill: string;
  recommendedWeeklyCadence: string;
  firstDailyProtocol: GeneratedQuestResponse;
  combatConditioningFocus: string;
  safetyRemediationProtocol: string;
}

export interface WeeklyPlanResponse {
  planTitle: string;
  weekObjective: string;
  days: {
    dayNumber: number;
    dayName: string;
    type: 'CALISTHENICS_PUSH' | 'CALISTHENICS_PULL' | 'LEGS_CORE' | 'COMBAT_FITNESS' | 'SKILL_MASTERY' | 'RECOVERY_MOBILITY';
    title: string;
    estimatedMinutes: number;
    keyFocus: string;
    exercises: {
      name: string;
      sets: number;
      repsOrDuration: string;
      notes: string;
    }[];
  }[];
}

/**
 * Formats raw Gemini SDK / Google API errors into clean, human-readable Hunter diagnostics
 */
export function formatGeminiErrorMessage(error: any): string {
  if (!error) return 'An unknown error occurred with the AI service.';

  let msg = typeof error === 'string' ? error : error.message || String(error);

  // Check if error message is or contains stringified Google RPC JSON
  try {
    const jsonMatch = msg.match(/\{[\s\S]*"error"[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed?.error?.message) {
        msg = parsed.error.message;
      }
    }
  } catch {
    // Continue with raw message
  }

  if (
    msg.includes('429') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('quota') ||
    msg.includes('Quota exceeded') ||
    msg.includes('rate-limits')
  ) {
    return 'Gemini API Free Tier quota reached (20 req/day limit). The Monarch engine has seamlessly engaged the offline System Architect fallback so you can continue training uninterrupted.';
  }

  if (
    msg.includes('API_KEY_INVALID') ||
    msg.includes('API key not valid') ||
    (msg.includes('400') && msg.includes('key'))
  ) {
    return 'Invalid Gemini API Key. Please verify your API key from Google AI Studio.';
  }

  if (
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('high demand') ||
    msg.includes('overloaded')
  ) {
    return 'Gemini AI neural grid is temporarily under high demand. System fallback engaged.';
  }

  return msg.replace(/[\n\r]+/g, ' ').trim().slice(0, 260);
}

/**
 * Resilient Gemini Content Generator with multi-model fallback and transient quota/spike handling
 */
async function resilientGenerateContent(
  ai: GoogleGenAI,
  params: {
    contents: any;
    config?: any;
  }
): Promise<{ text: string; modelUsed: string }> {
  // Primary, lite, and alias models from SKILL.md specification
  const modelsToTry = ['gemini-3.7-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: params.config
      });

      const text = response.text || '';
      if (text) {
        return { text, modelUsed: model };
      }
    } catch (err: any) {
      lastError = err;
      const isTransient =
        err?.status === 503 ||
        err?.status === 429 ||
        (err?.message &&
          (err.message.includes('503') ||
            err.message.includes('429') ||
            err.message.includes('RESOURCE_EXHAUSTED') ||
            err.message.includes('Quota exceeded') ||
            err.message.includes('high demand') ||
            err.message.includes('UNAVAILABLE')));

      if (isTransient) {
        // Try the next fallback model in the list
        await new Promise((res) => setTimeout(res, 200));
        continue;
      } else {
        // For non-transient errors (like invalid key), stop trying further
        break;
      }
    }
  }

  throw lastError || new Error('Failed to generate content from AI models');
}

export async function testGeminiConnectionBackend(providedApiKey?: string): Promise<{ success: boolean; message: string; modelUsed?: string }> {
  const apiKey = providedApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      success: false,
      message: 'Gemini API Key is not configured in environment or settings.'
    };
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const result = await resilientGenerateContent(ai, {
      contents: 'Ping test for Solo Leveling Monarch Calisthenics System. Reply strictly with JSON: {"status":"online","system":"Monarch Calisthenics Grand Architect Link"}',
      config: {
        responseMimeType: 'application/json'
      }
    });

    return {
      success: true,
      message: `System Link Established: Grand Architect Online (${result.modelUsed})`,
      modelUsed: result.modelUsed
    };
  } catch (error: any) {
    return {
      success: false,
      message: formatGeminiErrorMessage(error)
    };
  }
}

/**
 * Gemini "Zero-to-Hero" Adaptive Engine & Drill Sergeant
 * - Daily Calibration: Checks the last 3 days of completion percentage
 * - Level 1-5: Generates beginner volume (3 sets of 8, knee/incline pushups if struggling)
 * - If User hits target (completion >= 95%): Automatically increases target by +10%
 * - Strictly JSON Output
 */
export async function generateAdaptiveQuestBackend(params: {
  profile: UserProfile;
  history: WorkoutHistoryItem[];
  specialization?: string;
  providedApiKey?: string;
  last3DaysCompletionRate?: number; // 0.0 - 1.0 or 0 - 100
}): Promise<GeneratedQuestResponse> {
  const apiKey = params.providedApiKey || process.env.GEMINI_API_KEY;
  const completionPct = params.last3DaysCompletionRate !== undefined
    ? (params.last3DaysCompletionRate > 1 ? params.last3DaysCompletionRate / 100 : params.last3DaysCompletionRate)
    : 1.0;

  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return getFallbackQuest(params.profile, params.specialization, completionPct);
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const prompt = `You are the strict "DRILL SERGEANT & SYSTEM ARCHITECT" from Solo Leveling.
Calculate and generate the exact daily Calisthenics routine for Hunter ${params.profile.name}.

Hunter Details:
- Level: ${params.profile.level} (${params.profile.currentRank})
- Stats: STR: ${params.profile.str}, AGI: ${params.profile.agi}, END: ${params.profile.end}
- Weight: ${params.profile.weightKg}kg, Height: ${params.profile.heightCm}cm
- Last 3 Days Completion Rate: ${(completionPct * 100).toFixed(0)}%
- Recent History: ${JSON.stringify(params.history.slice(-3))}

Progression Logic:
1. If Hunter is Level 1-5: Generate beginner volume (e.g., 3 sets of 8, incline or standard pushups with 45° arrowhead tuck).
2. If Hunter has completion rate >= 95%: Automatically INCREASE daily target reps by +10% over base baseline.
3. If Hunter struggled (completion < 75%): Keep volume manageable (3 sets of 8-10) to prioritize biomechanical perfection and prevent overreaching.
4. Output STRICT JSON ONLY matching the GeneratedQuestResponse schema with totalTargetReps and drillSergeantCalibration.`;

    const { text } = await resilientGenerateContent(ai, {
      contents: prompt,
      config: {
        systemInstruction: 'You are the Solo Leveling Drill Sergeant. Return ONLY strict JSON.',
        responseMimeType: 'application/json'
      }
    });

    const cleanJson = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleanJson);
    if (parsed && parsed.exercises && Array.isArray(parsed.exercises) && parsed.exercises.length > 0) {
      const mappedExercises = parsed.exercises.map((ex: any, idx: number) => ({
        id: ex.id || `ex-${idx + 1}`,
        name: ex.name || 'Standard Push-ups (45° Arrowhead)',
        category: ex.category || 'push',
        sets: Number(ex.sets) || 3,
        repsPerSet: Number(ex.repsPerSet) || (params.profile.level <= 5 ? 8 : 12),
        restSeconds: Number(ex.restSeconds) || 60,
        xpPerRep: Number(ex.xpPerRep) || 10,
        description: ex.description || 'Strict 45-degree arrowhead elbow tucking toward hips with full chest depth.',
        formFocus: ex.formFocus || 'Elbows drive backward relative to torso at 45 degrees. Lock out at top.',
        targetAngleDepth: Number(ex.targetAngleDepth) || 80,
        lockoutAngle: Number(ex.lockoutAngle) || 165
      }));

      const calculatedTotalReps = mappedExercises.reduce((sum: number, e: any) => sum + (e.sets * e.repsPerSet), 0);

      return {
        questId: parsed.questId || `quest-${Date.now()}`,
        questTitle: parsed.questTitle || 'DAILY QUEST: MONARCH AWAKENING DRILL',
        systemMessage: parsed.systemMessage || `[DRILL SERGEANT] Target calibrated: ${calculatedTotalReps} total repetitions. Maintain strict 45° arrowhead form.`,
        difficulty: parsed.difficulty || (params.profile.level > 30 ? 'HARD' : 'NORMAL'),
        rankRequirement: parsed.rankRequirement || params.profile.currentRank,
        totalEstimatedTimeMin: parsed.totalEstimatedTimeMin || 20,
        estimatedCalories: parsed.estimatedCalories || 160,
        totalTargetReps: parsed.totalTargetReps || calculatedTotalReps,
        drillSergeantCalibration: {
          completionRateLast3Days: completionPct,
          progressionMultiplier: completionPct >= 0.95 ? 1.1 : 1.0,
          drillOrder: parsed.drillSergeantCalibration?.drillOrder || (completionPct >= 0.95 ? '+10% Progressive Overload Applied' : 'Form Baseline Sustained')
        },
        exercises: mappedExercises,
        rewards: {
          xp: parsed.rewards?.xp || 250,
          statPoints: parsed.rewards?.statPoints || 3,
          gold: parsed.rewards?.gold || 500,
          titleUnlock: parsed.rewards?.titleUnlock
        },
        penalty: {
          name: parsed.penalty?.name || 'PENALTY PROTOCOL',
          description: parsed.penalty?.description || 'Survive penalty conditioning if daily quest is neglected.',
          tasks: parsed.penalty?.tasks || ['100 Deep Push-ups', '100 Bodyweight Squats'],
          timeLimitMin: parsed.penalty?.timeLimitMin || 240
        }
      };
    }
    return getFallbackQuest(params.profile, params.specialization, completionPct);
  } catch (error) {
    return getFallbackQuest(params.profile, params.specialization, completionPct);
  }
}

export function getFallbackQuest(profile: UserProfile, specialization = 'Push & Chest', completionRate = 1.0): GeneratedQuestResponse {
  const isBeginner = profile.level <= 5;
  const isMaster = profile.level >= 50;
  const isAdvanced = profile.level >= 20;

  // Base rep volume scaled by level and 3-day completion rate (+10% if hitting targets)
  const multiplier = completionRate >= 0.95 ? 1.1 : 1.0;

  const basePushReps = isBeginner ? 8 : isMaster ? 18 : isAdvanced ? 14 : 10;
  const pushReps = Math.round(basePushReps * multiplier);
  const pushSets = isBeginner ? 3 : 4;

  const pushExercise = isBeginner
    ? {
        id: 'push-beginner',
        name: 'Standard Push-ups (45° Arrowhead)',
        category: 'push' as const,
        sets: 3,
        repsPerSet: pushReps,
        restSeconds: 60,
        xpPerRep: 10,
        description: 'Controlled descent with elbows tracking backward at 45 degrees. Lockout at top.',
        formFocus: 'Elbows tucked toward hips. θ_elbow < 85° at bottom, > 160° at top.',
        targetAngleDepth: 80,
        lockoutAngle: 165
      }
    : isMaster
    ? {
        id: 'push-monarch',
        name: 'Archer / Pseudo-Planche Push-ups',
        category: 'push' as const,
        sets: 4,
        repsPerSet: pushReps,
        restSeconds: 75,
        xpPerRep: 18,
        description: 'Elite calisthenic pressing with forward lean and deep elbow tuck.',
        formFocus: 'Elbows strictly tucked. Full lockout at top.',
        targetAngleDepth: 75,
        lockoutAngle: 165
      }
    : {
        id: 'push-standard',
        name: 'Diamond & Standard Push-ups',
        category: 'push' as const,
        sets: 3,
        repsPerSet: pushReps,
        restSeconds: 60,
        xpPerRep: 12,
        description: 'Biomechanically locked push-ups with 45° arrowhead trajectory.',
        formFocus: 'Elbows move backward along torso line.',
        targetAngleDepth: 80,
        lockoutAngle: 165
      };

  const totalTargetReps = pushSets * pushReps;

  return {
    questId: `quest-monarch-${new Date().toISOString().slice(0, 10)}`,
    questTitle: `DAILY QUEST: THE MONARCH AWAKENING DRILL`,
    systemMessage: `[DRILL SERGEANT] Level ${profile.level} Hunter Protocol. ${completionRate >= 0.95 ? '+10% Volume Overload Active.' : 'Standard Volume Baseline.'}`,
    difficulty: isMaster ? 'HELL' : isAdvanced ? 'HARD' : 'NORMAL',
    rankRequirement: profile.currentRank || 'E-Rank',
    totalEstimatedTimeMin: 20,
    estimatedCalories: 160,
    totalTargetReps,
    drillSergeantCalibration: {
      completionRateLast3Days: completionRate,
      progressionMultiplier: multiplier,
      drillOrder: completionRate >= 0.95 ? '+10% Progressive Overload Active' : 'Maintain Perfect Biomechanics'
    },
    exercises: [pushExercise],
    rewards: {
      xp: isMaster ? 500 : isAdvanced ? 350 : 200,
      statPoints: isMaster ? 5 : 3,
      gold: 600,
      titleUnlock: profile.level >= 10 ? 'Awakened Calisthenic Hunter' : undefined
    },
    penalty: {
      name: 'PENALTY QUEST: SURVIVAL ZONE',
      description: 'Failure to complete daily quest activates penalty conditioning.',
      tasks: ['100 Deep Push-ups', '100 Bodyweight Squats'],
      timeLimitMin: 240
    }
  };
}

export interface ChatMessage {
  role: 'user' | 'system';
  content: string;
  timestamp?: number;
}

export interface BiomechanicalSessionReport {
  overallScore: number;
  grade: 'S' | 'A' | 'B' | 'C' | 'D';
  systemEvaluation: string;
  strengths: string[];
  biomechanicalWeaknesses: string[];
  recommendedStatAllocation: {
    str: number;
    agi: number;
    end: number;
    sen: number;
    reasoning: string;
  };
  nextWorkoutPrescription: string;
  hunterTitleSuggestion?: string;
}

export async function chatWithSystemArchitectBackend(params: {
  messages: ChatMessage[];
  profile: UserProfile;
  providedApiKey?: string;
}): Promise<{ reply: string; audioSuggestedText?: string }> {
  const apiKey = params.providedApiKey || process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      reply: `[DRILL SERGEANT] Hunter ${params.profile.name}, lock in your 45° arrowhead push-up form. Elbows drive backward toward the hips, chest drops below 85°, full lockout at top.`,
      audioSuggestedText: 'Lock in your 45 degree arrowhead push up form.'
    };
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const systemPrompt = `You are the strict Drill Sergeant & System Architect from Solo Leveling.
Guide Hunter ${params.profile.name} (Level ${params.profile.level}, Rank ${params.profile.currentRank}).
Emphasize 45° arrowhead elbow tucking, lockout at θ > 160°, chest depth θ < 85°.`;

    const conversationHistory = params.messages.map((m) => `${m.role === 'user' ? 'Hunter' : 'System Architect'}: ${m.content}`).join('\n\n');

    const { text } = await resilientGenerateContent(ai, {
      contents: `${conversationHistory}\n\nDrill Sergeant:`,
      config: {
        systemInstruction: systemPrompt
      }
    });

    const reply = text || 'Maintain strict push-up form.';
    return {
      reply,
      audioSuggestedText: reply.slice(0, 160).replace(/[*#]/g, '')
    };
  } catch (error: any) {
    return {
      reply: `[DRILL SERGEANT] Maintain 45° arrowhead elbow tuck and rigid core.`,
      audioSuggestedText: 'Maintain 45 degree arrowhead elbow tuck.'
    };
  }
}

export async function analyzeWorkoutSessionBackend(params: {
  sessionData: {
    totalReps: number;
    totalSets: number;
    averageAngleDepth: number;
    repCadenceSeconds: number;
    antiCheatViolations: number;
    exerciseName: string;
    durationMinutes: number;
  };
  profile: UserProfile;
  providedApiKey?: string;
}): Promise<BiomechanicalSessionReport> {
  const defaultReport: BiomechanicalSessionReport = {
    overallScore: Math.max(70, Math.min(98, 100 - params.sessionData.antiCheatViolations * 5)),
    grade: params.sessionData.antiCheatViolations === 0 && params.sessionData.averageAngleDepth <= 85 ? 'S' : 'A',
    systemEvaluation: `Hunter ${params.profile.name} completed ${params.sessionData.totalReps} verified repetitions with strict 45° arrowhead elbow trajectory.`,
    strengths: [
      `Elbow trajectory maintained backward 45° arrowhead path`,
      `Chest reached deep ~${Math.round(params.sessionData.averageAngleDepth)}° depth`
    ],
    biomechanicalWeaknesses: params.sessionData.antiCheatViolations > 0
      ? ['Minor elbow flare warning on fatigue reps']
      : ['Hold lockout for 0.5s for peak contraction'],
    recommendedStatAllocation: {
      str: 2,
      agi: 1,
      end: 2,
      sen: 1,
      reasoning: 'Allocate +2 STR and +2 END to increase work capacity for next calibration.'
    },
    nextWorkoutPrescription: 'Advance daily target by +10% upon next system reset.'
  };

  return defaultReport;
}

export async function generateZeroToHeroRoadmapBackend(params: {
  profile: UserProfile;
  providedApiKey?: string;
}): Promise<ZeroToHeroRoadmap> {
  const defaultRoadmap: ZeroToHeroRoadmap = {
    hunterName: params.profile.name,
    currentTier: params.profile.currentRank || 'E-Rank',
    nextBenchmark: 'Master 20 Continuous 45° Arrowhead Standard Push-ups with Lockout',
    systemAssessment: `Hunter ${params.profile.name} is progressing through the fundamental calisthenic awakening pathway.`,
    tiers: [
      {
        tierRank: 'E-Rank (Initiate)',
        levelRange: 'Levels 1 - 5',
        title: 'Awakening Foundation',
        benchmarkGoal: '3 sets of 8-12 Incline / Knee -> 15 Standard Pushups',
        progressionChain: [
          {
            exerciseName: 'Incline Pushups (45° Arrowhead)',
            masteryRequirement: '3 sets of 12 reps',
            biomechanicalFocus: '45° elbow tuck and wrist conditioning',
            targetAngle: 85
          },
          {
            exerciseName: 'Standard Pushup Lockdown',
            masteryRequirement: '3 sets of 12 clean reps',
            biomechanicalFocus: 'Full lockout θ > 160°, depth θ < 85°',
            targetAngle: 80
          }
        ],
        physiologicalBenefits: ['Connective tissue remodeling', 'Scapular stability matrix']
      },
      {
        tierRank: 'D-Rank (Apprentice)',
        levelRange: 'Levels 6 - 15',
        title: 'Triceps & Anterior Leverage',
        benchmarkGoal: 'Master 15 Diamond Push-ups and 45s Iron Core Plank',
        progressionChain: [
          {
            exerciseName: 'Diamond Pushups',
            masteryRequirement: '3 sets of 12 reps beneath sternum',
            biomechanicalFocus: 'Triceps lateral head and sternal pectorals',
            targetAngle: 80
          }
        ],
        physiologicalBenefits: ['Tricep tendon durability', 'Overhead pressing base']
      },
      {
        tierRank: 'S-Rank (Monarch)',
        levelRange: 'Levels 50+',
        title: 'Shadow Monarch Calisthenics Mastery',
        benchmarkGoal: 'One-Arm Pushup & Full Planche Pushup Mastery',
        progressionChain: [
          {
            exerciseName: 'One-Arm Pushup',
            masteryRequirement: '5 clean reps per arm',
            biomechanicalFocus: 'Absolute unilateral dominance',
            targetAngle: 80
          }
        ],
        physiologicalBenefits: ['Superhuman strength-to-weight ratio']
      }
    ]
  };

  return defaultRoadmap;
}

export async function remediateFormFlawsBackend(params: {
  flawTypes: string[];
  currentExercise: string;
  profile: UserProfile;
  providedApiKey?: string;
}): Promise<FormRemediationResult> {
  return {
    detectedFlaws: params.flawTypes.length > 0 ? params.flawTypes : ['Elbows flaring in front of shoulder line'],
    immediateCorrectionCue: 'Tuck elbows 45° backward toward your hips. Form the Arrowhead.',
    regressionExercise: {
      name: 'Incline Pushups with 45° Arrowhead Guide',
      sets: 3,
      reps: 10,
      tempo: '3-1-1',
      description: 'Hands elevated on bench to practice backward elbow path with reduced gravity load.'
    },
    muscleActivationDrill: 'Scapular wall slides and band pull-aparts.',
    systemWarning: 'Flaring elbows past 70 degrees puts excessive shear on the anterior shoulder capsule.'
  };
}

/**
 * Generates a bespoke progressive Calisthenics Master plan on first launch / profile update
 */
export async function generatePersonalizedOnboardingPlanBackend(
  req: PersonalizedOnboardingRequest
): Promise<PersonalizedOnboardingPlan> {
  const apiKey = req.apiKey || process.env.GEMINI_API_KEY;

  const fallbackFirstQuest: GeneratedQuestResponse = {
    questId: `quest-onboarding-${Date.now()}`,
    questTitle: 'DAILY PROTOCOL: INITIAL BIOMECHANICAL AWAKENING',
    systemMessage: 'Calibrated to your physical vessel. Complete with strict lockout and depth.',
    difficulty: req.experience === 'elite' || req.experience === 'advanced' ? 'HARD' : 'NORMAL',
    rankRequirement: 'E-Rank',
    totalEstimatedTimeMin: 20,
    estimatedCalories: 180,
    totalTargetReps: 36,
    drillSergeantCalibration: {
      completionRateLast3Days: 1.0,
      progressionMultiplier: 1.0,
      drillOrder: 'Foundation calibration protocol'
    },
    exercises: [
      {
        id: 'pushup',
        name: 'Standard Push-ups (45° Arrowhead)',
        category: 'push',
        sets: 3,
        repsPerSet: req.experience === 'beginner' ? 8 : 12,
        restSeconds: 60,
        xpPerRep: 15,
        description: 'Maintain strict pelvic tuck and 45 degree elbow angle.',
        formFocus: 'Scapular protraction at apex lockout',
        targetAngleDepth: 85,
        lockoutAngle: 160
      },
      {
        id: 'squat',
        name: 'Deep Kinetic Squats',
        category: 'legs',
        sets: 3,
        repsPerSet: 12,
        restSeconds: 45,
        xpPerRep: 10,
        description: 'Full depth below parallel with upright spine.',
        formFocus: 'Torso alignment and knee trajectory',
        targetAngleDepth: 85,
        lockoutAngle: 165
      },
      {
        id: 'plank',
        name: 'Rigid Iron Plank',
        category: 'core',
        sets: 3,
        repsPerSet: 30,
        restSeconds: 45,
        xpPerRep: 12,
        description: 'Posterior pelvic tilt with active glute contraction.',
        formFocus: 'Anti-sag spine stability',
        targetAngleDepth: 175,
        lockoutAngle: 180
      }
    ],
    rewards: {
      xp: 250,
      statPoints: 5,
      gold: 500,
      titleUnlock: 'The Awakened Vessel'
    },
    penalty: {
      name: 'PENALTY PROTOCOL: SURVIVAL DRILL',
      description: 'Failure to complete the calibrated quota initiates high-volume remediation.',
      tasks: ['100 Push-ups', '100 Deep Squats', '180s Plank Hold'],
      timeLimitMin: 240
    }
  };

  const defaultPlan: PersonalizedOnboardingPlan = {
    hunterTitle: `${req.name.toUpperCase()} — THE AWAKENED ATHLETE`,
    hunterArchetype: req.experience === 'beginner'
      ? 'Foundation Kinetic Specialist'
      : req.experience === 'intermediate'
      ? 'Dynamic Calisthenics Master'
      : 'Elite Strength & Leverage Monarch',
    biometricAnalysis: `Physical profile calibrated: ${req.weightKg}kg mass, ${req.heightCm}cm leverage profile, ${req.age} Earth cycles. Training cadence set to ${req.trainingFrequency} sessions/week.`,
    personalizedStrategy: `Focusing on ${req.goals.join(', ')} with progressive overload through bodyweight leverage manipulation, strict biomechanical lockouts, and kinetic movement velocity.`,
    startingTier: req.experience === 'elite'
      ? 'ELITE'
      : req.experience === 'advanced'
      ? 'ADVANCED'
      : req.experience === 'intermediate'
      ? 'INTERMEDIATE'
      : req.experience === 'beginner'
      ? 'BEGINNER'
      : 'FOUNDATION',
    targetKeySkill: req.goals.includes('Planche Progression')
      ? 'Pseudo Planche & Tuck Planche'
      : req.goals.includes('Muscle-Up')
      ? 'Explosive High Pull-up & Muscle-Up'
      : req.goals.includes('Handstand Balance')
      ? 'Wall Handstand & Freestanding Balance'
      : 'Standard Push-Up 45° Arrowhead Mastery',
    recommendedWeeklyCadence: `${req.trainingFrequency} days active training, ${7 - req.trainingFrequency} days active recovery & joint mobility.`,
    firstDailyProtocol: fallbackFirstQuest,
    combatConditioningFocus: 'High-guard stability, rotational core transfer, and athletic footwork agility.',
    safetyRemediationProtocol: req.limitations && req.limitations.trim().length > 0 && req.limitations.toLowerCase() !== 'none'
      ? `Active safeguard: Modified load distribution calibrated for "${req.limitations}". Warm-up joint prep required before loading.`
      : 'Standard joint tendon conditioning and 45° elbow alignment enforced.'
  };

  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return defaultPlan;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const prompt = `You are the MONARCH MASTER AI COACH — a serious, elite, professional athletic calisthenics brain.
Analyze this user's profile and self-description to generate a personalized training profile and master plan.

User Onboarding Profile:
- Name: ${req.name}
- Age: ${req.age}
- Weight: ${req.weightKg} kg
- Height: ${req.heightCm} cm
- Experience Level: ${req.experience}
- Goals: ${req.goals.join(', ')}
- Available Equipment: ${req.equipment.join(', ')}
- Training Frequency: ${req.trainingFrequency} days/week
- Limitations / Injuries: ${req.limitations || 'None'}
- Personal Self-Description: "${req.personalDescription}"

Instructions:
1. Provide deep, serious, athletic biomechanical analysis. No cartoon style, no childish gaming tropes.
2. Formulate a personalized progression strategy based on their specific goals and equipment.
3. Structure an initial daily workout protocol matching the GeneratedQuestResponse JSON schema.
4. Output STRICT JSON conforming to the PersonalizedOnboardingPlan schema.`;

    const { text } = await resilientGenerateContent(ai, {
      contents: prompt,
      config: {
        systemInstruction: 'You are the Monarch Calisthenics Master Brain. Return ONLY valid JSON.',
        responseMimeType: 'application/json'
      }
    });

    const parsed = JSON.parse(text);
    return {
      ...defaultPlan,
      ...parsed,
      firstDailyProtocol: parsed.firstDailyProtocol || defaultPlan.firstDailyProtocol
    };
  } catch (err) {
    console.warn('Personalized onboarding AI fallback:', err);
    return defaultPlan;
  }
}

/**
 * Generates a 7-day progressive Calisthenics & Combat Fitness weekly plan
 */
export async function generateWeeklyPlanBackend(params: {
  profile: UserProfile;
  goals: string[];
  equipment: string[];
  providedApiKey?: string;
}): Promise<WeeklyPlanResponse> {
  const apiKey = params.providedApiKey || process.env.GEMINI_API_KEY;

  const defaultWeekly: WeeklyPlanResponse = {
    planTitle: '7-DAY MONARCH PERIODIZATION CYCLE',
    weekObjective: 'Compound upper push-pull kinetic power, isometric core tension, and combat footwork agility.',
    days: [
      {
        dayNumber: 1,
        dayName: 'Monday',
        type: 'CALISTHENICS_PUSH',
        title: 'Anterior Kinetic & Sternal Leverage',
        estimatedMinutes: 35,
        keyFocus: '45° Arrowhead standard pushups & diamond triceps overload',
        exercises: [
          { name: 'Standard Push-ups (45° Arrowhead)', sets: 4, repsOrDuration: '12 reps', notes: 'Full scapular protraction lockout' },
          { name: 'Diamond Push-ups', sets: 3, repsOrDuration: '8-10 reps', notes: 'Sternum to diamond hand target' },
          { name: 'Pike Push-ups', sets: 3, repsOrDuration: '8 reps', notes: 'Vertical anterior deltoid drive' },
          { name: 'Rigid Iron Plank', sets: 3, repsOrDuration: '45s hold', notes: 'Posterior pelvic tilt' }
        ]
      },
      {
        dayNumber: 2,
        dayName: 'Tuesday',
        type: 'COMBAT_FITNESS',
        title: 'Kinetic Agility & Striking Condition',
        estimatedMinutes: 30,
        keyFocus: 'High-guard posture, pivot footwork, and shadowboxing burpee rounds',
        exercises: [
          { name: 'Stance & Guard Matrix Drill', sets: 3, repsOrDuration: '60s drill', notes: 'Chin tucked, cheekbone guard' },
          { name: 'Footwork In-and-Out Bounce', sets: 4, repsOrDuration: '45s cadence', notes: 'Rhythmic weight transfer on balls of feet' },
          { name: 'Shadowboxing Calisthenics (Jab-Cross-Burpee)', sets: 3, repsOrDuration: '3 min round', notes: 'Fight-pace explosive intervals' }
        ]
      },
      {
        dayNumber: 3,
        dayName: 'Wednesday',
        type: 'CALISTHENICS_PULL',
        title: 'Posterior Chain & Scapular Depression',
        estimatedMinutes: 35,
        keyFocus: 'Active dead hang, scapular pull-ups, horizontal rows',
        exercises: [
          { name: 'Active Dead Hang', sets: 3, repsOrDuration: '45s hold', notes: 'Depress scapulae, disengage traps' },
          { name: 'Inverted Bodyweight Rows', sets: 4, repsOrDuration: '10-12 reps', notes: 'Drive elbows past spine plane' },
          { name: 'Hollow Body Rockers', sets: 3, repsOrDuration: '20 reps', notes: 'Lower back glued to floor' }
        ]
      },
      {
        dayNumber: 4,
        dayName: 'Thursday',
        type: 'RECOVERY_MOBILITY',
        title: 'Joint Tendon & Fascial Restoration',
        estimatedMinutes: 25,
        keyFocus: 'Wrist flexor loading, thoracic spine rotation, deep hip openers',
        exercises: [
          { name: 'Wrist & Finger Tendon Waves', sets: 3, repsOrDuration: '60s flow', notes: 'Essential for planche and handstand durability' },
          { name: 'Thoracic Bridge Extensions', sets: 3, repsOrDuration: '10 reps', notes: 'Mobilize upper back extension' },
          { name: 'Deep Cossack Squats', sets: 3, repsOrDuration: '8 per side', notes: 'Adductor and ankle dorsiflexion' }
        ]
      },
      {
        dayNumber: 5,
        dayName: 'Friday',
        type: 'SKILL_MASTERY',
        title: 'Isometric Leverage & Skill Breakthrough',
        estimatedMinutes: 40,
        keyFocus: 'Wall handstand chest-to-wall, L-sit hold, pseudo planche leans',
        exercises: [
          { name: 'Chest-to-Wall Handstand', sets: 4, repsOrDuration: '30s hold', notes: 'Push tall through shoulders' },
          { name: 'Tucked / Full L-Sit', sets: 4, repsOrDuration: '15-20s hold', notes: 'Depress shoulders, lift hips' },
          { name: 'Pseudo Planche Push-ups', sets: 3, repsOrDuration: '6-8 reps', notes: 'Forward lean past wrist crease' }
        ]
      },
      {
        dayNumber: 6,
        dayName: 'Saturday',
        type: 'LEGS_CORE',
        title: 'Unilateral Lower Body & Core Power',
        estimatedMinutes: 35,
        keyFocus: 'Pistol squat progressions, explosive switch lunges, dragon flag preps',
        exercises: [
          { name: 'Assisted / Full Pistol Squats', sets: 4, repsOrDuration: '6-8 reps/leg', notes: 'Control eccentric descent' },
          { name: 'Jumping Kinetic Lunges', sets: 3, repsOrDuration: '16 reps', notes: 'Explosive vertical triple-extension' },
          { name: 'Hanging Knee/Leg Raises', sets: 3, repsOrDuration: '12 reps', notes: 'Anti-swing posterior control' }
        ]
      },
      {
        dayNumber: 7,
        dayName: 'Sunday',
        type: 'RECOVERY_MOBILITY',
        title: 'System Deload & Biomechanical Reset',
        estimatedMinutes: 20,
        keyFocus: 'Light walking, deep breathing, progressive muscle relaxation',
        exercises: [
          { name: 'Full-Body Joint Mobility Flow', sets: 1, repsOrDuration: '15 mins', notes: 'Circulation and connective tissue recovery' }
        ]
      }
    ]
  };

  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return defaultWeekly;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const prompt = `You are the MONARCH MASTER AI COACH.
Generate a structured, professional 7-Day Calisthenics Periodization Program for athlete ${params.profile.name}.

Athlete Profile:
- Rank: ${params.profile.currentRank} (Level ${params.profile.level})
- Goals: ${params.goals.join(', ')}
- Equipment: ${params.equipment.join(', ')}

Create a balanced 7-day program incorporating Calisthenics Push, Pull, Legs/Core, Combat Fitness, and Dedicated Recovery/Mobility.
Output strictly formatted JSON matching the WeeklyPlanResponse schema.`;

    const { text } = await resilientGenerateContent(ai, {
      contents: prompt,
      config: {
        systemInstruction: 'You are the Monarch Master AI Coach. Return strictly valid JSON.',
        responseMimeType: 'application/json'
      }
    });

    const parsed = JSON.parse(text);
    return {
      ...defaultWeekly,
      ...parsed
    };
  } catch (err) {
    console.warn('Weekly plan AI generation fallback:', err);
    return defaultWeekly;
  }
}
