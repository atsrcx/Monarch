import { create } from 'zustand';
import { soundEngine } from '../utils/soundEngine';
import { aiTts, TtsPersona } from '../utils/aiTtsEngine';
import confetti from 'canvas-confetti';
import {
  GeneratedQuestResponse,
  getFallbackQuest,
  ChatMessage,
  BiomechanicalSessionReport
} from '../server/geminiBackend';

export type HunterRank = 'E-Rank' | 'D-Rank' | 'C-Rank' | 'B-Rank' | 'A-Rank' | 'S-Rank' | 'Shadow Monarch';

export interface HunterProfile {
  name: string;
  age: number;
  weightKg: number;
  heightCm: number;
  hunterClass: string;
  level: number;
  currentRank: HunterRank;
  xp: number;
  maxXp: number;
  statPoints: number;
  str: number;
  agi: number;
  end: number;
  sen: number;
  gold: number;
  titles: string[];
  activeTitle: string;
  isAwakened: boolean;
}

export interface WorkoutLogEntry {
  id: string;
  date: string;
  timestamp: number;
  exerciseName: string;
  reps: number;
  targetReps: number;
  accuracyScore: number;
  calories: number;
  xpEarned: number;
}

export interface RepQualityEntry {
  repIndex: number;
  qualityScore: number;
  grade: 'PERFECT' | 'GOOD' | 'FLAW' | 'INVALID';
  depthAngle: number;
  alignmentAngle: number;
  flawNote?: string;
  timestamp: number;
}

export interface GameStoreState {
  // Hunter Profile
  profile: HunterProfile;
  
  // Daily Quest & Routines
  currentQuest: GeneratedQuestResponse;
  completedSetsMap: Record<string, number>; // exerciseId -> completed sets count
  isQuestCompleted: boolean;
  isPenaltyActive: boolean;
  penaltyTasksLeft: string[];
  
  // Streak & History
  streak: number;
  lastWorkoutDate: string | null;
  workoutHistory: WorkoutLogEntry[];
  sessionRepQualityLog: RepQualityEntry[];
  
  // Settings & System Connectivity
  geminiApiKey: string;
  geminiStatus: 'untested' | 'testing' | 'online' | 'error';
  geminiStatusMessage: string;
  specialization: string;
  audioVolume: number;
  isMuted: boolean;
  cameraFacingMode: 'user' | 'environment';
  showSkeleton: boolean;
  antiCheatEnabled: boolean;

  // Vision Lab & Analyst HUD Settings
  visionHudMode: 'coach' | 'analyst';
  showGhostTrainer: boolean;
  showMotionTrails: boolean;
  showJointArcs: boolean;
  showMovementVectors: boolean;
  showTargetZones: boolean;
  landmarkConfidenceThreshold: number;
  smoothingAlpha: number;
  performanceMode: boolean;

  // AI TTS & Voice Persona
  ttsEnabled: boolean;
  ttsPersona: TtsPersona;
  ttsRate: number;
  ttsAutoCues: boolean;

  // Video Workout Studio State
  selectedVideoExercise: string;
  videoSplitMode: boolean;
  videoPlaybackSpeed: number;

  // AI Architect Chat Terminal
  chatMessages: ChatMessage[];
  latestDebrief: BiomechanicalSessionReport | null;
  
  // Active Modals & UI States
  activeModal: 'none' | 'awakening' | 'settings' | 'levelup' | 'rest' | 'penalty' | 'summary' | 'debrief' | 'roadmap';
  levelUpData: { newLevel: number; rankUnlocked?: HunterRank; statPointsAwarded: number } | null;
  restTimerSecondsLeft: number;
  activeExerciseId: string | null;
  
  // Actions
  setProfile: (profile: Partial<HunterProfile>) => void;
  awakenHunter: (name: string, age: number, weightKg: number, heightCm: number, hunterClass: string) => void;
  allocateStat: (stat: 'str' | 'agi' | 'end' | 'sen') => void;
  addXP: (amount: number) => void;
  recordRep: (exerciseId: string, repQuality?: RepQualityEntry) => void;
  completeSet: (exerciseId: string, reps: number, accuracy?: number) => void;
  setDailyQuest: (quest: GeneratedQuestResponse) => void;
  startExercise: (exerciseId: string) => void;
  startRestTimer: (seconds: number) => void;
  decrementRestTimer: () => void;
  stopRestTimer: () => void;
  openModal: (modal: GameStoreState['activeModal']) => void;
  closeModal: () => void;
  setGeminiApiKey: (key: string) => void;
  setGeminiStatus: (status: GameStoreState['geminiStatus'], message: string) => void;
  setSpecialization: (spec: string) => void;
  toggleMute: () => void;
  setVolume: (vol: number) => void;
  setCameraFacingMode: (mode: 'user' | 'environment') => void;
  toggleSkeleton: () => void;
  toggleAntiCheat: () => void;
  triggerPenaltyQuest: () => void;
  resolvePenaltyQuest: () => void;
  resetAllProgress: () => void;

  // Vision Lab Actions
  setVisionHudMode: (mode: 'coach' | 'analyst') => void;
  toggleGhostTrainer: () => void;
  toggleMotionTrails: () => void;
  toggleJointArcs: () => void;
  toggleMovementVectors: () => void;
  toggleTargetZones: () => void;
  setLandmarkConfidenceThreshold: (threshold: number) => void;
  setSmoothingAlpha: (alpha: number) => void;
  togglePerformanceMode: () => void;
  addRepQualityLog: (entry: RepQualityEntry) => void;
  clearRepQualityLog: () => void;

  // AI TTS Actions
  toggleTts: () => void;
  setTtsPersona: (persona: TtsPersona) => void;
  setTtsRate: (rate: number) => void;
  toggleTtsAutoCues: () => void;

  // Video Workout Actions
  setSelectedVideoExercise: (id: string) => void;
  toggleVideoSplitMode: () => void;
  setVideoPlaybackSpeed: (speed: number) => void;

  // AI Chat & Debrief Actions
  addChatMessage: (msg: ChatMessage) => void;
  clearChat: () => void;
  setLatestDebrief: (report: BiomechanicalSessionReport | null) => void;
}

const DEFAULT_PROFILE: HunterProfile = {
  name: 'Sung Jin-Woo',
  age: 24,
  weightKg: 74,
  heightCm: 180,
  hunterClass: 'Shadow Monarch (Calisthenics Specialist)',
  level: 1,
  currentRank: 'E-Rank',
  xp: 0,
  maxXp: 100,
  statPoints: 5,
  str: 10,
  agi: 10,
  end: 10,
  sen: 10,
  gold: 1000,
  titles: ['The Awakened Vessel', 'Iron Push Hunter'],
  activeTitle: 'The Awakened Vessel',
  isAwakened: false,
};

function calculateRank(level: number): HunterRank {
  if (level >= 100) return 'Shadow Monarch';
  if (level >= 86) return 'S-Rank';
  if (level >= 66) return 'A-Rank';
  if (level >= 46) return 'B-Rank';
  if (level >= 26) return 'C-Rank';
  if (level >= 11) return 'D-Rank';
  return 'E-Rank';
}

function calculateMaxXP(level: number): number {
  return Math.round(100 * Math.pow(1.18, level - 1));
}

// Load saved state from LocalStorage
const STORAGE_KEY = 'monarch_calisthenics_save_v1';
const initialSaved = (() => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load local storage save:', e);
  }
  return null;
})();

const defaultInitialProfile: HunterProfile = initialSaved?.profile || DEFAULT_PROFILE;
const defaultInitialQuest = initialSaved?.currentQuest || getFallbackQuest(defaultInitialProfile);

export const useGameStore = create<GameStoreState>((set, get) => ({
  profile: defaultInitialProfile,
  currentQuest: defaultInitialQuest,
  completedSetsMap: initialSaved?.completedSetsMap || {},
  isQuestCompleted: initialSaved?.isQuestCompleted || false,
  isPenaltyActive: initialSaved?.isPenaltyActive || false,
  penaltyTasksLeft: initialSaved?.penaltyTasksLeft || ['100 Deep Push-ups', '100 Bodyweight Squats', '180s Static Iron Plank'],
  streak: initialSaved?.streak || 1,
  lastWorkoutDate: initialSaved?.lastWorkoutDate || null,
  workoutHistory: initialSaved?.workoutHistory || [],
  sessionRepQualityLog: initialSaved?.sessionRepQualityLog || [],
  geminiApiKey: initialSaved?.geminiApiKey || '',
  geminiStatus: initialSaved?.geminiApiKey ? 'online' : 'untested',
  geminiStatusMessage: initialSaved?.geminiApiKey ? 'System Link Cached' : 'API Key not verified yet',
  specialization: initialSaved?.specialization || 'Push & Chest Hypertrophy',
  audioVolume: initialSaved?.audioVolume ?? 0.8,
  isMuted: initialSaved?.isMuted ?? false,
  cameraFacingMode: initialSaved?.cameraFacingMode || 'user',
  showSkeleton: initialSaved?.showSkeleton ?? true,
  antiCheatEnabled: initialSaved?.antiCheatEnabled ?? true,
  visionHudMode: initialSaved?.visionHudMode || 'coach',
  showGhostTrainer: initialSaved?.showGhostTrainer ?? true,
  showMotionTrails: initialSaved?.showMotionTrails ?? true,
  showJointArcs: initialSaved?.showJointArcs ?? true,
  showMovementVectors: initialSaved?.showMovementVectors ?? true,
  showTargetZones: initialSaved?.showTargetZones ?? true,
  landmarkConfidenceThreshold: initialSaved?.landmarkConfidenceThreshold ?? 0.55,
  smoothingAlpha: initialSaved?.smoothingAlpha ?? 0.70,
  performanceMode: initialSaved?.performanceMode ?? false,
  ttsEnabled: initialSaved?.ttsEnabled ?? true,
  ttsPersona: initialSaved?.ttsPersona || 'monarch',
  ttsRate: initialSaved?.ttsRate ?? 1.05,
  ttsAutoCues: initialSaved?.ttsAutoCues ?? true,
  selectedVideoExercise: initialSaved?.selectedVideoExercise || 'pushup-standard',
  videoSplitMode: initialSaved?.videoSplitMode ?? false,
  videoPlaybackSpeed: initialSaved?.videoPlaybackSpeed ?? 1.0,
  chatMessages: initialSaved?.chatMessages || [
    {
      role: 'system',
      content: 'System link established. I am the System Grand Architect. Inquire regarding calisthenics progressions, biomechanical form adjustments, or training protocols.',
      timestamp: Date.now()
    }
  ],
  latestDebrief: null,
  activeModal: defaultInitialProfile.isAwakened ? 'none' : 'awakening',
  levelUpData: null,
  restTimerSecondsLeft: 0,
  activeExerciseId: null,

  setProfile: (partial) => {
    set((state) => {
      const updated = { ...state.profile, ...partial };
      persistToStorage({ ...state, profile: updated });
      return { profile: updated };
    });
  },

  awakenHunter: (name, age, weightKg, heightCm, hunterClass) => {
    set((state) => {
      const updatedProfile: HunterProfile = {
        ...state.profile,
        name: name.trim() || 'Monarch Hunter',
        age: Number(age) || 24,
        weightKg: Number(weightKg) || 75,
        heightCm: Number(heightCm) || 178,
        hunterClass,
        isAwakened: true,
      };
      soundEngine.playLevelUp();
      confetti({
        particleCount: 80,
        spread: 90,
        origin: { y: 0.6 },
        colors: ['#00f0ff', '#8b5cf6', '#ffffff']
      });
      persistToStorage({ ...state, profile: updatedProfile });
      return { profile: updatedProfile, activeModal: 'none' };
    });
  },

  allocateStat: (stat) => {
    const { profile } = get();
    if (profile.statPoints <= 0) return;

    soundEngine.playClick();
    const updatedProfile: HunterProfile = {
      ...profile,
      statPoints: profile.statPoints - 1,
      [stat]: profile[stat] + 1,
    };

    set((state) => {
      persistToStorage({ ...state, profile: updatedProfile });
      return { profile: updatedProfile };
    });
  },

  addXP: (amount) => {
    set((state) => {
      let { level, xp, maxXp, currentRank, statPoints, gold } = state.profile;
      let newXp = xp + amount;
      let newLevel = level;
      let newRank = currentRank;
      let pointsAwarded = 0;
      let hasLeveledUp = false;

      while (newXp >= maxXp) {
        newXp -= maxXp;
        newLevel += 1;
        newRank = calculateRank(newLevel);
        maxXp = calculateMaxXP(newLevel);
        pointsAwarded += 3;
        gold += 500;
        hasLeveledUp = true;
      }

      const updatedProfile: HunterProfile = {
        ...state.profile,
        level: newLevel,
        currentRank: newRank,
        xp: newXp,
        maxXp,
        statPoints: statPoints + pointsAwarded,
        gold,
      };

      if (hasLeveledUp) {
        soundEngine.playLevelUp();
        confetti({
          particleCount: 120,
          spread: 100,
          origin: { y: 0.5 },
          colors: ['#00f0ff', '#8b5cf6', '#ffd700', '#ffffff']
        });
      }

      persistToStorage({ ...state, profile: updatedProfile });
      return {
        profile: updatedProfile,
        activeModal: hasLeveledUp ? 'levelup' : state.activeModal,
        levelUpData: hasLeveledUp
          ? {
              newLevel,
              rankUnlocked: newRank !== currentRank ? newRank : undefined,
              statPointsAwarded: pointsAwarded,
            }
          : state.levelUpData,
      };
    });
  },

  recordRep: (exerciseId, repQuality) => {
    const ex = get().currentQuest.exercises.find((e) => e.id === exerciseId);
    const xpPerRep = ex?.xpPerRep || 10;
    get().addXP(xpPerRep);
    if (repQuality) {
      get().addRepQualityLog(repQuality);
    }
  },

  completeSet: (exerciseId, reps, accuracy = 95) => {
    const state = get();
    const ex = state.currentQuest.exercises.find((e) => e.id === exerciseId);
    if (!ex) return;

    const currentSets = state.completedSetsMap[exerciseId] || 0;
    const nextSets = currentSets + 1;
    const updatedSetsMap = { ...state.completedSetsMap, [exerciseId]: nextSets };

    // Calculate calories: bodyweight * 0.05 * reps * MET factor
    const calories = Math.round((state.profile.weightKg * 0.045 * reps));
    const xpEarned = reps * ex.xpPerRep + 25; // Set bonus

    const newLog: WorkoutLogEntry = {
      id: `log-${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      timestamp: Date.now(),
      exerciseName: ex.name,
      reps,
      targetReps: ex.repsPerSet,
      accuracyScore: accuracy,
      calories,
      xpEarned,
    };

    const updatedHistory = [newLog, ...state.workoutHistory.slice(0, 49)];

    // Check if entire quest is complete
    const allDone = state.currentQuest.exercises.every(
      (item) => (updatedSetsMap[item.id] || 0) >= item.sets
    );

    let streak = state.streak;
    const today = new Date().toISOString().slice(0, 10);
    if (allDone && !state.isQuestCompleted) {
      if (state.lastWorkoutDate !== today) {
        streak += 1;
      }
      soundEngine.playLevelUp();
      confetti({
        particleCount: 150,
        spread: 120,
        origin: { y: 0.4 },
        colors: ['#00f0ff', '#ffd700', '#8b5cf6']
      });
    }

    set({
      completedSetsMap: updatedSetsMap,
      workoutHistory: updatedHistory,
      isQuestCompleted: allDone || state.isQuestCompleted,
      streak,
      lastWorkoutDate: today,
      activeModal: allDone ? 'summary' : state.activeModal,
    });

    state.addXP(xpEarned);
    persistToStorage(get());
  },

  setDailyQuest: (quest) => {
    set((state) => {
      persistToStorage({ ...state, currentQuest: quest, completedSetsMap: {}, isQuestCompleted: false });
      return { currentQuest: quest, completedSetsMap: {}, isQuestCompleted: false };
    });
  },

  startExercise: (exerciseId) => {
    set({ activeExerciseId: exerciseId });
  },

  startRestTimer: (seconds) => {
    set({ restTimerSecondsLeft: seconds, activeModal: 'rest' });
  },

  decrementRestTimer: () => {
    const { restTimerSecondsLeft } = get();
    if (restTimerSecondsLeft <= 1) {
      soundEngine.playRestComplete();
      set({ restTimerSecondsLeft: 0, activeModal: 'none' });
    } else {
      soundEngine.playRestTick();
      set({ restTimerSecondsLeft: restTimerSecondsLeft - 1 });
    }
  },

  stopRestTimer: () => {
    set({ restTimerSecondsLeft: 0, activeModal: 'none' });
  },

  openModal: (modal) => {
    soundEngine.playSystemOpen();
    set({ activeModal: modal });
  },

  closeModal: () => {
    set({ activeModal: 'none' });
  },

  setGeminiApiKey: (key) => {
    set((state) => {
      persistToStorage({ ...state, geminiApiKey: key });
      return { geminiApiKey: key };
    });
  },

  setGeminiStatus: (status, message) => {
    set({ geminiStatus: status, geminiStatusMessage: message });
  },

  setSpecialization: (spec) => {
    set((state) => {
      persistToStorage({ ...state, specialization: spec });
      return { specialization: spec };
    });
  },

  toggleMute: () => {
    const newMute = !get().isMuted;
    soundEngine.setMuted(newMute);
    set((state) => {
      persistToStorage({ ...state, isMuted: newMute });
      return { isMuted: newMute };
    });
  },

  setVolume: (vol) => {
    soundEngine.setVolume(vol);
    set((state) => {
      persistToStorage({ ...state, audioVolume: vol });
      return { audioVolume: vol };
    });
  },

  setCameraFacingMode: (mode) => {
    set((state) => {
      persistToStorage({ ...state, cameraFacingMode: mode });
      return { cameraFacingMode: mode };
    });
  },

  toggleSkeleton: () => {
    set((state) => {
      const showSkeleton = !state.showSkeleton;
      persistToStorage({ ...state, showSkeleton });
      return { showSkeleton };
    });
  },

  toggleAntiCheat: () => {
    set((state) => {
      const antiCheatEnabled = !state.antiCheatEnabled;
      persistToStorage({ ...state, antiCheatEnabled });
      return { antiCheatEnabled };
    });
  },

  triggerPenaltyQuest: () => {
    soundEngine.playPenaltyAlert();
    set((state) => {
      persistToStorage({ ...state, isPenaltyActive: true });
      return { isPenaltyActive: true, activeModal: 'penalty' };
    });
  },

  resolvePenaltyQuest: () => {
    soundEngine.playLevelUp();
    aiTts.speak('Penalty protocol cleared. System restored.', true);
    set((state) => {
      persistToStorage({ ...state, isPenaltyActive: false });
      return { isPenaltyActive: false, activeModal: 'none' };
    });
  },

  resetAllProgress: () => {
    localStorage.removeItem(STORAGE_KEY);
    set({
      profile: DEFAULT_PROFILE,
      currentQuest: getFallbackQuest(DEFAULT_PROFILE),
      completedSetsMap: {},
      isQuestCompleted: false,
      isPenaltyActive: false,
      streak: 1,
      lastWorkoutDate: null,
      workoutHistory: [],
      sessionRepQualityLog: [],
      activeModal: 'awakening',
      chatMessages: [
        {
          role: 'system',
          content: 'System memory reset. All stats recalibrated to base rank. Begin your awakening.',
          timestamp: Date.now()
        }
      ],
      latestDebrief: null
    });
  },

  // Vision Lab Actions
  setVisionHudMode: (mode) => {
    set((state) => {
      persistToStorage({ ...state, visionHudMode: mode });
      return { visionHudMode: mode };
    });
  },

  toggleGhostTrainer: () => {
    set((state) => {
      const showGhostTrainer = !state.showGhostTrainer;
      persistToStorage({ ...state, showGhostTrainer });
      return { showGhostTrainer };
    });
  },

  toggleMotionTrails: () => {
    set((state) => {
      const showMotionTrails = !state.showMotionTrails;
      persistToStorage({ ...state, showMotionTrails });
      return { showMotionTrails };
    });
  },

  toggleJointArcs: () => {
    set((state) => {
      const showJointArcs = !state.showJointArcs;
      persistToStorage({ ...state, showJointArcs });
      return { showJointArcs };
    });
  },

  toggleMovementVectors: () => {
    set((state) => {
      const showMovementVectors = !state.showMovementVectors;
      persistToStorage({ ...state, showMovementVectors });
      return { showMovementVectors };
    });
  },

  toggleTargetZones: () => {
    set((state) => {
      const showTargetZones = !state.showTargetZones;
      persistToStorage({ ...state, showTargetZones });
      return { showTargetZones };
    });
  },

  setLandmarkConfidenceThreshold: (threshold) => {
    set((state) => {
      persistToStorage({ ...state, landmarkConfidenceThreshold: threshold });
      return { landmarkConfidenceThreshold: threshold };
    });
  },

  setSmoothingAlpha: (alpha) => {
    set((state) => {
      persistToStorage({ ...state, smoothingAlpha: alpha });
      return { smoothingAlpha: alpha };
    });
  },

  togglePerformanceMode: () => {
    set((state) => {
      const performanceMode = !state.performanceMode;
      persistToStorage({ ...state, performanceMode });
      return { performanceMode };
    });
  },

  addRepQualityLog: (entry) => {
    set((state) => {
      const updated = [entry, ...state.sessionRepQualityLog.slice(0, 49)];
      persistToStorage({ ...state, sessionRepQualityLog: updated });
      return { sessionRepQualityLog: updated };
    });
  },

  clearRepQualityLog: () => {
    set((state) => {
      persistToStorage({ ...state, sessionRepQualityLog: [] });
      return { sessionRepQualityLog: [] };
    });
  },

  // AI TTS Actions
  toggleTts: () => {
    set((state) => {
      const enabled = !state.ttsEnabled;
      aiTts.updateSettings({ enabled });
      persistToStorage({ ...state, ttsEnabled: enabled });
      return { ttsEnabled: enabled };
    });
  },

  setTtsPersona: (persona) => {
    aiTts.updateSettings({ persona });
    set((state) => {
      persistToStorage({ ...state, ttsPersona: persona });
      return { ttsPersona: persona };
    });
  },

  setTtsRate: (rate) => {
    aiTts.updateSettings({ rate });
    set((state) => {
      persistToStorage({ ...state, ttsRate: rate });
      return { ttsRate: rate };
    });
  },

  toggleTtsAutoCues: () => {
    set((state) => {
      const autoCues = !state.ttsAutoCues;
      aiTts.updateSettings({ autoFormCues: autoCues });
      persistToStorage({ ...state, ttsAutoCues: autoCues });
      return { ttsAutoCues: autoCues };
    });
  },

  // Video Workout Studio Actions
  setSelectedVideoExercise: (id) => {
    set((state) => {
      persistToStorage({ ...state, selectedVideoExercise: id });
      return { selectedVideoExercise: id };
    });
  },

  toggleVideoSplitMode: () => {
    set((state) => {
      const videoSplitMode = !state.videoSplitMode;
      persistToStorage({ ...state, videoSplitMode });
      return { videoSplitMode };
    });
  },

  setVideoPlaybackSpeed: (speed) => {
    set((state) => {
      persistToStorage({ ...state, videoPlaybackSpeed: speed });
      return { videoPlaybackSpeed: speed };
    });
  },

  // AI Chat & Debrief Actions
  addChatMessage: (msg) => {
    set((state) => {
      const updated = [...state.chatMessages, msg];
      persistToStorage({ ...state, chatMessages: updated });
      return { chatMessages: updated };
    });
  },

  clearChat: () => {
    set((state) => {
      const initial = [
        {
          role: 'system' as const,
          content: 'Terminal buffer cleared. System Grand Architect standing by.',
          timestamp: Date.now()
        }
      ];
      persistToStorage({ ...state, chatMessages: initial });
      return { chatMessages: initial };
    });
  },

  setLatestDebrief: (report) => {
    set({ latestDebrief: report });
  }
}));

function persistToStorage(state: GameStoreState) {
  try {
    const payload = {
      profile: state.profile,
      currentQuest: state.currentQuest,
      completedSetsMap: state.completedSetsMap,
      isQuestCompleted: state.isQuestCompleted,
      isPenaltyActive: state.isPenaltyActive,
      penaltyTasksLeft: state.penaltyTasksLeft,
      streak: state.streak,
      lastWorkoutDate: state.lastWorkoutDate,
      workoutHistory: state.workoutHistory,
      sessionRepQualityLog: state.sessionRepQualityLog,
      geminiApiKey: state.geminiApiKey,
      specialization: state.specialization,
      audioVolume: state.audioVolume,
      isMuted: state.isMuted,
      cameraFacingMode: state.cameraFacingMode,
      showSkeleton: state.showSkeleton,
      antiCheatEnabled: state.antiCheatEnabled,
      visionHudMode: state.visionHudMode,
      showGhostTrainer: state.showGhostTrainer,
      showMotionTrails: state.showMotionTrails,
      showJointArcs: state.showJointArcs,
      showMovementVectors: state.showMovementVectors,
      showTargetZones: state.showTargetZones,
      landmarkConfidenceThreshold: state.landmarkConfidenceThreshold,
      smoothingAlpha: state.smoothingAlpha,
      performanceMode: state.performanceMode,
      ttsEnabled: state.ttsEnabled,
      ttsPersona: state.ttsPersona,
      ttsRate: state.ttsRate,
      ttsAutoCues: state.ttsAutoCues,
      selectedVideoExercise: state.selectedVideoExercise,
      videoSplitMode: state.videoSplitMode,
      videoPlaybackSpeed: state.videoPlaybackSpeed,
      chatMessages: state.chatMessages
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch (e) {
    console.error('Failed to save to local storage:', e);
  }
}
