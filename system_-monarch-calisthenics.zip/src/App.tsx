import React, { useState, useEffect } from 'react';
import {
  Flame,
  Volume2,
  VolumeX,
  Settings,
  Zap,
  Bot,
  Play,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Shield,
  Layers,
  Award,
  Maximize2,
  ChevronRight,
  TrendingUp,
  Target
} from 'lucide-react';
import { useGameStore } from './store/useGameStore';
import { soundEngine } from './utils/soundEngine';
import { aiTts } from './utils/aiTtsEngine';
import { requestAdaptiveDailyQuest } from './services/geminiService';
import { indexedDbService } from './utils/indexedDbService';
import { MonarchDashboard } from './components/MonarchDashboard';
import { CalisthenicsMasterTree } from './components/CalisthenicsMasterTree';
import { CombatConditioningHub } from './components/CombatConditioningHub';
import { VisionTracker } from './components/VisionTracker';
import { GamificationEngine } from './components/GamificationEngine';
import { SystemArchitectTerminal } from './components/SystemArchitectTerminal';
import { NavigationBar, TabType } from './components/NavigationBar';
import { SettingsModal } from './components/SettingsModal';
import { AwakeningModal } from './components/AwakeningModal';
import { LevelUpModal } from './components/LevelUpModal';
import { PenaltyModal } from './components/PenaltyModal';
import { RestTimerModal } from './components/RestTimerModal';
import { QuestSummaryModal } from './components/QuestSummaryModal';
import { BiomechanicalDebriefModal } from './components/BiomechanicalDebriefModal';
import { ZeroToHeroRoadmapModal } from './components/ZeroToHeroRoadmapModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';

export default function App() {
  const {
    profile,
    currentQuest,
    completedSetsMap,
    isQuestCompleted,
    isPenaltyActive,
    streak,
    isMuted,
    ttsEnabled,
    geminiApiKey,
    geminiStatus,
    activeModal,
    workoutHistory,
    toggleMute,
    toggleTts,
    openModal,
    closeModal,
    startExercise,
    setDailyQuest
  } = useGameStore();

  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [activeExerciseId, setActiveExerciseId] = useState<string>('push-standard');

  // Play startup sound and initialize on mount
  useEffect(() => {
    const handleFirstClick = () => {
      soundEngine.playSystemOpen();
      aiTts.speak('Monarch System online. Biomechanical sentry active.', false);
      window.removeEventListener('click', handleFirstClick);
    };
    window.addEventListener('click', handleFirstClick, { once: true });

    return () => window.removeEventListener('click', handleFirstClick);
  }, []);

  const primaryExercise = currentQuest.exercises[0] || {
    id: 'push-standard',
    name: 'Standard Push-ups (45° Arrowhead)',
    sets: 3,
    repsPerSet: 10,
    xpPerRep: 10,
  };

  const handleInitiateQuest = (overrideId?: string) => {
    const targetId = overrideId || primaryExercise.id;
    setActiveExerciseId(targetId);
    soundEngine.playQuestStart();
    startExercise(targetId);
    setIsCameraActive(true);
    aiTts.speak('Initiating calisthenics vision protocol. Position full body in frame.');
  };

  const handleCloseCamera = () => {
    soundEngine.playClick();
    setIsCameraActive(false);

    const totalTargetReps = currentQuest.totalTargetReps || (primaryExercise.sets * primaryExercise.repsPerSet);
    const setsDone = completedSetsMap[primaryExercise.id] || 0;
    const completedReps = Math.min(totalTargetReps, setsDone * primaryExercise.repsPerSet);
    const completionPercentage = Math.min(100, Math.round((completedReps / Math.max(1, totalTargetReps)) * 100));

    const today = new Date().toISOString().slice(0, 10);
    indexedDbService.saveDailyRecord({
      date: today,
      targetReps: totalTargetReps,
      completedReps,
      completionPercentage,
      isPassed: completionPercentage >= 100,
      questTitle: currentQuest.questTitle
    });
  };

  return (
    <div className="min-h-screen bg-black text-white font-mono antialiased flex flex-col justify-between relative overflow-x-hidden selection:bg-white selection:text-black">
      {/* Top Action Bar */}
      <header className="w-full max-w-4xl mx-auto px-4 sm:px-6 pt-5 pb-2 flex items-center justify-between z-30">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-neutral-900 border border-neutral-700 flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <span className="text-xs font-black font-['Orbitron'] tracking-widest text-white uppercase">
            MONARCH V3
          </span>
        </div>

        {/* Minimal Controls */}
        <div className="flex items-center gap-2">
          {/* Streak Counter */}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-neutral-900 border border-neutral-800 text-white font-mono text-xs font-bold">
            <Flame className="w-3.5 h-3.5 text-white" />
            <span>{streak}D STREAK</span>
          </div>

          {/* Voice Coach Toggle */}
          <button
            onClick={toggleTts}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              ttsEnabled
                ? 'bg-white text-black border-white'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500'
            }`}
            title={ttsEnabled ? 'AI Voice Coach Active' : 'AI Voice Coach Muted'}
          >
            <Bot className="w-4 h-4" />
          </button>

          {/* Sound FX Toggle */}
          <button
            onClick={toggleMute}
            className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white transition-all cursor-pointer"
            title={isMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-neutral-600" /> : <Volume2 className="w-4 h-4 text-white" />}
          </button>

          {/* Settings */}
          <button
            onClick={() => {
              soundEngine.playClick();
              openModal('settings');
            }}
            className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white transition-all cursor-pointer relative"
            title="System Settings"
          >
            <Settings className="w-4 h-4" />
            <span
              className={`absolute top-1 right-1 w-2 h-2 rounded-full ${
                geminiStatus === 'online' ? 'bg-white shadow-[0_0_6px_#ffffff]' : 'bg-neutral-600'
              }`}
            />
          </button>
        </div>
      </header>

      {/* Main Tab Content */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-4 z-10">
        {activeTab === 'dashboard' && (
          <MonarchDashboard
            onInitiateWorkout={() => handleInitiateQuest()}
            onNavigateToTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'skills' && (
          <CalisthenicsMasterTree
            onStartExercise={(exerciseId) => handleInitiateQuest(exerciseId)}
          />
        )}

        {activeTab === 'camera' && (
          <div className="space-y-4 pb-24">
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold font-['Orbitron'] text-white">LIVE VISION AI WORKOUT</h2>
                <p className="text-xs text-neutral-400">MediaPipe BlazePose 33-Keypoint Biomechanical Tracking</p>
              </div>
              <button
                onClick={() => setIsCameraActive(true)}
                className="px-4 py-2 rounded-xl bg-white text-black font-bold font-mono text-xs uppercase hover:bg-neutral-200 cursor-pointer"
              >
                OPEN FULLSCREEN
              </button>
            </div>
            <div className="w-full aspect-video rounded-3xl overflow-hidden border border-neutral-800 bg-neutral-950">
              <VisionTracker
                overrideExerciseId={activeExerciseId}
                onClose={() => setActiveTab('dashboard')}
              />
            </div>
          </div>
        )}

        {activeTab === 'combat' && (
          <CombatConditioningHub
            onStartCameraWorkout={(exerciseId) => handleInitiateQuest(exerciseId)}
          />
        )}

        {activeTab === 'chat' && (
          <div className="pb-24">
            <SystemArchitectTerminal />
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="pb-24">
            <GamificationEngine />
          </div>
        )}
      </main>

      {/* Fullscreen Camera Modal Overlay */}
      {isCameraActive && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col animate-in fade-in duration-200">
          <VisionTracker
            overrideExerciseId={activeExerciseId}
            onClose={handleCloseCamera}
          />
        </div>
      )}

      {/* Navigation Bar */}
      <NavigationBar
        activeTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
      />

      {/* PWA Install Banner */}
      <PWAInstallBanner />

      {/* System Modals */}
      {activeModal === 'awakening' && <AwakeningModal />}
      {activeModal === 'settings' && <SettingsModal />}
      {activeModal === 'levelup' && <LevelUpModal />}
      {activeModal === 'penalty' && <PenaltyModal />}
      {activeModal === 'rest' && <RestTimerModal />}
      {activeModal === 'summary' && <QuestSummaryModal />}
      {activeModal === 'debrief' && <BiomechanicalDebriefModal onClose={closeModal} />}
      {activeModal === 'roadmap' && (
        <ZeroToHeroRoadmapModal
          isOpen={true}
          onClose={closeModal}
          onSelectExerciseToPractice={(ex) => {
            closeModal();
            handleInitiateQuest();
          }}
        />
      )}
    </div>
  );
}
