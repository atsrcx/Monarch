# ==============================================================================
# SYSTEM: MONARCH CALISTHENICS — FULL SYSTEM UPGRADE SPECIFICATION V2.0
# CINEMATIC AI CALISTHENICS COACH — VISION + BIOMECHANICS + ADAPTIVE AI
# ==============================================================================

## 1. Executive System Overview
Monarch Calisthenics is a production-grade, AI-driven, computer-vision calisthenics coaching ecosystem combining sub-pixel landmark tracking, real-time 3D holographic wireframe overlays, Ghost Trainer biomechanical alignment matching, intelligent dual-language voice coaching, and server-side Google Gemini 2.5 AI orchestration.

---

## 2. Comprehensive Architecture Map
```
                      ┌──────────────────────────────────────────────┐
                      │            GOOGLE GEMINI 2.5 / PRO           │
                      │     (Server-Side API Proxy /api/gemini/*)    │
                      └──────────────────────┬───────────────────────┘
                                             │
                        Adaptive Quests, Debriefs, Flaw Fixes, AI Chat
                                             │
                                             ▼
                      ┌──────────────────────────────────────────────┐
                      │              STATE & LOGS STORE              │
                      │     (Zustand + Local IndexedDB Storage)      │
                      └──────────────────────┬───────────────────────┘
                                             │
                              Structured Exercise Definitions
                                             │
                                             ▼
                      ┌──────────────────────────────────────────────┐
                      │             LOCAL VISION ENGINE              │
                      │       (MediaPipe 60 FPS Pose Tracking)       │
                      └──────┬────────────────────────────────┬──────┘
                             │                                │
                 2nd-Order EMA Smoothing           3D Vector Dot-Product
                    (α = 0.70 Filter)               Joint Angle Math
                             │                                │
                             └───────────────┬────────────────┘
                                             ▼
                      ┌──────────────────────────────────────────────┐
                      │         4-PHASE REP DETECTOR & SENTRY        │
                      │    (Locked ➔ Descend ➔ Peak Depth ➔ Locked)  │
                      └──────────────┬────────────────┬──────────────┘
                                     │                │
            Electric Cyan / Red Bone Overlay    Debounced Speech
                                     ▼                ▼
                      ┌──────────────────────┐ ┌─────────────────────┐
                      │  3D SKELETAL CANVAS  │ │ SPOKEN VOICE COACH  │
                      │  + GHOST TRAINER (◇) │ │  (English & Hindi)  │
                      └──────────────────────┘ └─────────────────────┘
```

---

## 3. Vision Quality Gate & Landmark Confidence
1. **Vision Quality Gate**:
   - Verification of key landmark visibility before rep counting is initiated ($\text{vis} \ge 0.65$).
   - If user is too close, too far, or missing critical limbs, system displays framing cues: `MOVE CAMERA BACK`, `SHOW YOUR FEET`, `TURN SIDEWAYS`.
2. **Stale Landmark Protection**:
   - Timestamps tracked per landmark; if visibility drops or updates stall $>250\text{ms}$, landmarks fade to prevent ghost skeletal drift.
3. **Ghost Trainer Overlay**:
   - Superimposes ideal biomechanical motion path in subtle holographic cyan ($20\%$ opacity) adapting to current movement phase.
   - Calculates real-time Ghost Match alignment score ($0-100\%$).

---

## 4. Biomechanical Engine & Mathematical Equations
1. **Vector 3D Dot-Product Angle**:
   $$\theta = \arccos\left(\frac{(A - B) \cdot (C - B)}{\|A - B\| \cdot \|C - B\|}\right) \times \frac{180^\circ}{\pi}$$
2. **Push-up Depth & Lockout**:
   - Lockout Apex: $\theta_{\text{elbow}} \ge 160^\circ$
   - Bottom Depth: $\theta_{\text{elbow}} \le 85^\circ$ held for $\ge 80\text{ms}$ with zero bounce.
3. **45° Arrowhead Elbow Flare**:
   - Ratio: $\frac{\text{Distance}(\text{Elbow}, \text{Torso})}{\text{Distance}(\text{Shoulder}, \text{Hip})}$
   - Valid Range: $30^\circ - 55^\circ$; Flawed: $>75^\circ$ (T-flare danger zone flagged in crimson).
4. **Spine Alignment Axis**:
   - Shoulder $\rightarrow$ Hip $\rightarrow$ Ankle collinearity ($\theta_{\text{spine}} \ge 160^\circ$).
5. **Specialized Diamond Push-up Target (◇)**:
   - Hand-to-shoulder width ratio: $0.15\times - 0.55\times$ with dynamic chest-anchored target zone.

---

## 5. 4-Phase Deterministic Repetition State Machine
- **Phase 0 (`LOCKED_UP`)**: Top lockout ($\theta > 160^\circ$).
- **Phase 1 (`DESCENDING`)**: Controlled eccentric phase.
- **Phase 2 (`CHEST_DEPTH_REACHED`)**: Valid depth reached ($\theta \le 85^\circ$, held $\ge 80\text{ms}$).
- **Phase 3 (`ASCENDING`)**: Concentric upward drive.
- **Phase 4 (`REP_VALIDATED`)**: Full lockout returned $\rightarrow$ rep incremented, XP awarded, spoken callout triggered.

---

## 6. Spoken AI Voice Coach & Anti-Spam
- Synthesized speech cues in English and Hindi.
- **Anti-Spam Filter**: 3.5s minimum interval between non-urgent speech triggers.
- **500ms Error Persistence**: Posture flaw must persist $\ge 500\text{ms}$ before triggering voice corrections.

---

## 7. Full-Stack Gemini AI Architecture
- Express `/api/gemini/*` proxy routes protecting API keys.
- **Adaptive Daily Quests**: Evaluates 3-day trailing completion rates and prior form flaws.
- **Biomechanical Debriefs**: Generates S/A/B/C/F grades, kinetic symmetry metrics, and attribute recommendations.
- **System Architect Terminal**: Conversational kinesiology assistant.
- **Form Flaw Remediation**: Pinpointed micro-routines targeting specific detected posture errors.

---

## 8. Offline & Performance Guarantee
- 100% offline capability for local camera tracking, skeleton rendering, and rep counting.
- Persistent local storage using IndexedDB.
