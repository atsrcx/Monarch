# SYSTEM: MONARCH CALISTHENICS — ARCHITECTURE & BIOMECHANICAL SYSTEM PROMPT

## Overview
Monarch Calisthenics is a production-grade, AI-driven, computer vision calisthenics coaching ecosystem combining sub-pixel landmark tracking, real-time 3D holographic wireframe overlays, intelligent dual-language voice coaching, and server-side Google Gemini 2.5 AI orchestration.

---

## 1. Biomechanical Vision Pipeline
- **Tracking Algorithm**: 33-point MediaPipe Pose with 2nd-order Exponential Moving Average (EMA) smoothing ($\alpha = 0.70$).
- **Joint Angle Calculation**: Vector 3D Dot Product with real-time HUD arc overlays and degree badges attached directly to active joints.
- **Form Validation**:
  - Push-ups: Lockout at $\theta \ge 160^\circ$, Chest Depth at $\theta \le 85^\circ$ held for $\ge 80\text{ms}$.
  - Arrowhead 45° Trajectory: Elbow-to-torso ratio validation ($30^\circ - 55^\circ$ nominal, $>75^\circ$ flared).
  - Spine Alignment: Shoulder-Hip-Ankle collinearity checking ($\theta \ge 160^\circ$).
  - Diamond Target Zone ($\diamond$): Dynamically rendered on user's chest with inward elbow correction vectors.
- **Finite State Machine**: 4-phase state cycle guaranteeing zero ghost or partial reps.

---

## 2. Voice Coaching & Anti-Spam Architecture
- **Speech Engine**: Web SpeechSynthesis with customized pitch/rate modifiers matching Monarch/Architect persona.
- **Debouncing**: 3.5-second anti-spam delay between non-critical speech utterances.
- **Error Persistence**: Flaw must remain active for $\ge 500\text{ms}$ before triggering audio corrections.
- **Bilingual Cues**: Full English and Hindi spoken guidance for all major flaws.

---

## 3. Server-Side AI Layer (Gemini 2.5 Flash / Pro)
- Express `/api/*` proxy architecture ensuring complete API key isolation.
- **Adaptive Daily Quests**: Calculates optimal sets and reps from 3-day trailing completion rates and past biomechanical flaws.
- **Post-Workout Debrief**: Generates S/A/B/C/F grades, kinetic symmetry analysis, and attribute point allocation guidance.
- **AI Architect Chat**: Natural language calisthenics assistant grounded in kinesiology and injury prevention.
- **Form Flaw Remediation**: Generates targeted micro-routines to fix persistent posture breakdowns.

---

## 4. Local Persistence & Performance
- **IndexedDB**: Persistent local database for workouts, daily completion streaks, and hunter attributes.
- **PWA & Offline Capable**: Runs 100% offline for live camera tracking, skeleton rendering, and rep validation.
