import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import dotenv from 'dotenv';
import {
  testGeminiConnectionBackend,
  generateAdaptiveQuestBackend,
  chatWithSystemArchitectBackend,
  analyzeWorkoutSessionBackend,
  generateZeroToHeroRoadmapBackend,
  remediateFormFlawsBackend,
} from './src/server/geminiBackend.ts';

dotenv.config();

export default defineConfig(() => {
  return {
    base: './',
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'gemini-api-dev-middleware',
        configureServer(server) {
          server.middlewares.use(async (req, res, next) => {
            if (req.url === '/api/gemini/test-connection' && req.method === 'POST') {
              let body = '';
              req.on('data', (chunk) => {
                body += chunk;
              });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body || '{}');
                  const result = await testGeminiConnectionBackend(parsed.apiKey);
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = result.success ? 200 : 400;
                  res.end(JSON.stringify(result));
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 500;
                  res.end(JSON.stringify({ success: false, message: err.message }));
                }
              });
              return;
            }

            if (req.url === '/api/gemini/generate-quest' && req.method === 'POST') {
              let body = '';
              req.on('data', (chunk) => {
                body += chunk;
              });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body || '{}');
                  const result = await generateAdaptiveQuestBackend({
                    profile: parsed.profile,
                    history: parsed.history || [],
                    specialization: parsed.specialization,
                    providedApiKey: parsed.apiKey,
                    last3DaysCompletionRate: parsed.last3DaysCompletionRate,
                  });
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 200;
                  res.end(JSON.stringify(result));
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
              return;
            }

            if (req.url === '/api/gemini/chat' && req.method === 'POST') {
              let body = '';
              req.on('data', (chunk) => {
                body += chunk;
              });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body || '{}');
                  const result = await chatWithSystemArchitectBackend({
                    messages: parsed.messages,
                    profile: parsed.profile,
                    providedApiKey: parsed.apiKey,
                  });
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 200;
                  res.end(JSON.stringify(result));
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
              return;
            }

            if (req.url === '/api/gemini/analyze-workout' && req.method === 'POST') {
              let body = '';
              req.on('data', (chunk) => {
                body += chunk;
              });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body || '{}');
                  const result = await analyzeWorkoutSessionBackend({
                    sessionData: parsed.sessionData,
                    profile: parsed.profile,
                    providedApiKey: parsed.apiKey,
                  });
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 200;
                  res.end(JSON.stringify(result));
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
              return;
            }

            if (req.url === '/api/gemini/zero-to-hero-roadmap' && req.method === 'POST') {
              let body = '';
              req.on('data', (chunk) => {
                body += chunk;
              });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body || '{}');
                  const result = await generateZeroToHeroRoadmapBackend({
                    profile: parsed.profile,
                    providedApiKey: parsed.apiKey,
                  });
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 200;
                  res.end(JSON.stringify(result));
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
              return;
            }

            if (req.url === '/api/gemini/remediate-flaw' && req.method === 'POST') {
              let body = '';
              req.on('data', (chunk) => {
                body += chunk;
              });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body || '{}');
                  const result = await remediateFormFlawsBackend({
                    flawTypes: parsed.flawTypes || [],
                    currentExercise: parsed.currentExercise || 'Standard Push-ups',
                    profile: parsed.profile,
                    providedApiKey: parsed.apiKey,
                  });
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 200;
                  res.end(JSON.stringify(result));
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
              return;
            }

            next();
          });
        }
      }
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
