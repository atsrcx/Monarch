import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import {
  testGeminiConnectionBackend,
  generateAdaptiveQuestBackend,
  chatWithSystemArchitectBackend,
  analyzeWorkoutSessionBackend,
  generateZeroToHeroRoadmapBackend,
  remediateFormFlawsBackend,
  generatePersonalizedOnboardingPlanBackend,
  generateWeeklyPlanBackend
} from './src/server/geminiBackend.ts';
import { searchSkillVideosBackend } from './src/server/skillVideosBackend.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// API: Test Gemini Connection Protocol
app.post('/api/gemini/test-connection', async (req: Request, res: Response) => {
  const { apiKey } = req.body;
  try {
    const result = await testGeminiConnectionBackend(apiKey);
    return res.json(result);
  } catch (err: any) {
    return res.json({
      success: false,
      message: err.message || 'Internal Server Error during Gemini connection test.'
    });
  }
});

// API: Adaptive Daily Calisthenics Quest Generator
app.post('/api/gemini/generate-quest', async (req: Request, res: Response) => {
  const { profile, history, specialization, apiKey, last3DaysCompletionRate } = req.body;
  try {
    const quest = await generateAdaptiveQuestBackend({
      profile,
      history: history || [],
      specialization,
      providedApiKey: apiKey,
      last3DaysCompletionRate
    });
    return res.json(quest);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to generate quest',
      message: err.message
    });
  }
});

// API: AI Calisthenics System Architect Chat
app.post('/api/gemini/chat', async (req: Request, res: Response) => {
  const { messages, profile, apiKey } = req.body;
  try {
    const result = await chatWithSystemArchitectBackend({
      messages,
      profile,
      providedApiKey: apiKey
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to process architect chat',
      message: err.message
    });
  }
});

// API: AI Biomechanical Workout Debrief Analyzer
app.post('/api/gemini/analyze-workout', async (req: Request, res: Response) => {
  const { sessionData, profile, apiKey } = req.body;
  try {
    const result = await analyzeWorkoutSessionBackend({
      sessionData,
      profile,
      providedApiKey: apiKey
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to analyze workout session',
      message: err.message
    });
  }
});

// API: Zero-to-Hero Calisthenics Mastery Roadmap
app.post('/api/gemini/zero-to-hero-roadmap', async (req: Request, res: Response) => {
  const { profile, apiKey } = req.body;
  try {
    const result = await generateZeroToHeroRoadmapBackend({
      profile,
      providedApiKey: apiKey
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to generate zero-to-hero roadmap',
      message: err.message
    });
  }
});

// API: Form Flaw Biomechanical Remediation Protocol
app.post('/api/gemini/remediate-flaw', async (req: Request, res: Response) => {
  const { flawTypes, currentExercise, profile, apiKey } = req.body;
  try {
    const result = await remediateFormFlawsBackend({
      flawTypes: flawTypes || [],
      currentExercise: currentExercise || 'Standard Push-ups',
      profile,
      providedApiKey: apiKey
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to remediate form flaws',
      message: err.message
    });
  }
});

// API: Personalized Onboarding Master Plan
app.post('/api/gemini/onboarding-plan', async (req: Request, res: Response) => {
  try {
    const result = await generatePersonalizedOnboardingPlanBackend(req.body);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to generate onboarding master plan',
      message: err.message
    });
  }
});

// API: 7-Day Calisthenics & Combat Weekly Plan
app.post('/api/gemini/weekly-plan', async (req: Request, res: Response) => {
  const { profile, goals, equipment, apiKey } = req.body;
  try {
    const result = await generateWeeklyPlanBackend({
      profile,
      goals: goals || [],
      equipment: equipment || [],
      providedApiKey: apiKey
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to generate weekly plan',
      message: err.message
    });
  }
});

// API: Dynamic Skill Learning Video Discovery
app.post('/api/skills/videos', async (req: Request, res: Response) => {
  const { skillId, skillName, category, customQuery, apiKey } = req.body;
  try {
    const result = await searchSkillVideosBackend({
      skillId,
      skillName: skillName || 'Push-Up',
      category,
      customQuery,
      providedApiKey: apiKey
    });
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      error: 'Failed to discover skill videos',
      message: err.message
    });
  }
});

// Serve static frontend in production build
app.use(express.static(path.join(__dirname, 'dist')));

app.get('*', (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`SYSTEM: MONARCH CALISTHENICS Server online at http://0.0.0.0:${PORT}`);
});
